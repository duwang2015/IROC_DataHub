"""Convert DVA constraint spreadsheets to MIM automation CSV.

Parses dose-volume constraint notation (D/V metrics with Gy/%, cc units)
from an Excel DVA form and generates a CSV compatible with MIM software.

Ported from mim_script_auto_conversion.m (MATLAB, version 8).
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)

# MIM constraint type constants
CONSTRAINT_D = "CONSTRAINT_TYPE_D"
CONSTRAINT_V = "CONSTRAINT_TYPE_V"
CONSTRAINT_STAT = "CONSTRAINT_TYPE_STATISTIC"
DOSE_GY = "DOSE_UNIT_GY"
DOSE_PCT_RX = "DOSE_UNIT_PERCENT_RX"
VOL_ML = "VOLUME_UNIT_ML"
VOL_PCT = "VOLUME_UNIT_PERCENT_CONTOUR_VOL"
CMP_GT = "COMPARISON_TYPE_GREATER_THAN"
CMP_LT = "COMPARISON_TYPE_LESS_THAN"

_NUM_RE = re.compile(r"[\d.]+")


def _extract_numbers(text: str) -> list[str]:
    """Extract all numeric tokens from a string."""
    if not isinstance(text, str):
        text = str(text)
    return _NUM_RE.findall(text)


def _detect_comparison(col4: str, col5: str) -> str:
    """Determine comparison type from goal/variation columns."""
    # Check column 4 (goal) for explicit < or >
    if "<" in str(col4):
        return CMP_LT
    if ">" in str(col4):
        return CMP_GT

    # Check column 5 (variation) for range indicators
    col5_str = str(col5)
    if "to" in col5_str.lower() or "and" in col5_str.lower() or "-" in col5_str:
        return CMP_GT
    if "<" in col5_str:
        return CMP_LT
    if ">" in col5_str:
        return CMP_GT

    return CMP_GT  # default


def _parse_constraint_type(notation: str) -> dict:
    """Parse a DVA constraint notation like ``D0.03cc[Gy]`` or ``V20Gy[%]``.

    Returns a dict with keys: type, dose, dose_unit, volume, volume_unit.
    """
    result: dict = {}
    notation = notation.strip()

    if notation.lower().startswith("mean"):
        result["type"] = CONSTRAINT_STAT
        result["statistic"] = "MINMEANMAX_MEAN"
        result["dose_unit"] = DOSE_GY
        return result
    if notation.lower().startswith("max"):
        result["type"] = CONSTRAINT_STAT
        result["statistic"] = "MINMEANMAX_MAX"
        result["dose_unit"] = DOSE_GY
        return result
    if notation.lower().startswith("min"):
        result["type"] = CONSTRAINT_STAT
        result["statistic"] = "MINMEANMAX_MIN"
        result["dose_unit"] = DOSE_GY
        return result

    # Find bracket position
    bracket = notation.find("[")
    if bracket < 0:
        result["type"] = CONSTRAINT_STAT
        result["dose_unit"] = DOSE_GY
        return result

    prefix = notation[:bracket]
    inside = notation[bracket + 1 :].rstrip("]")

    if notation[0] == "D":
        result["type"] = CONSTRAINT_D
        # Parse volume part (between D and [)
        vol_part = prefix[1:]
        if vol_part.lower().endswith("cc"):
            result["volume_unit"] = VOL_ML
            result["volume"] = vol_part[:-2]
        elif vol_part.endswith("%"):
            result["volume_unit"] = VOL_PCT
            result["volume"] = vol_part[:-1]
        else:
            result["volume"] = vol_part

        # Parse dose unit (inside brackets)
        if inside == "%":
            result["dose_unit"] = DOSE_PCT_RX
        elif inside.lower() in ("gy", "gy"):
            result["dose_unit"] = DOSE_GY
        else:
            result["dose_unit"] = DOSE_GY

    elif notation[0] == "V":
        result["type"] = CONSTRAINT_V
        # Parse dose part (between V and [)
        dose_part = prefix[1:]
        if dose_part.lower().endswith("gy"):
            result["dose_unit"] = DOSE_GY
            result["dose"] = dose_part[:-2]
        elif dose_part.endswith("%"):
            result["dose_unit"] = DOSE_PCT_RX
            result["dose"] = dose_part[:-1]
        else:
            result["dose"] = dose_part

        # Parse volume unit (inside brackets)
        if inside == "%":
            result["volume_unit"] = VOL_PCT
        elif inside.lower() == "cc":
            result["volume_unit"] = VOL_ML
        else:
            result["volume_unit"] = VOL_ML

    return result


def dva_to_mim_csv(
    input_excel: str | Path,
    output_csv: str | Path,
) -> pd.DataFrame:
    """Convert a DVA constraint Excel file to MIM CSV format.

    The input Excel has 7 columns (no header):
      1. Contour name
      2. (unused)
      3. Constraint notation (e.g. ``D0.03cc[Gy]``)
      4. Goal value (may contain ``<`` or ``>``)
      5. Variation value (may contain range like ``60 to 65``)
      6. (unused)
      7. Unique ID (constraint name)

    Parameters
    ----------
    input_excel : Path
        Input DVA Excel file.
    output_csv : Path
        Output MIM CSV file.

    Returns
    -------
    DataFrame
        The MIM constraint table.
    """
    input_excel = Path(input_excel)
    output_csv = Path(output_csv)

    df = pd.read_excel(input_excel, header=None)

    rows = []
    for _, raw in df.iterrows():
        contour = str(raw.iloc[0]) if pd.notna(raw.iloc[0]) else ""
        notation = str(raw.iloc[2]) if pd.notna(raw.iloc[2]) else ""
        goal_str = str(raw.iloc[3]) if pd.notna(raw.iloc[3]) else ""
        var_str = str(raw.iloc[4]) if pd.notna(raw.iloc[4]) else ""
        unique_id = str(raw.iloc[6]) if pd.notna(raw.iloc[6]) else ""

        parsed = _parse_constraint_type(notation)
        comparison = _detect_comparison(goal_str, var_str)

        # Extract numeric values
        goal_nums = _extract_numbers(goal_str)
        var_nums = _extract_numbers(var_str)
        score1 = float(goal_nums[0]) if goal_nums else 0.0

        # Compute thresholds
        neg_threshold = 0.0
        pos_threshold = 0.0
        if len(var_nums) >= 2:
            pos_threshold = float(var_nums[1]) - score1
            neg_threshold = score1 - float(var_nums[0])
        elif len(var_nums) == 1:
            if "<" in var_str:
                pos_threshold = float(var_nums[0]) - score1
            elif ">" in var_str:
                neg_threshold = score1 - float(var_nums[0])

        row = {
            "Constraint Name": unique_id,
            "Constraint Type": parsed.get("type", ""),
            "Contours": contour,
            "Regex Used": "0",
            "Contour Types": "",
            "Dose": parsed.get("dose", score1),
            "Dose Units": parsed.get("dose_unit", ""),
            "Volume": parsed.get("volume", ""),
            "Volume Units": parsed.get("volume_unit", ""),
            "Comparison Type": comparison,
            "Statistic Type": parsed.get("statistic", ""),
            "Negative Threshold": neg_threshold,
            "Positive Threshold": pos_threshold,
        }

        # For D-type, score goes in Dose; for V-type, in Volume
        if parsed.get("type") == CONSTRAINT_D:
            row["Dose"] = score1
        elif parsed.get("type") == CONSTRAINT_V:
            row["Volume"] = score1

        rows.append(row)

    result = pd.DataFrame(rows)
    result.to_csv(output_csv, index=False)
    logger.info("Wrote %d constraints → %s", len(result), output_csv)
    return result
