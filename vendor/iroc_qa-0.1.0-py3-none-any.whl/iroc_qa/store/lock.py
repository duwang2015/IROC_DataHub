"""Single-writer lock for the store, implemented as an O_EXCL lock file on the share."""

from __future__ import annotations

import getpass
import json
import logging
import os
import socket
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


class LockHeldError(RuntimeError):
    def __init__(self, holder: dict):
        self.holder = holder
        super().__init__(f"store lock held by {holder.get('user')}@{holder.get('host')} "
                         f"pid {holder.get('pid')} since {holder.get('started_at')}")


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if sys.platform == "win32":
        import ctypes

        handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)  # type: ignore[attr-defined]
        if handle:
            ctypes.windll.kernel32.CloseHandle(handle)  # type: ignore[attr-defined]
            return True
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


class StoreLock:
    def __init__(self, path: Path, stale_minutes: int = 120, heartbeat_seconds: int = 60,
                 cmd: str = ""):
        self.path = Path(path)
        self.stale_minutes = stale_minutes
        self.heartbeat_seconds = heartbeat_seconds
        self.cmd = cmd or " ".join(sys.argv[:3])
        self._fd: int | None = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.host = socket.gethostname()
        self.user = _username()

    # -- state ------------------------------------------------------------
    def read_holder(self) -> dict | None:
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def is_held_by_live_process(self) -> bool:
        if not self.path.exists():
            return False
        holder = self.read_holder() or {}
        try:
            age_min = (time.time() - self.path.stat().st_mtime) / 60.0
        except OSError:
            return False
        if holder.get("host") == self.host:
            try:
                return _pid_alive(int(holder.get("pid", -1)))
            except (TypeError, ValueError):
                pass
        return age_min < self.stale_minutes

    # -- acquire / release -------------------------------------------------
    def _payload(self) -> str:
        return json.dumps({
            "host": self.host, "pid": os.getpid(), "user": self.user,
            "started_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "cmd": self.cmd,
        })

    def acquire(self, wait_seconds: float = 0.0, poll: float = 2.0) -> None:
        deadline = time.time() + wait_seconds
        while True:
            try:
                fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                if self.is_held_by_live_process():
                    if time.time() < deadline:
                        time.sleep(poll)
                        continue
                    raise LockHeldError(self.read_holder() or {})
                holder = self.read_holder() or {}
                logger.warning("breaking stale store lock held by %s@%s (pid %s, since %s)",
                               holder.get("user"), holder.get("host"), holder.get("pid"),
                               holder.get("started_at"))
                try:
                    self.path.unlink()
                except OSError:
                    pass
                continue
            os.write(fd, self._payload().encode("utf-8"))
            os.close(fd)
            self._fd = 1
            self._start_heartbeat()
            return

    def release(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
        if self._fd is not None:
            try:
                self.path.unlink()
            except OSError:
                pass
            self._fd = None

    def heartbeat(self) -> None:
        try:
            self.path.write_text(self._payload(), encoding="utf-8")
        except OSError as exc:
            logger.warning("lock heartbeat failed: %s", exc)

    def _start_heartbeat(self) -> None:
        if self.heartbeat_seconds <= 0:
            return
        self._stop.clear()

        def _run():
            while not self._stop.wait(self.heartbeat_seconds):
                self.heartbeat()

        self._thread = threading.Thread(target=_run, name="store-lock-heartbeat", daemon=True)
        self._thread.start()

    def __enter__(self) -> StoreLock:
        self.acquire()
        return self

    def __exit__(self, *exc) -> None:
        self.release()


def _username() -> str:
    try:
        return getpass.getuser()
    except Exception:
        return os.environ.get("USERNAME") or os.environ.get("USER") or "unknown"
