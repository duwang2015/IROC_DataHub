function Out=code_reports2bprocessedV5
% Use the folder of reports to be processed as input_path, 
% Select a folder for the output of vv spreadsheet (output_path)
% Please notice the warning message
% replace all the nan to 0, and remove "'".
% by Yutao. Jan. 2015.
% revised by Huaizhi Geng  Oct. 2018.

%path=pwd;
%path=strrep(path,'MATLAB_codes','Reports2BProcessed\');

mh1=msgbox('RTOG Physics team: Please select your VVspreadsheet processing input folder');
dname1=uigetdir;
input_path=dname1;
delete(mh1); 

mh2=msgbox('RTOG Physics team: Please select your VVspreadsheet Summary output folder');
dname2=uigetdir; 
output_path=dname2;
delete(mh2);

L=dir(input_path);

% header={'Trial','Totals','Target Contour','Total','OAR contour','Total','Target DVH','Total','OAR DVH'};
% header={'Trial','DD received','DD QAed','DD received and QAed','Totals','Prepared for QA','Target Contour 3 (%)','Total','2B done','OAR contour 3 (%)','Total','Prepared for QA','Target DVH 3 (%)','Total','Prepared for QA','OAR DVH 3 (%)'};

header={'Trial','Digital_Data_Received (C)','Digital_Data_Integrity_QA (D)','PI reviewed (E)','Target Total-TV Score (F)','Target Contour Score 3(%) (F)','OAR Total just for calculation','Prepared for QA','OAR contour Score 3 (%) (G)','Target DVH Total','Prepared for QA','Target DVH Score 3 (%) (H)' ,'OAR DVH Total just for calc','Prepared for QA','OAR DVH Score 3 (%) (I)'};
Out_results={};

h=waitbar(0,'Ready...','Name','VV forms are under scanning...');

for i=3:length(L)
    tic;
%    Excel=actxserver('Excel.Application');
%    Excel.Workbooks.Open(fullfile(path,L(i).name));
    [~,~,temp_current_excel_sheet]=xlsread(fullfile(input_path,L(i).name));
    current_excel_sheet=cell(size(temp_current_excel_sheet,1)+21,size(temp_current_excel_sheet,2));
    current_excel_sheet(1:size(temp_current_excel_sheet,1),:)=temp_current_excel_sheet;
    temp_index=strfind(L(i).name,' ');
    trial_name=L(i).name(1:temp_index(1)-1);
    empty_row=0;
    M_temp=[];
    current_excel_sheet{1,3}(logical(1-isletter(current_excel_sheet{1,3})))='';
    current_excel_sheet{1,4}(logical(1-isletter(current_excel_sheet{1,4})))='';
    current_excel_sheet{1,6}(logical(1-isletter(current_excel_sheet{1,6})))='';
    current_excel_sheet{1,7}(logical(1-isletter(current_excel_sheet{1,7})))='';
    current_excel_sheet{1,8}(logical(1-isletter(current_excel_sheet{1,8})))='';
    current_excel_sheet{1,9}(logical(1-isletter(current_excel_sheet{1,9})))='';
    signal_C=(strcmpi(current_excel_sheet{1,3},'digitaldatareceived')');
    signal_D=(strcmpi(current_excel_sheet{1,4},'digitaldataintegrityqa')');
    signal_E=(strcmpi(current_excel_sheet{1,4},'PIreviewed')');
    signal_F=(strcmpi(current_excel_sheet{1,6},'tvscore')');
    signal_G=(strcmpi(current_excel_sheet{1,7},'oarscore')');
    signal_H=(strcmpi(current_excel_sheet{1,8},'tvdvascore')');
    signal_I=(strcmpi(current_excel_sheet{1,9},'oardvascore')');
    
    if signal_C&&signal_D&&signal_E&&signal_F&&signal_G&&signal_H&&signal_I
    else
        warning(['!!! File ',trial_name,' is not written in standard format, please check manually !!!']);
    end
    
    empty_row=0;
    
    for j=2:8000    % 8000 is a number big enough
        if empty_row>20
            break
        end
        if floor(j/50)*50==j
            waitbar((i-2)/(length(L)-2),h,sprintf(['Current file: ' L(i).name '\nCurrent row: ' num2str(j)]));
        end
        
%         temp_C=Excel.ActiveSheet.Range(['C' num2str(j)]).Value;
%         temp_D=Excel.ActiveSheet.Range(['D' num2str(j)]).Value;
%         temp_F=Excel.ActiveSheet.Range(['F' num2str(j)]).Value;
%         temp_G=Excel.ActiveSheet.Range(['G' num2str(j)]).Value;
%         temp_H=Excel.ActiveSheet.Range(['H' num2str(j)]).Value;
%         temp_I=Excel.ActiveSheet.Range(['I' num2str(j)]).Value;
        temp_C=current_excel_sheet{j,3};
        temp_D=current_excel_sheet{j,4};
        temp_E=current_excel_sheet{j,5};
        temp_F=current_excel_sheet{j,6};
        temp_G=current_excel_sheet{j,7};
        temp_H=current_excel_sheet{j,8};
        temp_I=current_excel_sheet{j,9};
        
        disp(j)
        
  % if ~isnumeric(temp_F) && ~isnumeric(temp_G) && ~isnumeric(temp_H) && ~isnumeric(temp_I)
        if isempty(current_excel_sheet{j,1})
            empty_row=empty_row+1;
            continue
        elseif isnan(current_excel_sheet{j,1})
            empty_row=empty_row+1;
            continue
        else
            
            
            if isempty(temp_C), temp_C=999; end
            if isempty(temp_D), temp_D=999; end
            if isempty(temp_E), temp_E=999; end
            if isempty(temp_F), temp_F=999; end
            if isempty(temp_G), temp_G=999; end
            if isempty(temp_H), temp_H=999; end
            if isempty(temp_I), temp_I=999; end
            
            
            if ~isnumeric(temp_C), temp_C=999; end
            if ~isnumeric(temp_D), temp_D=999; end
            if ~isnumeric(temp_E), temp_E=999; end
            if ~isnumeric(temp_F), temp_F=999; end
            if ~isnumeric(temp_G), temp_G=999; end
            if ~isnumeric(temp_H), temp_H=999; end
            if ~isnumeric(temp_I)
                temp_I=999;
            end
            
            if isnan(temp_C), temp_C=999; end
            if isnan(temp_D), temp_D=999; end
            if isnan(temp_E), temp_E=999; end
            if isnan(temp_F), temp_F=999; end
            if isnan(temp_G), temp_G=999; end
            if isnan(temp_H), temp_H=999; end
            if isnan(temp_I), temp_I=999; end
           
            
            M_temp=[M_temp;[temp_C, temp_D, temp_E, temp_F, temp_G, temp_H, temp_I]];
        end
        
 
    end
    Total=sum(M_temp(:,3)==2);
    Unaccptable_num_TV=sum(M_temp(:,4)==3);
    Unaccptable_num_OAR=sum(M_temp(:,5)==3);
    Unaccptable_num_DT=sum(M_temp(:,6)==3);
    Unaccptable_num_DO=sum(M_temp(:,7)==3);
    Unaccptable_r_TV=Unaccptable_num_TV./Total;
    Unaccptable_r_OAR=Unaccptable_num_OAR./Total;
    Unaccptable_r_DT=Unaccptable_num_DT./Total;
    Unaccptable_r_DO=Unaccptable_num_DO./Total;
    two_in_C=sum(M_temp(:,1)==2);
    two_in_D=sum(M_temp(:,2)==2);
    %two_in_CD=sum(M_temp(:,1)==2 & M_temp(:,2)==2);
    %data_temp=[two_in_C,two_in_D,two_in_CD,Total(3),two_in_CD-Total(3),Unaccptable_r(3),Total(4),two_in_CD-Total(4),Unaccptable_r(4),Total(5),two_in_CD-Total(5),Unaccptable_r(5),Total(6),two_in_CD-Total(6),Unaccptable_r(6)];
    %data_temp=[two_in_C,two_in_D,Total,two_in_D-Total,round(10*Unaccptable_r(3))/10,Total,two_in_D-Total,round(10*Unaccptable_r(4))/10,Total,two_in_D-Total,round(10*Unaccptable_r(5))/10,Total,two_in_D-Total,round(10*Unaccptable_r(6))/10];
    data_temp=[two_in_C,two_in_D,Total,Unaccptable_num_TV,Unaccptable_r_TV,Unaccptable_num_OAR,Unaccptable_r_OAR,Unaccptable_num_DT,Unaccptable_r_DT,Unaccptable_num_DO,Unaccptable_r_DO];
    Out_results=[Out_results;[trial_name,num2cell(data_temp)]];
    clearvars M_temp
    toc;
end
%Out_results(:,6)=cellstr(strcat(num2str(cell2mat(Out_results(:,6)),'%.1f'),'%'));
%Out_results(:,9)=cellstr(strcat(num2str(cell2mat(Out_results(:,9)),'%.1f'),'%'));
%Out_results(:,12)=cellstr(strcat(num2str(cell2mat(Out_results(:,12)),'%.1f'),'%'));
%Out_results(:,15)=cellstr(strcat(num2str(cell2mat(Out_results(:,15)),'%.1f'),'%'));
%Out=[header;Out_results];
xlswrite(fullfile(output_path,'VV spreadsheet.xls'),Out_results);
close(h);