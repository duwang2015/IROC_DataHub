"""CLI entry point for evaluation: ``iroc-eval``."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path


def main(argv: list[str] | None = None) -> int:
    """Run evaluation subcommands."""
    parser = argparse.ArgumentParser(
        prog="iroc-eval",
        description="IROC QA evaluation and reporting tools.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_vv = sub.add_parser("vv-report", help="Process VV spreadsheets")
    p_vv.add_argument("--input-dir", required=True, type=Path)
    p_vv.add_argument("--output", required=True, type=Path)

    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if args.command == "vv-report":
        from .vv_report import process_vv_sheets
        df = process_vv_sheets(args.input_dir, args.output)
        print(f"Processed {len(df)} trials → {args.output}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
