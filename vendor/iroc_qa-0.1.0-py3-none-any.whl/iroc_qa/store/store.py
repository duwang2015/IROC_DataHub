"""The :class:`Store` object: config + catalog + lock + trial log for one store root."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

from .catalog import Catalog, case_pk
from .config import StoreConfig, find_root, load_config, write_default_config
from .layout import DERIVED_DIR, ORIGINAL_DIR, case_dir
from .lock import StoreLock
from .triallog import TrialLog

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class CaseRef:
    trial: str          # collection id (a trial or a non-trial source)
    case_id: str
    pk: str
    dir: Path
    site: str = "OTHER"
    kind: str = "trial"

    @property
    def collection(self) -> str:
        return self.trial

    @property
    def original_dir(self) -> Path:
        return self.dir / ORIGINAL_DIR

    @property
    def derived_dir(self) -> Path:
        return self.dir / DERIVED_DIR


class Store:
    def __init__(self, cfg: StoreConfig, read_only: bool = False):
        self.cfg = cfg
        self.root = cfg.root
        self.read_only = read_only
        self.catalog = Catalog(cfg.catalog_path, cfg.busy_timeout_seconds, read_only=read_only)
        self.log = TrialLog(self.root, None if read_only else self.catalog,
                            path_for=self.collection_dir)

    # -- lifecycle -------------------------------------------------------------
    @classmethod
    def open(cls, root: Path | str | None = None, read_only: bool = False) -> Store:
        cfg = load_config(find_root(root))
        store = cls(cfg, read_only=read_only)
        if not read_only:
            store.ensure_dirs()
            store.catalog.init_schema()
            for t in cfg.trials:
                store.catalog.upsert_trial(t.id, t.name, t.protocol_ids, t.site, t.kind)
        elif not cfg.catalog_path.exists():
            raise FileNotFoundError(f"catalog missing: {cfg.catalog_path} (run iroc-store reindex)")
        return store

    @classmethod
    def init(cls, root: Path | str, trials: list[str] | None = None,
             overwrite: bool = False) -> Store:
        write_default_config(root, trials, overwrite=overwrite)
        return cls.open(root)

    def ensure_dirs(self) -> None:
        for p in (self.root, self.cfg.inbox, self.cfg.holding, self.cfg.logs, self.cfg.reports):
            p.mkdir(parents=True, exist_ok=True)

    def close(self) -> None:
        self.catalog.close()

    def __enter__(self) -> Store:
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # -- helpers ---------------------------------------------------------------
    def lock(self, cmd: str = "") -> StoreLock:
        return StoreLock(self.cfg.lock_path, self.cfg.lock_stale_minutes, cmd=cmd)

    def case(self, trial: str, case_id: str) -> CaseRef:
        rule = self.cfg.trial(trial)
        from .layout import normalize_case_id

        cid = normalize_case_id(case_id, rule.case_id_normalize)
        return CaseRef(rule.id, cid, case_pk(rule.id, cid),
                       case_dir(self.root, rule.site, rule.id, cid), rule.site, rule.kind)

    def case_from_pk(self, pk: str) -> CaseRef:
        trial, cid = pk.split("/", 1)
        return self.case(trial, cid)

    def collection_dir(self, collection_id: str) -> Path:
        from .layout import collection_dir

        rule = self.cfg.trial(collection_id)
        return collection_dir(self.root, rule.site, rule.id)

    def rel(self, path: Path) -> str:
        return Path(path).resolve().relative_to(self.root.resolve()).as_posix()

    def abs(self, rel_path: str) -> Path:
        return self.root / Path(rel_path)

    # -- derived data -----------------------------------------------------------------
    def series(self, case: CaseRef, modality: str | None = None, batch: str | None = None,
               current_only: bool = True):
        from .derived import series_refs

        return series_refs(self, case, modality=modality, batch=batch, current_only=current_only)

    def derive(self, case: CaseRef, module: str, version: str, params: dict | None = None,
               inputs: dict | None = None, *, force: bool = False):
        from .derived import derive

        return derive(self, case, module, version, params, inputs, force=force)

    def refresh_card(self, case: CaseRef) -> None:
        """Rewrite <case>/case.json and the collection's cases.json after a change."""
        if self.read_only:
            return
        from .cards import refresh_cards

        refresh_cards(self, case)

    # -- hooks implemented by later modules -------------------------------------
    def refresh_overview(self) -> None:
        if self.read_only or not self.cfg.overview_auto:
            return
        try:
            from .overview import write_overview
        except ImportError:
            return
        try:
            write_overview(self)
        except Exception as exc:  # never fail an ingest because of the HTML page
            logger.warning("overview not refreshed: %s", exc)

    def run_on_ingest(self, case: CaseRef, batch_id: str) -> None:
        if not self.cfg.on_ingest:
            return
        try:
            from .producers import run_named
        except ImportError:
            return
        for name in self.cfg.on_ingest:
            try:
                run_named(self, name, case, batch_id)
            except Exception as exc:
                logger.warning("on_ingest producer %s failed for %s: %s", name, case.pk, exc)
