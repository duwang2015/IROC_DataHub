"""Static HTML overview of the store: ``_overview/index.html`` plus one page per trial.

Self-contained (no external fonts, scripts or styles) so it opens straight from a share,
online or not. The tree is rendered server-side with <details> so it works without
JavaScript; the inline script only adds filtering and expand/collapse.
"""

from __future__ import annotations

import html
import json
from datetime import datetime, timezone
from pathlib import Path

from .store import Store

IMAGE_MODS = ("CT", "MR", "PT")
RT_MODS = ("RTSTRUCT", "RTPLAN", "RTDOSE")
BADGE = {"CT": "CT", "MR": "MR", "PT": "PET", "RTSTRUCT": "RS", "RTPLAN": "RP", "RTDOSE": "RD",
         "REG": "REG", "SEG": "SEG"}


def file_uri(path: Path | str) -> str:
    s = str(path)
    if s.startswith("\\\\"):
        return "file://" + s[2:].replace("\\", "/")
    if len(s) > 1 and s[1] == ":":
        return "file:///" + s.replace("\\", "/")
    try:
        return Path(s).resolve().as_uri()
    except (ValueError, OSError):
        return "file://" + s.replace("\\", "/")


def _esc(s) -> str:
    return html.escape("" if s is None else str(s), quote=True)


def _gb(n: int) -> str:
    return f"{(n or 0) / 1e9:.2f} GB" if (n or 0) >= 1e8 else f"{(n or 0) / 1e6:.1f} MB"


def _short(ts: str | None) -> str:
    if not ts:
        return "-"
    return ts[:16].replace("T", " ")


# ---------------------------------------------------------------------------
# payload
# ---------------------------------------------------------------------------

def trial_payload(store: Store, trial_id: str) -> dict:
    cat = store.catalog
    cases = []
    holding_by_case: dict[str, list[dict]] = {}
    holding_unassigned = []
    known_cases = {c["case_id"] for c in cat.list_cases(trial_id)}
    for h in cat.list_holding():
        dec = json.loads(h["report_json"]) if h["report_json"] else {}
        h = dict(h, suggested=f"{dec.get('trial') or '?'}/{dec.get('case') or '?'}")
        if dec.get("trial") == trial_id and dec.get("case") in known_cases:
            holding_by_case.setdefault(dec["case"], []).append(h)
        elif dec.get("trial") == trial_id or not dec.get("trial"):
            holding_unassigned.append(h)
    for c in cat.list_cases(trial_id):
        pk = c["id"]
        batches = cat.list_batches(pk)
        series = cat.series_for_case(pk)
        runs = cat.runs_for_case(pk)
        mods = sorted({s["modality"] for s in series})
        modules = sorted({r["module"] for r in runs if r["status"] == "completed"})
        bl = []
        for b in batches:
            bl.append({
                "name": b["name"], "seq": b["seq"], "kind": b["kind"],
                "ingested_at": b["ingested_at"], "n_files": b["n_files"],
                "bytes": b["total_bytes"], "current": b["id"] == c["current_batch_id"],
                "path": str(store.case(trial_id, c["case_id"]).original_dir / b["name"]),
                "series": [{
                    "dir": s["rel_dir"].rsplit("/", 1)[-1], "modality": s["modality"],
                    "number": s["series_number"], "desc": s["series_description"],
                    "n": s["n_instances"], "date": s["study_date"],
                    "path": str(store.abs(s["rel_dir"])),
                } for s in series if s["batch_id"] == b["id"]],
            })
        rl = []
        for r in runs:
            files = [f for f in cat.derived_files(pk, module=r["module"], latest_only=False)
                     if f["derived_run_id"] == r["id"]]
            rl.append({
                "module": r["module"], "version": r["version"], "run": r["run_name"],
                "status": r["status"], "started_at": r["started_at"],
                "path": str(store.abs(r["rel_dir"])),
                "files": [{"name": f["rel_path"].rsplit("/", 1)[-1], "kind": f["kind"],
                           "size": f["size"]} for f in files],
            })
        cases.append({
            "case_id": c["case_id"], "pk": pk, "modalities": mods, "modules": modules,
            "n_batches": len(batches), "current": (c["current_batch_id"] or "").rsplit("/", 1)[-1],
            "pinned": bool(c["pinned"]), "batches": bl, "runs": rl,
            "holding": [{"ingest_id": h["ingest_id"], "group_no": h["group_no"],
                         "reason": h["reason"],
                         "report": str(store.cfg.holding / h["ingest_id"] / "report.md")}
                        for h in holding_by_case.get(c["case_id"], [])],
            "path": str(store.case(trial_id, c["case_id"]).dir),
            "last_ingest": max((b["ingested_at"] for b in batches), default=None),
        })
    stats = next((t for t in cat.stats()["trials"] if t["id"] == trial_id), {})
    rule = store.cfg.trial(trial_id)
    return {
        "trial": trial_id, "name": stats.get("name") or trial_id, "cases": cases,
        "stats": stats, "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "log": cat.trial_log(trial_id, limit=10),
        "log_path": str(store.log.path(trial_id)),
        "site": rule.site, "kind": rule.kind,
        "holding_unassigned": [{"ingest_id": h["ingest_id"], "group_no": h["group_no"],
                                "reason": h["reason"], "suggested": h["suggested"],
                                "report": str(store.cfg.holding / h["ingest_id"] / "report.md")}
                               for h in holding_unassigned],
        "root": str(store.root),
    }


# ---------------------------------------------------------------------------
# rendering
# ---------------------------------------------------------------------------

CSS = """
/* layout: summary strip on top, filter bar, then one collapsible row per case */
:root{--bg:#f6f7f9;--panel:#ffffff;--fg:#1c2430;--muted:#5d6a7a;--line:#d8dee6;
 --accent:#0f6e7a;--accent-soft:#dff0f2;--ok:#2d7f4f;--warn:#b26a00;--bad:#b3261e;
 --chip:#eef1f5;--mono:ui-monospace,Consolas,"SF Mono",Menlo,monospace;
 --sans:system-ui,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#13181f;--panel:#1b222b;
 --fg:#e6ebf1;--muted:#9aa7b6;--line:#2c3744;--accent:#5fc3cf;--accent-soft:#143a40;
 --ok:#6fcf97;--warn:#f0b35b;--bad:#f28b82;--chip:#242e39;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#13181f;--panel:#1b222b;--fg:#e6ebf1;--muted:#9aa7b6;
 --line:#2c3744;--accent:#5fc3cf;--accent-soft:#143a40;--ok:#6fcf97;--warn:#f0b35b;
 --bad:#f28b82;--chip:#242e39;color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.45 var(--sans);
 padding-block:0 32px}
.wrap{max-width:1180px;margin:0 auto;padding-inline:16px}
header.top{position:sticky;top:0;background:var(--bg);border-bottom:1px solid var(--line);
 padding-block:12px;z-index:2}
header.top .wrap{display:flex;flex-wrap:wrap;gap:8px 20px;align-items:baseline}
h1{font-size:20px;margin:0;font-weight:650;letter-spacing:-.01em}
h2{font-size:15px;margin:24px 0 10px;text-transform:uppercase;letter-spacing:.06em;
 color:var(--muted);font-weight:600}
.meta{color:var(--muted);font-size:12.5px}
a{color:var(--accent)}
.tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;
 margin-top:14px}
.tile{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:10px 12px}
.tile .v{font-size:22px;font-weight:650;font-variant-numeric:tabular-nums;line-height:1.1}
.tile .k{color:var(--muted);font-size:12px;margin-top:4px}
.tile.warn .v{color:var(--warn)}
.bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:14px 0 10px}
.bar input[type=search]{flex:1 1 180px;min-width:0;padding:6px 10px;border:1px solid var(--line);
 border-radius:5px;background:var(--panel);color:var(--fg);font:inherit}
.bar select,.bar button{padding:6px 10px;border:1px solid var(--line);border-radius:5px;
 background:var(--panel);color:var(--fg);font:inherit;cursor:pointer}
.bar button:hover{border-color:var(--accent)}
.bar label{display:inline-flex;gap:5px;align-items:center;color:var(--muted);font-size:13px}
details.case{background:var(--panel);border:1px solid var(--line);border-radius:6px;
 margin-bottom:6px}
details.case>summary{list-style:none;cursor:pointer;display:flex;flex-wrap:wrap;gap:6px 12px;
 align-items:center;padding:8px 12px}
details.case>summary::-webkit-details-marker{display:none}
details.case>summary::before{content:"▸";color:var(--muted);width:12px;display:inline-block}
details.case[open]>summary::before{content:"▾"}
.cid{font-weight:650;font-family:var(--mono);min-width:120px}
.chips{display:flex;flex-wrap:wrap;gap:4px}
.chip{background:var(--chip);border-radius:4px;padding:1px 7px;font-size:12px;
 font-family:var(--mono)}
.chip.on{background:var(--accent-soft);color:var(--accent)}
.chip.bad{background:transparent;color:var(--bad);border:1px solid var(--bad)}
.chip.ok{color:var(--ok)}
.sp{flex:1}
.body{padding:4px 12px 12px 30px;border-top:1px solid var(--line)}
.body h4{margin:10px 0 4px;font-size:12.5px;color:var(--muted);text-transform:uppercase;
 letter-spacing:.05em;font-weight:600}
table{border-collapse:collapse;width:100%;font-size:13px}
td,th{padding:3px 8px 3px 0;text-align:left;vertical-align:top;border-bottom:1px solid var(--line)}
th{color:var(--muted);font-weight:600;font-size:12px}
td.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
td.m,.mono{font-family:var(--mono);font-size:12.5px}
tr.cur td{background:var(--accent-soft)}
.tbl{overflow-x:auto}
.plink{color:var(--muted);text-decoration:none;font-size:12px}
.plink:hover{color:var(--accent)}
.log{font-family:var(--mono);font-size:12px;white-space:pre-wrap;background:var(--panel);
 border:1px solid var(--line);border-radius:6px;padding:10px 12px;overflow-x:auto}
.empty{color:var(--muted);padding:20px;text-align:center}
.trials{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px}
.tcard{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:14px 16px}
.tcard h3{margin:0 0 6px;font-size:16px}
.tcard .row{display:flex;flex-wrap:wrap;gap:6px 14px;color:var(--muted);font-size:13px}
.tcard .row b{color:var(--fg);font-variant-numeric:tabular-nums}
.hold{color:var(--bad)}
@media (prefers-reduced-motion:no-preference){details.case>summary{transition:background .12s}}
details.case>summary:hover{background:var(--chip)}
:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
"""

JS = """
(function(){
  var q=document.getElementById('q'),mod=document.getElementById('mod'),
      miss=document.getElementById('miss'),hold=document.getElementById('hold'),
      nod=document.getElementById('noderived'),cnt=document.getElementById('cnt');
  var cases=Array.prototype.slice.call(document.querySelectorAll('details.case'));
  function apply(){
    var s=(q.value||'').trim().toUpperCase(),m=mod.value,ms=miss.value,n=0;
    cases.forEach(function(el){
      var mods=' '+el.dataset.mods+' ',show=true;
      if(s&&el.dataset.case.toUpperCase().indexOf(s)<0)show=false;
      if(m&&mods.indexOf(' '+m+' ')<0)show=false;
      if(ms&&mods.indexOf(' '+ms+' ')>=0)show=false;
      if(hold.checked&&el.dataset.holding==='0')show=false;
      if(nod.checked&&el.dataset.modules.indexOf('dcm2nii')>=0)show=false;
      el.hidden=!show;if(show)n++;
    });
    cnt.textContent=n+' / '+cases.length+' cases';
  }
  [q,mod,miss,hold,nod].forEach(function(e){e.addEventListener('input',apply);
    e.addEventListener('change',apply)});
  document.getElementById('xall').addEventListener('click',function(){
    cases.forEach(function(e){if(!e.hidden)e.open=true})});
  document.getElementById('call').addEventListener('click',function(){
    cases.forEach(function(e){e.open=false})});
  apply();
})();
"""


def _link(path: str, text: str, cls: str = "plink") -> str:
    return f'<a class="{cls}" href="{_esc(file_uri(path))}" title="{_esc(path)}">{_esc(text)}</a>'


def _chips(mods: list[str], hl: tuple[str, ...] = IMAGE_MODS + RT_MODS) -> str:
    out = []
    for m in mods:
        cls = "chip on" if m in hl else "chip"
        out.append(f'<span class="{cls}">{_esc(BADGE.get(m, m))}</span>')
    return "".join(out)


def render_case(c: dict) -> str:
    missing = [m for m in ("CT", "RTSTRUCT", "RTDOSE") if m not in c["modalities"]]
    s = [f'<details class="case" data-case="{_esc(c["case_id"])}" '
         f'data-mods="{_esc(" ".join(c["modalities"]))}" '
         f'data-modules="{_esc(" ".join(c["modules"]))}" '
         f'data-holding="{len(c["holding"])}">']
    s.append(f'<summary><span class="cid">{_esc(c["case_id"])}</span>'
             f'<span class="chips">{_chips(c["modalities"])}</span>'
             f'<span class="chips">' +
             "".join(f'<span class="chip ok">{_esc(m)}</span>' for m in c["modules"]) +
             "".join(f'<span class="chip bad">holding: {_esc(h["reason"])}</span>'
                     for h in c["holding"]) +
             "".join(f'<span class="chip bad">no {_esc(BADGE[m])}</span>' for m in missing) +
             f'</span><span class="sp"></span>'
             f'<span class="meta">{c["n_batches"]} batch{"es" if c["n_batches"] != 1 else ""}'
             f' · current {_esc(c["current"] or "-")}{" (pinned)" if c["pinned"] else ""}'
             f' · {_short(c["last_ingest"])}</span></summary>')
    s.append('<div class="body">')
    s.append(f'<div class="meta">{_link(c["path"], c["path"], "plink mono")}</div>')
    s.append("<h4>original</h4>")
    for b in c["batches"]:
        cur = " · current" if b["current"] else ""
        s.append(f'<div class="meta"><b>{_esc(b["name"])}</b> seq {b["seq"]} · {_esc(b["kind"])}'
                 f' · {b["n_files"]} files · {_gb(b["bytes"])} · {_short(b["ingested_at"])}{cur}'
                 f' · {_link(b["path"], "open folder")}</div>')
        if b["series"]:
            s.append('<div class="tbl"><table><tr><th>series folder</th><th>modality</th>'
                     '<th class="n">files</th><th>description</th><th>study date</th></tr>')
            for se in b["series"]:
                s.append(f'<tr><td class="m">{_link(se["path"], se["dir"], "plink mono")}</td>'
                         f'<td>{_esc(se["modality"])}</td><td class="n">{se["n"]}</td>'
                         f'<td>{_esc(se["desc"] or "")}</td><td>{_esc(se["date"] or "")}</td></tr>')
            s.append("</table></div>")
    if c["runs"]:
        s.append("<h4>derived</h4>")
        s.append('<div class="tbl"><table><tr><th>module</th><th>run</th><th>status</th>'
                 '<th>outputs</th></tr>')
        for r in c["runs"]:
            files = ", ".join(f["name"] for f in r["files"][:8]) + \
                (f" (+{len(r['files']) - 8})" if len(r["files"]) > 8 else "")
            st = {"completed": "ok", "failed": "bad", "running": ""}.get(r["status"], "")
            s.append(f'<tr><td class="m">{_esc(r["module"])}@{_esc(r["version"])}</td>'
                     f'<td class="m">{_link(r["path"], r["run"], "plink mono")}</td>'
                     f'<td><span class="chip {st}">{_esc(r["status"])}</span></td>'
                     f'<td class="m">{_esc(files)}</td></tr>')
        s.append("</table></div>")
    if c["holding"]:
        s.append("<h4>holding</h4>")
        for h in c["holding"]:
            s.append(f'<div class="meta hold">{_esc(h["ingest_id"])} group {h["group_no"]}: '
                     f'{_esc(h["reason"])} · {_link(h["report"], "report.md")}</div>')
    s.append("</div></details>")
    return "".join(s)


def render_trial_page(p: dict) -> str:
    st = p["stats"] or {}
    mods = st.get("cases_by_modality", {})
    mod_by = st.get("cases_by_module", {})
    n_cases = len(p["cases"])
    n_hold = sum(len(c["holding"]) for c in p["cases"]) + len(p["holding_unassigned"])
    tiles = [
        (n_cases, "cases", ""), (st.get("batches", 0), "batches", ""),
        (st.get("files", 0), "files", ""), (_gb(st.get("bytes", 0)), "on disk", ""),
        (mods.get("CT", 0), "with CT", ""), (mods.get("MR", 0), "with MR", ""),
        (mods.get("PT", 0), "with PET", ""), (mods.get("RTSTRUCT", 0), "with RTSTRUCT", ""),
        (mods.get("RTDOSE", 0), "with RTDOSE", ""),
        (mod_by.get("dcm2nii", 0), "dcm2nii done", ""),
        (n_hold, "in holding", "warn" if n_hold else ""),
    ]
    all_mods = sorted({m for c in p["cases"] for m in c["modalities"]})
    h = ['<header class="top"><div class="wrap">'
         f'<h1>{_esc(p["trial"])}</h1><span class="chip">{_esc(p.get("site", ""))} · '
         f'{_esc(p.get("kind", "trial"))}</span>'
         f'<span class="meta"><a href="index.html">all trials</a> · '
         f'{_link(p["root"], p["root"], "plink mono")} · generated {_short(p["generated_at"])} UTC'
         f' · {_link(p["log_path"], "TRIAL_LOG.md")}</span></div></header>',
         '<main class="wrap">', '<div class="tiles">']
    for v, k, cls in tiles:
        h.append(f'<div class="tile {cls}"><div class="v">{_esc(v)}</div><div class="k">{_esc(k)}'
                 '</div></div>')
    h.append("</div>")
    h.append('<div class="bar"><input id="q" type="search" placeholder="case id…" '
             'aria-label="filter by case id">'
             '<label>has <select id="mod"><option value="">any</option>' +
             "".join(f'<option value="{_esc(m)}">{_esc(BADGE.get(m, m))}</option>'
                     for m in all_mods) +
             '</select></label><label>missing <select id="miss"><option value="">-</option>' +
             "".join(f'<option value="{_esc(m)}">{_esc(BADGE.get(m, m))}</option>'
                     for m in ("CT", "MR", "PT", "RTSTRUCT", "RTPLAN", "RTDOSE")) +
             '</select></label>'
             '<label><input id="hold" type="checkbox"> has holding</label>'
             '<label><input id="noderived" type="checkbox"> no dcm2nii</label>'
             '<span class="sp"></span><span id="cnt" class="meta"></span>'
             '<button id="xall" type="button">expand all</button>'
             '<button id="call" type="button">collapse all</button></div>')
    if not p["cases"]:
        h.append('<div class="empty">No cases filed yet. Drop data into _inbox and run '
                 '<span class="mono">iroc-store ingest</span>.</div>')
    for c in p["cases"]:
        h.append(render_case(c))
    if p["holding_unassigned"]:
        h.append("<h2>holding, not filed to any case</h2>")
        for x in p["holding_unassigned"]:
            h.append(f'<div class="meta hold">{_esc(x["ingest_id"])} group {x["group_no"]}: '
                     f'{_esc(x["reason"])} · header says {_esc(x["suggested"])} · '
                     f'{_link(x["report"], "report.md")}</div>')
    h.append("<h2>recent log</h2>")
    if p["log"]:
        h.append('<div class="log">' + "\n".join(
            f'{_esc(r["at"])}  {_esc(r["username"])}@{_esc(r["host"])}  {_esc(r["action"]):<8}'
            f'  {_esc(r["case_id"] or "-"):<14}  {_esc(r["message"])}' for r in p["log"]) +
            "</div>")
    else:
        h.append('<div class="meta">no log entries yet</div>')
    h.append(f"</main><script>{JS}</script>")
    return _page(f"{p['trial']} data overview", "\n".join(h))


def _trial_card(t: dict) -> str:
    mods = t["cases_by_modality"]
    kind = t.get("kind", "trial")
    return (f'<div class="tcard"><h3><a href="{_esc(t["id"])}.html">{_esc(t["id"])}</a> '
            f'<span class="chip">{_esc(kind)}</span></h3>'
            f'<div class="row"><span><b>{t["cases"]}</b> cases</span>'
            f'<span><b>{t["batches"]}</b> batches</span><span><b>{t["files"]}</b> files</span>'
            f'<span><b>{_gb(t["bytes"])}</b></span></div>'
            f'<div class="row" style="margin-top:6px">' +
            "".join(f'<span>{_esc(BADGE.get(m, m))} <b>{n}</b></span>'
                    for m, n in sorted(mods.items())) +
            f'</div><div class="meta" style="margin-top:6px">last ingest '
            f'{_short(t["last_ingest"])}</div></div>')


def render_index(store: Store, payloads: list[dict]) -> str:
    st = store.catalog.stats()
    holding = store.catalog.list_holding()
    inbox = sorted(p.name for p in store.cfg.inbox.iterdir()) if store.cfg.inbox.exists() else []
    h = ['<header class="top"><div class="wrap"><h1>IROC data store</h1>'
         f'<span class="meta">{_link(str(store.root), str(store.root), "plink mono")} · generated '
         f'{_short(datetime.now(timezone.utc).isoformat())} UTC</span></div></header>',
         '<main class="wrap">', '<div class="tiles">']
    tot_cases = sum(t["cases"] for t in st["trials"])
    tot_files = sum(t["files"] for t in st["trials"])
    tot_bytes = sum(t["bytes"] for t in st["trials"])
    for v, k, cls in [(len(st["trials"]), "trials", ""), (tot_cases, "cases", ""),
                      (tot_files, "files", ""), (_gb(tot_bytes), "on disk", ""),
                      (len(holding), "holding groups", "warn" if holding else ""),
                      (len(inbox), "waiting in inbox", "warn" if inbox else "")]:
        h.append(f'<div class="tile {cls}"><div class="v">{_esc(v)}</div><div class="k">{_esc(k)}'
                 '</div></div>')
    h.append("</div>")
    by_site: dict[str, list[dict]] = {}
    for t in st["trials"]:
        by_site.setdefault(t.get("site") or "OTHER", []).append(t)
    for site in store.cfg.sites():
        if site not in by_site:
            continue
        h.append(f"<h2>{_esc(site)}</h2><div class=\"trials\">")
        for t in by_site[site]:
            h.append(_trial_card(t))
        h.append("</div>")
    if not st["trials"]:
        h.append('<div class="empty">no collections configured</div>')
    if holding:
        h.append("<h2>holding</h2>")
        for x in holding:
            rep = store.cfg.holding / x["ingest_id"] / "report.md"
            h.append(f'<div class="meta hold">{_esc(x["ingest_id"])} group {x["group_no"]}: '
                     f'{_esc(x["reason"])} · {_link(str(rep), "report.md")}</div>')
    if inbox:
        h.append("<h2>inbox</h2>")
        for n in inbox:
            h.append(f'<div class="meta mono">{_esc(n)}</div>')
    h.append("</main>")
    return _page("IROC data store overview", "\n".join(h))


def write_overview(store: Store, trial: str | None = None) -> list[Path]:
    out_dir = store.cfg.overview_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    trials = [store.cfg.trial(trial).id] if trial else \
        [t["id"] for t in store.catalog.list_trials()]
    written = []
    payloads = []
    for tid in trials:
        p = trial_payload(store, tid)
        payloads.append(p)
        path = out_dir / f"{tid}.html"
        path.write_text(render_trial_page(p), encoding="utf-8")
        written.append(path)
    idx = out_dir / "index.html"
    idx.write_text(render_index(store, payloads), encoding="utf-8")
    written.append(idx)
    return written


def _page(title: str, body: str) -> str:
    return ('<!doctype html>\n<html lang="en"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            f"<title>{_esc(title)}</title><style>{CSS}</style></head><body>\n"
            + body + "\n</body></html>\n")
