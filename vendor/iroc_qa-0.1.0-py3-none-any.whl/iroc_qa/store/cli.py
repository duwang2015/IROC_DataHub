"""``iroc-store`` command line."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

EXIT_OK, EXIT_ERROR, EXIT_NOTHING = 0, 1, 2


def _open(args, read_only: bool = False):
    from .store import Store

    return Store.open(getattr(args, "root", None), read_only=read_only)


def _print_json(obj) -> None:
    print(json.dumps(obj, indent=2, ensure_ascii=False, default=str))


# -- commands ---------------------------------------------------------------------

def cmd_init(args) -> int:
    from .store import Store

    store = Store.init(args.root, args.trial, overwrite=args.force)
    print(f"initialised store at {store.root}")
    print(f"  config:  {store.root / 'iroc_store.yaml'}  (edit the trial rules!)")
    print(f"  inbox:   {store.cfg.inbox}")
    print(f"  holding: {store.cfg.holding}")
    store.close()
    return EXIT_OK


def cmd_ingest(args) -> int:
    from .ingest import Ingester

    forced = (args.trial, args.case) if args.trial or args.case else None
    if forced and not (args.trial and args.case):
        print("--trial and --case must be given together", file=sys.stderr)
        return EXIT_ERROR
    with _open(args) as store:
        ing = Ingester(store, dry_run=args.dry_run, forced=forced, keep_source=args.keep_source)
        rep = ing.run([Path(s) for s in args.source] or None, if_idle=args.if_idle,
                      settle=not args.no_settle)
    if args.json:
        _print_json([d.__dict__ for d in rep.drops])
    else:
        print(rep.summary())
    if rep.lock_busy:
        return EXIT_NOTHING
    if rep.n_failures:
        return EXIT_ERROR
    return EXIT_OK if rep.drops else EXIT_NOTHING


def cmd_import(args) -> int:
    from .ingest import Ingester

    forced = (args.trial, args.case) if args.trial or args.case else None
    if forced and not (args.trial and args.case):
        print("--trial and --case must be given together", file=sys.stderr)
        return EXIT_ERROR
    with _open(args) as store:
        ing = Ingester(store, dry_run=args.dry_run, forced=forced, copy_only=True)
        rep = ing.import_folder(Path(args.folder), if_idle=args.if_idle)
    if args.json:
        _print_json([d.__dict__ for d in rep.drops] + [{"summary": str(rep.summary_path)}])
    else:
        print(rep.summary())
    if rep.lock_busy:
        return EXIT_NOTHING
    return EXIT_ERROR if rep.n_failures else EXIT_OK


def cmd_cards(args) -> int:
    from .cards import rebuild_all_cards

    with _open(args) as store:
        n = rebuild_all_cards(store)
    print(f"wrote {n} case.json card(s) and the collection indexes")
    return EXIT_OK


def cmd_reports(args) -> int:
    from .summary import list_summaries

    with _open(args, read_only=True) as store:
        rows = list_summaries(store.cfg.reports, args.last)
    if args.json:
        _print_json(rows)
        return EXIT_OK
    if not rows:
        print("no summaries yet")
        return EXIT_NOTHING
    if args.show:
        print(Path(rows[0]["path"]).read_text(encoding="utf-8"))
        return EXIT_OK
    for r in rows:
        t = r["totals"]
        print(f"{r['started_at'][:16]}  {r['mode']:7s}{' (dry)' if r['dry_run'] else '      '} "
              f"batches={t.get('batches', 0)} held={t.get('held_groups', 0)} "
              f"dups={t.get('duplicates', 0)} fail={t.get('failures', 0)}  {r['path']}")
    return EXIT_OK


def cmd_status(args) -> int:
    with _open(args, read_only=True) as store:
        st = store.catalog.stats()
        lock = store.lock()
        st["lock"] = lock.read_holder() if lock.is_held_by_live_process() else None
        st["inbox_pending"] = sorted(p.name for p in store.cfg.inbox.iterdir()) \
            if store.cfg.inbox.exists() else []
        st["holding_items"] = store.catalog.list_holding()
        st["leftovers"] = [str(p) for p in store.root.glob("*/*/original/.incoming-*")] + \
            [str(p) for p in store.root.glob("*/*/derived/*/.tmp-*")]
    if args.json:
        _print_json(st)
        return EXIT_OK
    print(f"store: {store.root}")
    for t in st["trials"]:
        mods = ", ".join(f"{m}:{n}" for m, n in sorted(t["cases_by_modality"].items()))
        print(f"  [{t.get('site', 'OTHER')}] {t['id']} ({t.get('kind', 'trial')}): "
              f"{t['cases']} cases, {t['batches']} batches, {t['files']} files, "
              f"{t['bytes'] / 1e9:.2f} GB  [{mods}]  last ingest {t['last_ingest'] or '-'}")
    print(f"  holding: {st['holding_open']} unresolved group(s)")
    for h in st["holding_items"]:
        print(f"    {h['ingest_id']} group {h['group_no']}: {h['reason']}")
    print(f"  inbox: {len(st['inbox_pending'])} pending drop(s)")
    for n in st["inbox_pending"]:
        print(f"    {n}")
    if st["lock"]:
        print(f"  lock: held by {st['lock'].get('user')}@{st['lock'].get('host')} "
              f"since {st['lock'].get('started_at')}")
    for p in st["leftovers"]:
        print(f"  leftover: {p}  (run reindex)")
    return EXIT_OK


def cmd_ls(args) -> int:
    with _open(args, read_only=True) as store:
        cat = store.catalog
        if not args.trial:
            rows = cat.list_trials()
            out = [{"site": t.get("site", "OTHER"), "kind": t.get("kind", "trial"),
                    "trial": t["id"], "name": t["name"],
                    "cases": len(cat.list_cases(t["id"]))} for t in rows]
            out.sort(key=lambda o: (store.cfg.sites().index(o["site"])
                                    if o["site"] in store.cfg.sites() else 99, o["trial"]))
            if args.json:
                _print_json(out)
            else:
                for o in out:
                    print(f"{o['site']:10s} {o['kind']:7s} {o['trial']}\t{o['cases']} cases")
            return EXIT_OK
        if not args.case:
            rows = cat.list_cases(store.cfg.trial(args.trial).id)
            out = []
            for c in rows:
                mods = sorted({s["modality"] for s in cat.series_for_case(c["id"])})
                out.append({"case": c["case_id"], "batches": len(cat.list_batches(c["id"])),
                            "current": (c["current_batch_id"] or "").rsplit("/", 1)[-1],
                            "modalities": mods})
            if args.json:
                _print_json(out)
            else:
                for o in out:
                    print(f"{o['case']}\t{o['batches']} batch(es)\tcurrent={o['current']}\t"
                          f"{','.join(o['modalities'])}")
            return EXIT_OK
        case = store.case(args.trial, args.case)
        info = {"case": case.pk, "dir": str(case.dir),
                "batches": cat.list_batches(case.pk),
                "series": cat.series_for_case(case.pk),
                "runs": cat.runs_for_case(case.pk)}
        if args.json:
            for b in info["batches"]:
                b.pop("manifest_json", None)
            _print_json(info)
            return EXIT_OK
        c = cat.get_case(case.pk)
        print(f"{case.pk}  ({case.dir})")
        for b in info["batches"]:
            cur = " *current*" if c and c["current_batch_id"] == b["id"] else ""
            print(f"  {b['name']}  seq={b['seq']} kind={b['kind']} files={b['n_files']} "
                  f"ingested={b['ingested_at']}{cur}")
            for s in [s for s in info["series"] if s["batch_id"] == b["id"]]:
                print(f"      {s['rel_dir'].rsplit('/', 1)[-1]:40s} {s['modality']:8s} "
                      f"n={s['n_instances']:<4d} {s['series_description'] or ''}")
        for r in info["runs"]:
            print(f"  derived {r['module']}@{r['version']} {r['run_name']} [{r['status']}]")
    return EXIT_OK


def cmd_resolve(args) -> int:
    from .ingest import resolve_holding

    groups = None if args.all else args.group
    if not groups and not args.all:
        print("give --group N (repeatable) or --all", file=sys.stderr)
        return EXIT_ERROR
    with _open(args) as store:
        results = resolve_holding(store, args.ingest_id, groups, args.trial, args.case,
                                  discard=args.discard, force_new_batch=args.force_new_batch)
    if args.json:
        _print_json(results)
    else:
        for r in results:
            print(f"group {r['group_no']}: {r['status']}"
                  + (f" ({r.get('batch_id')})" if r.get("batch_id") else ""))
    return EXIT_OK if all(r["status"] != "still held" for r in results) else EXIT_ERROR


def cmd_current(args) -> int:
    with _open(args) as store:
        case = store.case(args.trial, args.case)
        cat = store.catalog
        c = cat.get_case(case.pk)
        if c is None:
            print(f"unknown case {case.pk}", file=sys.stderr)
            return EXIT_ERROR
        if args.set:
            b = cat.get_batch(f"{case.pk}/{args.set}")
            if b is None:
                print(f"unknown batch {args.set}", file=sys.stderr)
                return EXIT_ERROR
            with cat.transaction():
                cat.set_current_batch(case.pk, b["id"], pin=args.pin)
            store.log.append(case.trial, "current", f"current batch set to {args.set}"
                             + (" (pinned)" if args.pin else ""), case_id=case.case_id)
            c = cat.get_case(case.pk)
        if args.kind:
            target = args.set or (c["current_batch_id"] or "").rsplit("/", 1)[-1]
            with cat.transaction():
                cat.set_batch_kind(f"{case.pk}/{target}", args.kind)
        store.refresh_card(case)
        print(f"{case.pk}: current={(c['current_batch_id'] or '').rsplit('/', 1)[-1] or '-'} "
              f"pinned={bool(c['pinned'])}")
    return EXIT_OK


def cmd_note(args) -> int:
    with _open(args) as store:
        trial = store.cfg.trial(args.trial).id
        case = store.case(trial, args.case).case_id if args.case else None
        rec = store.log.append(trial, "note", args.message, case_id=case)
    print(f"logged to {store.log.path(trial)}: {rec['at']} {rec['action']} {rec['message']}")
    return EXIT_OK


def cmd_log(args) -> int:
    with _open(args, read_only=True) as store:
        trial = store.cfg.trial(args.trial).id
        case = store.case(trial, args.case).case_id if args.case else None
        rows = store.catalog.trial_log(trial, case, args.since, args.action, args.limit)
    if args.json:
        _print_json(rows)
    else:
        for r in reversed(rows):
            print(f"{r['at']}  {r['username']}@{r['host']:<12s} {r['action']:<8s} "
                  f"{r['case_id'] or '-':<14s} {r['message']}")
    return EXIT_OK


def cmd_watch(args) -> int:
    from .watch import watch

    with _open(args) as store:
        return watch(store, args.interval or store.cfg.interval_seconds, once=args.once)


def cmd_find(args) -> int:
    from .find import find

    with _open(args, read_only=True) as store:
        rows = find(store, args.trial, modalities=args.modality, missing=args.missing,
                    kind=args.kind, module=args.module, current_only=args.current_only)
    if args.json:
        _print_json(rows)
    elif args.paths:
        for r in rows:
            for p in r.get("paths", []):
                print(p)
    else:
        for r in rows:
            print(f"{r['case']}\t{len(r.get('paths', []))} path(s)")
    return EXIT_OK if rows else EXIT_NOTHING


def cmd_reindex(args) -> int:
    from .reindex import reindex

    with _open(args) as store:
        rep = reindex(store, full_hash=args.full, dry_run=args.dry_run)
    print(rep.summary())
    return EXIT_OK if not rep.problems else EXIT_ERROR


def cmd_verify(args) -> int:
    from .verify import verify

    with _open(args, read_only=True) as store:
        rep = verify(store, args.trial, args.case, sample=args.sample, full_hash=not args.fast)
    print(rep.summary())
    return EXIT_OK if rep.ok else EXIT_ERROR


def cmd_overview(args) -> int:
    from .overview import write_overview

    with _open(args, read_only=True) as store:
        paths = write_overview(store, args.trial)
    for p in paths:
        print(p)
    return EXIT_OK


def cmd_export(args) -> int:
    from .export import export

    with _open(args) as store:
        n = export(store, args.trial, args.case or None, Path(args.dest),
                   what="derived" if args.derived else "original", module=args.derived,
                   current_only=args.current_only, note=args.note)
    print(f"exported {n} file(s) to {args.dest}")
    return EXIT_OK if n else EXIT_NOTHING


def cmd_run(args) -> int:
    from .producers import run_named_cli

    with _open(args) as store:
        return run_named_cli(store, args)


# -- parser ------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="iroc-store",
                                description="IROC on-disk data store: inbox ingest, catalog, "
                                            "trial logs, overview.")
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="cmd", required=True)

    def root_arg(sp):
        sp.add_argument("--root", help="store root (default: $IROC_STORE_ROOT or walk up)")

    s = sub.add_parser("init", help="create a new store root")
    s.add_argument("root")
    s.add_argument("--trial", action="append", help="trial id (repeatable)")
    s.add_argument("--force", action="store_true", help="overwrite existing config")
    s.set_defaults(func=cmd_init)

    s = sub.add_parser("ingest", help="file everything in the inbox (or given sources)")
    root_arg(s)
    s.add_argument("source", nargs="*", help="drop folders/files (default: whole inbox)")
    s.add_argument("--dry-run", action="store_true")
    s.add_argument("--trial")
    s.add_argument("--case")
    s.add_argument("--if-idle", action="store_true", help="exit 2 at once if locked")
    s.add_argument("--keep-source", action="store_true")
    s.add_argument("--no-settle", action="store_true", help="skip the settle check")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_ingest)

    s = sub.add_parser("import", help="file everything found in a folder; the folder is left "
                                      "untouched (copy, never move)")
    root_arg(s)
    s.add_argument("folder")
    s.add_argument("--dry-run", action="store_true")
    s.add_argument("--trial")
    s.add_argument("--case")
    s.add_argument("--if-idle", action="store_true")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_import)

    s = sub.add_parser("cards", help="rebuild every <case>/case.json and <collection>/cases.json")
    root_arg(s)
    s.set_defaults(func=cmd_cards)

    s = sub.add_parser("reports", help="list ingest/import summaries")
    root_arg(s)
    s.add_argument("--last", type=int, default=20)
    s.add_argument("--show", action="store_true", help="print the most recent summary")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_reports)

    s = sub.add_parser("watch", help="poll the inbox forever")
    root_arg(s)
    s.add_argument("--interval", type=int)
    s.add_argument("--once", action="store_true")
    s.set_defaults(func=cmd_watch)

    s = sub.add_parser("status", help="store summary")
    root_arg(s)
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_status)

    s = sub.add_parser("ls", help="list trials / cases / one case")
    root_arg(s)
    s.add_argument("trial", nargs="?")
    s.add_argument("case", nargs="?")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_ls)

    s = sub.add_parser("find", help="query cases and paths")
    root_arg(s)
    s.add_argument("--trial", required=True)
    s.add_argument("--modality", action="append", default=[])
    s.add_argument("--missing", action="append", default=[], help="modality that must be absent")
    s.add_argument("--kind", help="file kind filter, e.g. nifti_image")
    s.add_argument("--module", help="derived module, e.g. dcm2nii")
    s.add_argument("--current-only", action="store_true")
    s.add_argument("--paths", action="store_true")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_find)

    s = sub.add_parser("resolve", help="file or discard a holding group")
    root_arg(s)
    s.add_argument("ingest_id")
    s.add_argument("--group", type=int, action="append")
    s.add_argument("--all", action="store_true")
    s.add_argument("--trial")
    s.add_argument("--case")
    s.add_argument("--discard", action="store_true")
    s.add_argument("--force-new-batch", action="store_true",
                   help="accept files whose SOPInstanceUID already exists with other content")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_resolve)

    s = sub.add_parser("current", help="show/set the current batch of a case")
    root_arg(s)
    s.add_argument("trial")
    s.add_argument("case")
    s.add_argument("--set", metavar="BATCH")
    s.add_argument("--pin", action="store_true")
    s.add_argument("--kind", choices=["initial", "resubmission", "supplement"])
    s.set_defaults(func=cmd_current)

    s = sub.add_parser("note", help="append a note to a trial log")
    root_arg(s)
    s.add_argument("trial")
    s.add_argument("--case")
    s.add_argument("-m", "--message", required=True)
    s.set_defaults(func=cmd_note)

    s = sub.add_parser("log", help="show a trial log")
    root_arg(s)
    s.add_argument("trial")
    s.add_argument("--case")
    s.add_argument("--since")
    s.add_argument("--action")
    s.add_argument("--limit", type=int, default=200)
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_log)

    s = sub.add_parser("reindex", help="rebuild the catalog from the tree")
    root_arg(s)
    s.add_argument("--full", action="store_true", help="re-hash every file")
    s.add_argument("--dry-run", action="store_true")
    s.set_defaults(func=cmd_reindex)

    s = sub.add_parser("verify", help="check catalog against the tree")
    root_arg(s)
    s.add_argument("--trial")
    s.add_argument("--case")
    s.add_argument("--sample", type=int)
    s.add_argument("--fast", action="store_true", help="sizes only, no hashing")
    s.set_defaults(func=cmd_verify)

    s = sub.add_parser("overview", help="regenerate the HTML overview")
    root_arg(s)
    s.add_argument("--trial")
    s.set_defaults(func=cmd_overview)

    s = sub.add_parser("export", help="copy a conventional tree out of the store")
    root_arg(s)
    s.add_argument("--trial", required=True)
    s.add_argument("--case", action="append")
    s.add_argument("--dest", required=True)
    s.add_argument("--derived", metavar="MODULE")
    s.add_argument("--current-only", action="store_true")
    s.add_argument("--note", help="purpose, written to the trial log")
    s.set_defaults(func=cmd_export)

    s = sub.add_parser("run", help="run a producer module on a case")
    root_arg(s)
    s.add_argument("producer", choices=["dcm2nii", "dicom-qc"])
    s.add_argument("--trial", required=True)
    s.add_argument("--case", required=True)
    s.add_argument("--batch")
    s.add_argument("--force", action="store_true")
    s.add_argument("--no-resample", action="store_true")
    s.add_argument("--skip-suv", action="store_true")
    s.add_argument("--skip-rtstruct", action="store_true")
    s.set_defaults(func=cmd_run)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
    try:
        return args.func(args)
    except Exception as exc:
        from .config import ConfigError
        from .lock import LockHeldError

        if isinstance(exc, (ConfigError, LockHeldError, FileNotFoundError, ValueError)):
            print(f"error: {exc}", file=sys.stderr)
            return EXIT_ERROR
        raise


if __name__ == "__main__":
    sys.exit(main())
