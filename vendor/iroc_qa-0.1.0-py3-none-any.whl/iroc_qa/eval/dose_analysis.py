"""Dose distribution analysis and comparison tools.

Provides gamma analysis, dose difference statistics, plan quality
indices (CI, HI, GI), and comprehensive dose comparison reporting.
Designed for comparing original vs defaced dose distributions.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import nibabel as nib
import numpy as np

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# NIfTI loading
# ---------------------------------------------------------------------------

def _load_nifti(path: str | Path) -> tuple[np.ndarray, np.ndarray]:
    """Load NIfTI file, return (data, affine)."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"NIfTI not found: {path}")
    nii = nib.load(str(path))
    return nii.get_fdata(), nii.affine


def _voxel_spacing(affine: np.ndarray) -> np.ndarray:
    """Extract voxel spacing (mm) from affine matrix."""
    return np.sqrt(np.sum(affine[:3, :3] ** 2, axis=0))


def _voxel_volume_cc(affine: np.ndarray) -> float:
    """Compute voxel volume in cc."""
    spacing = _voxel_spacing(affine)
    return float(np.prod(spacing)) / 1000.0


# ---------------------------------------------------------------------------
# Dose difference
# ---------------------------------------------------------------------------

def dose_difference_map(
    dose_a: np.ndarray,
    dose_b: np.ndarray,
) -> np.ndarray:
    """Compute voxel-wise absolute dose difference (same units as input)."""
    return np.abs(dose_a.astype(np.float64) - dose_b.astype(np.float64))


def dose_difference_stats(
    dose_a: np.ndarray,
    dose_b: np.ndarray,
    mask: np.ndarray | None = None,
) -> dict:
    """Compute dose difference statistics.

    Parameters
    ----------
    dose_a, dose_b : array
        Dose arrays (same shape, same units).
    mask : array, optional
        Boolean mask to restrict analysis to an ROI.

    Returns
    -------
    dict with max_diff, mean_diff, std_diff, p95_diff, p99_diff,
    n_total, n_nonzero_diff.
    """
    diff = np.abs(dose_a.astype(np.float64) - dose_b.astype(np.float64))

    if mask is not None:
        diff = diff[mask]

    if diff.size == 0:
        return {
            "max_diff": 0.0, "mean_diff": 0.0, "std_diff": 0.0,
            "p95_diff": 0.0, "p99_diff": 0.0,
            "n_total": 0, "n_nonzero_diff": 0,
        }

    return {
        "max_diff": float(diff.max()),
        "mean_diff": float(diff.mean()),
        "std_diff": float(diff.std()),
        "p95_diff": float(np.percentile(diff, 95)),
        "p99_diff": float(np.percentile(diff, 99)),
        "n_total": int(diff.size),
        "n_nonzero_diff": int((diff > 0).sum()),
    }


# ---------------------------------------------------------------------------
# Gamma analysis (same-grid)
# ---------------------------------------------------------------------------

def gamma_analysis_3d(
    ref_dose: np.ndarray,
    eval_dose: np.ndarray,
    spacing_mm: np.ndarray | tuple | list,
    dose_threshold_pct: float = 3.0,
    distance_mm: float = 3.0,
    dose_cutoff_pct: float = 10.0,
    ref_dose_value: float | None = None,
) -> tuple[np.ndarray, float]:
    """3D gamma index analysis for same-grid dose distributions.

    Optimized for the defacing use case where reference and evaluation
    doses share the same spatial grid (no interpolation needed).

    Parameters
    ----------
    ref_dose : array (3D)
        Reference dose distribution.
    eval_dose : array (3D)
        Evaluation dose distribution.
    spacing_mm : array-like (3,)
        Voxel spacing in mm for each axis.
    dose_threshold_pct : float
        Dose difference criterion (%).  Default 3%.
    distance_mm : float
        Distance-to-agreement criterion (mm).  Default 3mm.
    dose_cutoff_pct : float
        Exclude voxels below this % of reference max dose.
    ref_dose_value : float, optional
        Reference dose for % calculation.  If None, uses max of ref_dose.

    Returns
    -------
    (gamma_map, pass_rate)
        gamma_map has same shape as ref_dose (NaN where below cutoff).
        pass_rate is the fraction of evaluated voxels with gamma <= 1.0.
    """
    ref = ref_dose.astype(np.float64)
    evl = eval_dose.astype(np.float64)
    spacing = np.array(spacing_mm, dtype=np.float64)

    if ref.shape != evl.shape:
        raise ValueError(
            f"Shape mismatch: ref {ref.shape} vs eval {evl.shape}"
        )

    # Reference dose for percentage calculation
    if ref_dose_value is None:
        ref_dose_value = float(ref.max())
    if ref_dose_value <= 0:
        logger.warning("Reference dose max is <= 0; returning trivial gamma")
        gamma_map = np.full(ref.shape, np.nan)
        return gamma_map, 1.0

    # Dose difference criterion in absolute units
    dd_threshold = ref_dose_value * dose_threshold_pct / 100.0

    # Dose cutoff mask
    cutoff_abs = ref_dose_value * dose_cutoff_pct / 100.0
    analysis_mask = ref >= cutoff_abs

    n_analyzed = int(analysis_mask.sum())
    if n_analyzed == 0:
        logger.warning("No voxels above dose cutoff — trivial gamma")
        gamma_map = np.full(ref.shape, np.nan)
        return gamma_map, 1.0

    gamma_map = np.full(ref.shape, np.nan)

    # Search radius in voxels per axis
    search_voxels = np.ceil(distance_mm / spacing).astype(int) + 1

    # Get indices of voxels to analyze
    idx = np.argwhere(analysis_mask)  # (N, 3)

    # For each analyzed voxel, compute gamma
    # Build KD-tree of evaluation dose for spatial search
    # (For same-grid, we search neighbors directly)
    n_pass = 0
    for i in range(len(idx)):
        iz, iy, ix = idx[i]
        ref_d = ref[iz, iy, ix]

        # Define search neighborhood
        z_lo = max(0, iz - search_voxels[0])
        z_hi = min(ref.shape[0], iz + search_voxels[0] + 1)
        y_lo = max(0, iy - search_voxels[1])
        y_hi = min(ref.shape[1], iy + search_voxels[1] + 1)
        x_lo = max(0, ix - search_voxels[2])
        x_hi = min(ref.shape[2], ix + search_voxels[2] + 1)

        # Extract neighborhood from evaluation dose
        eval_patch = evl[z_lo:z_hi, y_lo:y_hi, x_lo:x_hi]

        # Physical distances from center voxel to each neighbor
        zz = np.arange(z_lo, z_hi) - iz
        yy = np.arange(y_lo, y_hi) - iy
        xx = np.arange(x_lo, x_hi) - ix
        dz, dy, dx = np.meshgrid(
            zz * spacing[0], yy * spacing[1], xx * spacing[2],
            indexing="ij",
        )
        dist_sq = dz**2 + dy**2 + dx**2

        # Gamma for each neighbor
        dose_diff_sq = (eval_patch - ref_d) ** 2
        gamma_sq = (dose_diff_sq / dd_threshold**2
                    + dist_sq / distance_mm**2)
        min_gamma = float(np.sqrt(gamma_sq.min()))

        gamma_map[iz, iy, ix] = min_gamma
        if min_gamma <= 1.0:
            n_pass += 1

    pass_rate = n_pass / n_analyzed if n_analyzed > 0 else 1.0

    logger.info(
        "Gamma %g%%/%gmm: %d/%d pass (%.1f%%)",
        dose_threshold_pct, distance_mm,
        n_pass, n_analyzed, pass_rate * 100,
    )

    return gamma_map, pass_rate


def gamma_pass_rate(gamma_map: np.ndarray, threshold: float = 1.0) -> float:
    """Compute fraction of evaluated voxels with gamma <= threshold."""
    valid = gamma_map[~np.isnan(gamma_map)]
    if valid.size == 0:
        return 1.0
    return float((valid <= threshold).sum() / valid.size)


# ---------------------------------------------------------------------------
# Per-ROI dose statistics
# ---------------------------------------------------------------------------

def dose_statistics_per_roi(
    dose_path: str | Path,
    label_path: str | Path,
    roi_mapping: dict[int, str] | str | Path,
) -> list[dict]:
    """Compute per-ROI dose statistics.

    Parameters
    ----------
    dose_path : path
        NIfTI dose file (cGy).
    label_path : path
        NIfTI label map.
    roi_mapping : dict or JSON path
        Label int → ROI name.

    Returns
    -------
    List of dicts with keys: roi_name, volume_cc, Dmin, Dmax, Dmean,
    Dstd, D2, D98.
    """
    dose_data, dose_affine = _load_nifti(dose_path)
    label_data, _ = _load_nifti(label_path)

    if isinstance(roi_mapping, (str, Path)):
        with open(roi_mapping, encoding="utf-8") as f:
            raw = json.load(f)
        roi_mapping = {int(k): v for k, v in raw.items()}

    if dose_data.shape != label_data.shape:
        raise ValueError(
            f"Shape mismatch: dose {dose_data.shape} vs labels {label_data.shape}"
        )

    label_arr = np.round(label_data).astype(int)
    voxel_cc = _voxel_volume_cc(dose_affine)

    results = []
    for label_int, name in sorted(roi_mapping.items()):
        roi_mask = label_arr == label_int
        n_voxels = int(roi_mask.sum())

        if n_voxels == 0:
            results.append({
                "roi_name": name, "volume_cc": 0.0,
                "Dmin_cGy": 0.0, "Dmax_cGy": 0.0, "Dmean_cGy": 0.0,
                "Dstd_cGy": 0.0, "D2_cGy": 0.0, "D98_cGy": 0.0,
            })
            continue

        dose_roi = dose_data[roi_mask].astype(np.float64)
        volume_cc = n_voxels * voxel_cc

        results.append({
            "roi_name": name,
            "volume_cc": round(volume_cc, 2),
            "Dmin_cGy": round(float(dose_roi.min()), 2),
            "Dmax_cGy": round(float(dose_roi.max()), 2),
            "Dmean_cGy": round(float(dose_roi.mean()), 2),
            "Dstd_cGy": round(float(dose_roi.std()), 2),
            "D2_cGy": round(float(np.percentile(dose_roi, 98)), 2),
            "D98_cGy": round(float(np.percentile(dose_roi, 2)), 2),
        })

    return results


# ---------------------------------------------------------------------------
# Plan quality indices
# ---------------------------------------------------------------------------

def conformity_index(
    dose_data: np.ndarray,
    rx_dose: float,
    target_mask: np.ndarray,
) -> float:
    """Paddick conformity index.

    CI = (V_target_rx)^2 / (V_target * V_rx)

    Where V_target_rx = volume of target receiving >= rx_dose,
    V_target = total target volume, V_rx = total volume receiving >= rx_dose.
    """
    rx_mask = dose_data >= rx_dose
    v_target = float(target_mask.sum())
    v_rx = float(rx_mask.sum())
    v_target_rx = float((target_mask & rx_mask).sum())

    if v_target == 0 or v_rx == 0:
        return 0.0

    return (v_target_rx ** 2) / (v_target * v_rx)


def homogeneity_index(
    dose_data: np.ndarray,
    target_mask: np.ndarray,
    d50_dose: float | None = None,
) -> float:
    """Homogeneity index: HI = (D2 - D98) / D50.

    Parameters
    ----------
    dose_data : array
    target_mask : boolean array
    d50_dose : float, optional
        If None, computed from dose_data within target.
    """
    dose_target = dose_data[target_mask].astype(np.float64)
    if dose_target.size == 0:
        return 0.0

    d2 = float(np.percentile(dose_target, 98))
    d98 = float(np.percentile(dose_target, 2))
    d50 = d50_dose if d50_dose is not None else float(np.percentile(dose_target, 50))

    if d50 <= 0:
        return 0.0
    return (d2 - d98) / d50


def dose_gradient_index(
    dose_data: np.ndarray,
    rx_dose: float,
    target_mask: np.ndarray,
) -> float:
    """Paddick dose gradient index: GI = V_50%_rx / V_rx.

    Ratio of volume receiving 50% of prescription to volume receiving
    100% of prescription.  Lower = steeper gradient.
    """
    v_rx = float((dose_data >= rx_dose).sum())
    v_half = float((dose_data >= rx_dose * 0.5).sum())

    if v_rx == 0:
        return 0.0
    return v_half / v_rx


# ---------------------------------------------------------------------------
# Comprehensive comparison
# ---------------------------------------------------------------------------

def compare_dose_distributions(
    original_dose_path: str | Path,
    defaced_dose_path: str | Path,
    label_path: str | Path | None = None,
    roi_mapping: dict[int, str] | str | Path | None = None,
    gamma_criteria: tuple[float, float] = (3.0, 3.0),
    dose_cutoff_pct: float = 10.0,
) -> dict:
    """All-in-one comparison of original vs defaced dose.

    Parameters
    ----------
    original_dose_path : path
        Original dose NIfTI (cGy).
    defaced_dose_path : path
        Defaced dose NIfTI (cGy).
    label_path : path, optional
        Label map NIfTI for per-ROI analysis.
    roi_mapping : dict or path, optional
        Label int → ROI name.
    gamma_criteria : (dose_pct, distance_mm)
        Gamma analysis criteria.
    dose_cutoff_pct : float
        Dose cutoff for gamma (% of max).

    Returns
    -------
    Comprehensive report dict.
    """
    orig_data, orig_affine = _load_nifti(original_dose_path)
    defc_data, defc_affine = _load_nifti(defaced_dose_path)
    spacing = _voxel_spacing(orig_affine)

    if orig_data.shape != defc_data.shape:
        raise ValueError(
            f"Shape mismatch: original {orig_data.shape} "
            f"vs defaced {defc_data.shape}"
        )

    report = {
        "original": str(original_dose_path),
        "defaced": str(defaced_dose_path),
        "shape": list(orig_data.shape),
        "spacing_mm": [round(float(s), 3) for s in spacing],
    }

    # Global dose difference
    report["global_diff"] = dose_difference_stats(orig_data, defc_data)

    # Gamma analysis
    dose_pct, dist_mm = gamma_criteria
    gamma_map, pass_rate = gamma_analysis_3d(
        orig_data, defc_data, spacing,
        dose_threshold_pct=dose_pct,
        distance_mm=dist_mm,
        dose_cutoff_pct=dose_cutoff_pct,
    )
    report["gamma"] = {
        "criteria": f"{dose_pct}%/{dist_mm}mm",
        "pass_rate": round(pass_rate * 100, 2),
        "dose_cutoff_pct": dose_cutoff_pct,
    }

    # Per-ROI analysis
    if label_path and roi_mapping:
        if isinstance(roi_mapping, (str, Path)):
            with open(roi_mapping, encoding="utf-8") as f:
                raw = json.load(f)
            roi_mapping = {int(k): v for k, v in raw.items()}

        label_data, _ = _load_nifti(label_path)
        label_arr = np.round(label_data).astype(int)

        roi_diffs = []
        for label_int, name in sorted(roi_mapping.items()):
            roi_mask = label_arr == label_int
            n_voxels = int(roi_mask.sum())
            if n_voxels == 0:
                continue

            stats = dose_difference_stats(orig_data, defc_data, mask=roi_mask)
            stats["roi_name"] = name
            stats["volume_cc"] = round(
                n_voxels * _voxel_volume_cc(orig_affine), 2
            )
            roi_diffs.append(stats)

        report["per_roi_diff"] = roi_diffs

    return report


def export_comparison_report(
    report: dict,
    output_path: str | Path,
):
    """Export comparison results to Excel.

    Creates sheets: Summary, Per-ROI Differences.
    """
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill
    except ImportError:
        logger.warning("openpyxl not installed — saving as JSON instead")
        output_path = Path(output_path).with_suffix(".json")
        with open(output_path, "w", encoding="utf-8") as f:
            # Convert numpy types for JSON serialization
            def _convert(obj):
                if isinstance(obj, np.integer):
                    return int(obj)
                if isinstance(obj, np.floating):
                    return float(obj)
                if isinstance(obj, np.ndarray):
                    return obj.tolist()
                return obj

            json.dump(report, f, indent=2, default=_convert, ensure_ascii=False)
        return

    wb = openpyxl.Workbook()

    header_font = Font(bold=True)
    header_fill = PatternFill(
        start_color="D9E1F2", end_color="D9E1F2", fill_type="solid"
    )
    pass_fill = PatternFill(
        start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"
    )
    warn_fill = PatternFill(
        start_color="FFEB9C", end_color="FFEB9C", fill_type="solid"
    )

    # --- Summary sheet ---
    ws = wb.active
    ws.title = "Summary"

    summary_rows = [
        ("Original", report.get("original", "")),
        ("Defaced", report.get("defaced", "")),
        ("Shape", str(report.get("shape", []))),
        ("Spacing (mm)", str(report.get("spacing_mm", []))),
        ("", ""),
        ("Global Dose Difference", ""),
    ]

    gd = report.get("global_diff", {})
    for key in ["max_diff", "mean_diff", "std_diff", "p95_diff", "n_nonzero_diff"]:
        val = gd.get(key, "")
        summary_rows.append((f"  {key}", str(val)))

    summary_rows.append(("", ""))
    summary_rows.append(("Gamma Analysis", ""))
    gamma = report.get("gamma", {})
    summary_rows.append(("  Criteria", gamma.get("criteria", "")))
    summary_rows.append(("  Pass Rate (%)", str(gamma.get("pass_rate", ""))))
    summary_rows.append(("  Dose Cutoff (%)", str(gamma.get("dose_cutoff_pct", ""))))

    for label, value in summary_rows:
        ws.append([label, value])

    # Bold first column
    for row_cells in ws.iter_rows(min_row=1, max_row=ws.max_row, max_col=1):
        for cell in row_cells:
            cell.font = Font(bold=True)

    ws.column_dimensions["A"].width = 25
    ws.column_dimensions["B"].width = 60

    # --- Per-ROI sheet ---
    roi_diffs = report.get("per_roi_diff", [])
    if roi_diffs:
        ws2 = wb.create_sheet("Per-ROI Differences")
        headers = [
            "ROI", "Volume (cc)", "Max Diff", "Mean Diff",
            "Std Diff", "P95 Diff", "P99 Diff", "N Nonzero",
        ]
        ws2.append(headers)
        for cell in ws2[1]:
            cell.font = header_font
            cell.fill = header_fill

        for rd in roi_diffs:
            row = [
                rd.get("roi_name", ""),
                rd.get("volume_cc", 0),
                round(rd.get("max_diff", 0), 4),
                round(rd.get("mean_diff", 0), 4),
                round(rd.get("std_diff", 0), 4),
                round(rd.get("p95_diff", 0), 4),
                round(rd.get("p99_diff", 0), 4),
                rd.get("n_nonzero_diff", 0),
            ]
            ws2.append(row)

            # Color max_diff cell
            max_diff = rd.get("max_diff", 0)
            row_idx = ws2.max_row
            cell = ws2.cell(row=row_idx, column=3)
            cell.fill = pass_fill if max_diff < 0.01 else warn_fill

        for i, w in enumerate([20, 12, 12, 12, 12, 12, 12, 12], 1):
            ws2.column_dimensions[chr(64 + i)].width = w

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(output_path))
    logger.info("Comparison report saved: %s", output_path)
