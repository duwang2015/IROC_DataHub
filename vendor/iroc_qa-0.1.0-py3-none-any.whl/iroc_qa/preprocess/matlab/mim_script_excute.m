% Specify the input and output directories
inputDir = 'C:\Upenn\Lab\IROC Service\HN\HN009\MIMinput';
outputDir = 'C:\Upenn\Lab\IROC Service\HN\HN009\MIMoutput';

% Get a list of all Excel files in the input directory
inputFiles = dir(fullfile(inputDir, '*.xlsx'));

% Loop over each file in the directory
for k = 1:length(inputFiles)
    % Construct the full path to the input file
    inputFile = fullfile(inputDir, inputFiles(k).name);
    
    % Define the output filename by changing the extension to .csv
    [~, name, ~] = fileparts(inputFiles(k).name);
    outputFile = fullfile(outputDir, strcat(name, '.csv'));
    
    % Execute the conversion function
    mim_script_auto_conversion(inputFile, outputFile);
    
    % Optionally, confirm each file has been processed
    fprintf('Processed %s\n', inputFiles(k).name);
end

% Print completion message
disp('All files have been processed.');
