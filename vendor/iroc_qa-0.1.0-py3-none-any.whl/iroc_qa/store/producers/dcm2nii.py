"""Run ``iroc_qa.preprocess.dcm2nii.process_case`` on a case as a derived run."""

from __future__ import annotations

import json
import logging
import shutil

from ..derived import DerivedRun, derive, series_refs
from ..store import CaseRef, Store
from .dicom_qc import build_series_groups

logger = logging.getLogger(__name__)
DCM2NII_VERSION = "1.0.0"   # bump when preprocess/dcm2nii.py changes behaviour
ROLES = {"CT": "ct", "MR": "mr", "PT": "pt", "RTDOSE": "rtdose", "RTSTRUCT": "rtstruct"}


def _tool():
    try:
        from iroc_qa.preprocess.dcm2nii import process_case
    except ImportError as exc:
        logger.warning("dcm2nii unavailable (%s); install iroc-qa[imaging]", exc)
        return None
    return process_case


def _kind_and_parents(name: str) -> tuple[str, str, list[str]]:
    n = name.lower()
    if n.endswith("_roi_mapping.json"):
        return "roi_mapping", "json", ["rtstruct"]
    if "rtstruct" in n:
        return "rtstruct_label", "nifti_label", ["rtstruct", "ct"]
    if "rtdose" in n:
        return "dose", "nifti_image", ["rtdose", "ct"]
    if "suv" in n or "_pet" in n:
        return "pet", "nifti_image", ["pt"]
    if "_ct" in n:
        return "ct", "nifti_image", ["ct"]
    if n.endswith((".nii", ".nii.gz")):
        return "mr", "nifti_image", ["mr"]
    return "other", "unknown", []


def run_dcm2nii(store: Store, case: CaseRef, batch: str | None = None, *,
                no_resample: bool = False, skip_suv: bool = False, roi_filter=None,
                skip_rtstruct: bool = False, force: bool = False) -> DerivedRun | None:
    process_case = _tool()
    if process_case is None:
        return None
    series = [s for s in series_refs(store, case, batch=batch) if s.modality in ROLES]
    if not series:
        return None
    inputs: dict[str, list] = {}
    for s in series:
        inputs.setdefault(ROLES[s.modality], []).append(s)
    params = {"no_resample": no_resample, "skip_suv": skip_suv,
              "roi_filter": sorted(roi_filter) if roi_filter else None,
              "skip_rtstruct": skip_rtstruct, "batch": series[0].batch}
    with derive(store, case, "dcm2nii", DCM2NII_VERSION, params, inputs, force=force) as run:
        if run.cached:
            return run
        groups = build_series_groups(series)
        report = process_case(case.case_id, groups, str(run.dir), no_resample=no_resample,
                              skip_suv=skip_suv, roi_filter=roi_filter,
                              skip_rtstruct=skip_rtstruct)
        case_out = run.dir / case.case_id
        if case_out.is_dir():                       # process_case nests outputs under case id
            for p in list(case_out.iterdir()):
                shutil.move(str(p), str(run.dir / p.name))
            case_out.rmdir()
        if report.get("roi_mapping"):
            mp = run.dir / f"{case.case_id}_roi_mapping.json"
            mp.write_text(json.dumps({str(k): v for k, v in report["roi_mapping"].items()},
                                     indent=1), encoding="utf-8")
        for p in sorted(run.dir.iterdir()):
            if p.is_file() and p.name not in ("run.log",):
                role, kind, parents = _kind_and_parents(p.name)
                run.add_output(role, p, kind, parents=[r for r in parents if r in inputs])
        run.log.info("dcm2nii %s: %s", case.case_id, ", ".join(report.get("nifti_files", [])))
    return run
