"""On-disk data store for IROC trial data: layout, catalog, inbox ingest, trial logs."""

from .config import ConfigError, StoreConfig, TrialRule, load_config, write_default_config
from .store import CaseRef, Store

__all__ = ["CaseRef", "ConfigError", "Store", "StoreConfig", "TrialRule", "load_config",
           "open_store", "write_default_config"]


def open_store(root=None, read_only: bool = False) -> Store:
    return Store.open(root, read_only=read_only)
