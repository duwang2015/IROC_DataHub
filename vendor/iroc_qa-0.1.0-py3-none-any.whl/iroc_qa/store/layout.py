"""Path building and Windows-safe name sanitisation for the on-disk store."""

from __future__ import annotations

import hashlib
import re
from datetime import date, datetime
from pathlib import Path

_ILLEGAL = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_RESERVED = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | \
    {f"LPT{i}" for i in range(1, 10)}

ORIGINAL_DIR = "original"
DERIVED_DIR = "derived"
DOCUMENTS_DIR = "documents"
IMAGES_DIR = "images"
MISC_DIR = "misc"
ARCHIVES_DIR = "archives"
BATCH_MANIFEST = "batch.json"
RUN_MANIFEST = "run.json"
CASE_PIN = "case.json"
TRIAL_LOG = "TRIAL_LOG.md"


def sanitize_component(s: str, max_len: int = 80) -> str:
    """Make ``s`` safe as a single Windows/NTFS/SMB path component."""
    s = _ILLEGAL.sub("_", str(s))
    s = re.sub(r"[\s_]+", "_", s)
    s = s.strip(". _")
    if not s:
        return "NA"
    stem = s.split(".")[0].upper()
    if stem in _RESERVED:
        s = "_" + s
    if len(s) > max_len:
        s = s[:max_len].rstrip(". _") or "NA"
    return s


def normalize_case_id(raw: str, mode: str = "upper_dash") -> str:
    s = str(raw).strip()
    if mode == "none":
        return s
    s = s.upper()
    if mode == "upper_dash":
        s = re.sub(r"[\s_]+", "-", s)
        s = re.sub(r"-{2,}", "-", s).strip("-")
    return s


def uid8(uid: str) -> str:
    return hashlib.sha1(uid.encode("utf-8")).hexdigest()[:8]


def series_dirname(modality_dir: str, series_number: int | None, desc: str,
                   desc_max_len: int = 40) -> str:
    num = f"{series_number:03d}" if isinstance(series_number, int) and series_number >= 0 \
        else "000"
    name = f"{modality_dir}_{num}"
    d = sanitize_component(desc, desc_max_len) if desc else ""
    if d and d != "NA":
        name += f"_{d}"
    return name


def instance_filename(prefix: str, instance_number: int | None, ext: str = ".dcm") -> str:
    n = instance_number if isinstance(instance_number, int) and instance_number >= 0 else 0
    return f"{prefix}{n:05d}{ext}"


def batch_dirname(day: date, seq_today: int) -> str:
    return f"batch-{day:%Y%m%d}-{seq_today:02d}"


BATCH_RX = re.compile(r"^batch-(\d{8})-(\d{2,})$")


def parse_batch_dirname(name: str) -> tuple[str, int] | None:
    m = BATCH_RX.match(name)
    if not m:
        return None
    return m.group(1), int(m.group(2))


def run_dirname(started_utc: datetime, run_hash: str) -> str:
    return f"{started_utc:%Y%m%dT%H%M%SZ}-{run_hash[:6]}"


def module_dirname(module: str, version: str) -> str:
    return f"{sanitize_component(module, 40)}@{sanitize_component(version, 20)}"


def unique_name(name: str, taken: set[str], suffix: str) -> str:
    """Return ``name`` or ``name_<suffix>`` so that it is unique in ``taken`` (case-insensitive).

    ``taken`` is updated with the chosen name (upper-cased).
    """
    cand = name
    if cand.upper() in taken:
        cand = f"{name}_{suffix}"
        i = 2
        while cand.upper() in taken:
            cand = f"{name}_{suffix}_{i}"
            i += 1
    taken.add(cand.upper())
    return cand


def unique_filename(name: str, taken: set[str]) -> str:
    """Explorer-style ``name (2).ext`` de-duplication, case-insensitive."""
    if name.upper() not in taken:
        taken.add(name.upper())
        return name
    p = Path(name)
    stem, ext = p.stem, p.suffix
    i = 2
    while True:
        cand = f"{stem} ({i}){ext}"
        if cand.upper() not in taken:
            taken.add(cand.upper())
            return cand
        i += 1


def fit_series_dirname(base_dir: Path, modality_dir: str, series_number: int | None,
                       desc: str, series_uid: str, desc_max_len: int, max_path: int,
                       filename_len: int = 12) -> str:
    """Pick a series dir name such that ``base_dir/<name>/<file>`` fits in ``max_path``."""
    budget = max_path - len(str(base_dir)) - 1 - filename_len - 1
    name = series_dirname(modality_dir, series_number, desc, desc_max_len)
    if len(name) <= budget:
        return name
    for n in (24, 12):
        name = series_dirname(modality_dir, series_number, desc, n)
        if len(name) <= budget:
            return name
    name = series_dirname(modality_dir, series_number, "", desc_max_len)
    if len(name) <= budget:
        return name
    return f"{modality_dir[:4]}_{uid8(series_uid)}"


def collection_dir(root: Path, site: str, collection_id: str) -> Path:
    return root / sanitize_component(site, 40) / sanitize_component(collection_id, 60)


def case_dir(root: Path, site: str, collection_id: str, case_id: str) -> Path:
    return collection_dir(root, site, collection_id) / sanitize_component(case_id, 60)


def rel(root: Path, path: Path) -> str:
    """Relative path with forward slashes, for manifests and the catalog."""
    return Path(path).resolve().relative_to(Path(root).resolve()).as_posix()
