"""Poll the inbox at a fixed interval. Prefer a scheduled ``ingest --if-idle`` on Windows."""

from __future__ import annotations

import logging
import time

from .ingest import Ingester
from .store import Store

logger = logging.getLogger(__name__)
STOP_FILE = "STOP"


def watch(store: Store, interval_seconds: int, once: bool = False, sleep=time.sleep) -> int:
    logger.info("watching %s every %ds (create %s/%s to stop)", store.cfg.inbox, interval_seconds,
                store.cfg.inbox, STOP_FILE)
    while True:
        stop = store.cfg.inbox / STOP_FILE
        if stop.exists():
            logger.info("stop file found; exiting")
            try:
                stop.unlink()
            except OSError:
                pass
            return 0
        try:
            # SMB connections drop; reopen the catalog each cycle
            store.catalog.close()
            rep = Ingester(store).run(if_idle=True)
            if rep.drops:
                logger.info("%s", rep.summary())
        except KeyboardInterrupt:
            return 0
        except Exception as exc:
            logger.exception("ingest cycle failed: %s", exc)
        if once:
            return 0
        try:
            sleep(interval_seconds)
        except KeyboardInterrupt:
            return 0
