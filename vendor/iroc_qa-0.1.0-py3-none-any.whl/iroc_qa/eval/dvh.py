"""DVH computation from NIfTI dose and ROI mask files.

Computes cumulative dose-volume histograms and standard dose-volume
metrics (Dmean, D95, V20Gy, etc.) directly from NIfTI files.  Designed
for the NIMOD defacing pipeline where all data is in NIfTI format.

Dose convention: cGy (matching dcm2nii.py output).
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path

import nibabel as nib
import numpy as np

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DVH dataclass
# ---------------------------------------------------------------------------

@dataclass
class DVH:
    """Cumulative dose-volume histogram."""

    dose_bins: np.ndarray        # Dose bin edges (cGy), length n_bins+1
    cum_volume: np.ndarray       # Cumulative volume (cc) at each bin, length n_bins+1
    diff_volume: np.ndarray      # Differential volume (cc) per bin, length n_bins
    total_volume_cc: float       # Total structure volume in cc
    roi_name: str = ""
    dose_unit: str = "cGy"

    @property
    def cum_volume_pct(self) -> np.ndarray:
        """Cumulative volume as percentage of total."""
        if self.total_volume_cc > 0:
            return self.cum_volume / self.total_volume_cc * 100.0
        return np.zeros_like(self.cum_volume)

    @property
    def dose_bin_centers(self) -> np.ndarray:
        """Center of each dose bin."""
        return (self.dose_bins[:-1] + self.dose_bins[1:]) / 2.0


# ---------------------------------------------------------------------------
# DVH computation
# ---------------------------------------------------------------------------

def _load_nifti(path: str | Path) -> tuple[np.ndarray, np.ndarray]:
    """Load NIfTI file, return (data, affine)."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"NIfTI not found: {path}")
    nii = nib.load(str(path))
    return nii.get_fdata(), nii.affine


def _voxel_volume_cc(affine: np.ndarray) -> float:
    """Compute voxel volume in cc from NIfTI affine matrix."""
    voxel_dims = np.sqrt(np.sum(affine[:3, :3] ** 2, axis=0))
    volume_mm3 = float(np.prod(voxel_dims))
    return volume_mm3 / 1000.0  # mm^3 -> cc


def compute_dvh(
    dose_path: str | Path,
    mask_path: str | Path,
    label: int | None = None,
    n_bins: int = 1000,
    roi_name: str = "",
) -> DVH:
    """Compute cumulative DVH from dose + ROI mask NIfTI files.

    Parameters
    ----------
    dose_path : path
        NIfTI dose file (values in cGy).
    mask_path : path
        NIfTI mask file.  Binary mask (>0.5) or label map.
    label : int, optional
        If mask is a label map, use this label value.
        If None, treat mask as binary (all nonzero voxels).
    n_bins : int
        Number of dose histogram bins.
    roi_name : str
        Name of the ROI for labeling.

    Returns
    -------
    DVH dataclass.
    """
    dose_data, dose_affine = _load_nifti(dose_path)
    mask_data, mask_affine = _load_nifti(mask_path)

    # Verify shapes match
    if dose_data.shape != mask_data.shape:
        raise ValueError(
            f"Shape mismatch: dose {dose_data.shape} vs mask {mask_data.shape}"
        )

    # Build boolean mask
    if label is not None:
        roi_mask = np.round(mask_data).astype(int) == label
    else:
        roi_mask = mask_data > 0.5

    n_voxels = int(roi_mask.sum())
    if n_voxels == 0:
        logger.warning("Empty ROI mask for '%s'", roi_name)
        empty_bins = np.linspace(0, 1, n_bins + 1)
        return DVH(
            dose_bins=empty_bins,
            cum_volume=np.zeros(n_bins + 1),
            diff_volume=np.zeros(n_bins),
            total_volume_cc=0.0,
            roi_name=roi_name,
        )

    # Extract dose values within ROI
    dose_in_roi = dose_data[roi_mask].astype(np.float64)
    voxel_cc = _voxel_volume_cc(dose_affine)
    total_cc = n_voxels * voxel_cc

    # Build histogram
    dose_max = float(dose_in_roi.max())
    dose_min = 0.0
    if dose_max <= 0:
        dose_max = 1.0

    bins = np.linspace(dose_min, dose_max * 1.01, n_bins + 1)
    diff_vol, _ = np.histogram(dose_in_roi, bins=bins)
    diff_vol_cc = diff_vol.astype(np.float64) * voxel_cc

    # Cumulative (reverse cumsum): volume receiving >= each dose
    cum_vol_cc = np.zeros(n_bins + 1)
    cum_vol_cc[:-1] = np.cumsum(diff_vol_cc[::-1])[::-1]

    return DVH(
        dose_bins=bins,
        cum_volume=cum_vol_cc,
        diff_volume=diff_vol_cc,
        total_volume_cc=total_cc,
        roi_name=roi_name,
    )


def compute_dvh_batch(
    dose_path: str | Path,
    label_path: str | Path,
    roi_mapping: dict[int, str] | str | Path,
    n_bins: int = 1000,
) -> dict[str, DVH]:
    """Compute DVH for all ROIs in a combined label map.

    Parameters
    ----------
    dose_path : path
        NIfTI dose file (cGy).
    label_path : path
        NIfTI label map (integer labels per voxel).
    roi_mapping : dict or path
        Label int → ROI name.  If path, reads JSON file.
    n_bins : int
        Number of dose bins.

    Returns
    -------
    dict mapping ROI name → DVH.
    """
    if isinstance(roi_mapping, (str, Path)):
        roi_mapping = Path(roi_mapping)
        if not roi_mapping.exists():
            raise FileNotFoundError(f"ROI mapping not found: {roi_mapping}")
        with open(roi_mapping, encoding="utf-8") as f:
            raw = json.load(f)
        roi_mapping = {int(k): v for k, v in raw.items()}

    dose_data, dose_affine = _load_nifti(dose_path)
    label_data, _ = _load_nifti(label_path)

    if dose_data.shape != label_data.shape:
        raise ValueError(
            f"Shape mismatch: dose {dose_data.shape} vs labels {label_data.shape}"
        )

    label_arr = np.round(label_data).astype(int)
    voxel_cc = _voxel_volume_cc(dose_affine)

    dvhs = {}
    for label_int, name in sorted(roi_mapping.items()):
        roi_mask = label_arr == label_int
        n_voxels = int(roi_mask.sum())

        if n_voxels == 0:
            logger.warning("Empty ROI: %s (label %d)", name, label_int)
            bins = np.linspace(0, 1, n_bins + 1)
            dvhs[name] = DVH(
                dose_bins=bins,
                cum_volume=np.zeros(n_bins + 1),
                diff_volume=np.zeros(n_bins),
                total_volume_cc=0.0,
                roi_name=name,
            )
            continue

        dose_in_roi = dose_data[roi_mask].astype(np.float64)
        total_cc = n_voxels * voxel_cc

        dose_max = float(dose_in_roi.max())
        if dose_max <= 0:
            dose_max = 1.0

        bins = np.linspace(0, dose_max * 1.01, n_bins + 1)
        diff_vol, _ = np.histogram(dose_in_roi, bins=bins)
        diff_vol_cc = diff_vol.astype(np.float64) * voxel_cc

        cum_vol_cc = np.zeros(n_bins + 1)
        cum_vol_cc[:-1] = np.cumsum(diff_vol_cc[::-1])[::-1]

        dvhs[name] = DVH(
            dose_bins=bins,
            cum_volume=cum_vol_cc,
            diff_volume=diff_vol_cc,
            total_volume_cc=total_cc,
            roi_name=name,
        )
        logger.info(
            "  DVH computed: %s (%d voxels, %.1f cc)",
            name, n_voxels, total_cc,
        )

    return dvhs


# ---------------------------------------------------------------------------
# DVH metrics
# ---------------------------------------------------------------------------

def dvh_mean(dvh: DVH) -> float:
    """Mean dose to structure (cGy)."""
    if dvh.total_volume_cc <= 0:
        return 0.0
    # Weighted average: sum(bin_center * diff_volume) / total_volume
    centers = dvh.dose_bin_centers
    return float(np.sum(centers * dvh.diff_volume) / dvh.total_volume_cc)


def dvh_min(dvh: DVH) -> float:
    """Minimum dose (D100%) — dose covering 100% of volume."""
    if dvh.total_volume_cc <= 0:
        return 0.0
    # First bin where cumulative volume < total (i.e., some volume starts)
    for i, vol in enumerate(dvh.cum_volume):
        if vol < dvh.total_volume_cc * 0.999:
            return float(dvh.dose_bins[max(0, i - 1)])
    return float(dvh.dose_bins[0])


def dvh_max(dvh: DVH) -> float:
    """Maximum dose (D0%) — highest dose in the structure."""
    if dvh.total_volume_cc <= 0:
        return 0.0
    # Last bin with nonzero differential volume
    nonzero = np.where(dvh.diff_volume > 0)[0]
    if len(nonzero) == 0:
        return 0.0
    return float(dvh.dose_bins[nonzero[-1] + 1])


def dvh_d_percent(dvh: DVH, percent: float) -> float:
    """D-metric: dose covering *percent*% of volume (cGy).

    E.g., dvh_d_percent(dvh, 95) returns D95.
    """
    if dvh.total_volume_cc <= 0:
        return 0.0
    target_cc = dvh.total_volume_cc * percent / 100.0
    return float(np.interp(target_cc, dvh.cum_volume[::-1], dvh.dose_bins[::-1]))


def dvh_d_cc(dvh: DVH, cc: float) -> float:
    """D-metric: dose at absolute volume *cc* (cGy).

    E.g., dvh_d_cc(dvh, 0.03) returns D0.03cc (near-max dose).
    """
    if dvh.total_volume_cc <= 0:
        return 0.0
    return float(np.interp(cc, dvh.cum_volume[::-1], dvh.dose_bins[::-1]))


def dvh_v_dose(dvh: DVH, dose_threshold: float) -> float:
    """V-metric: volume (%) receiving >= *dose_threshold* (cGy).

    E.g., dvh_v_dose(dvh, 2000) returns V20Gy (if dose in cGy).
    """
    if dvh.total_volume_cc <= 0:
        return 0.0
    vol_cc = float(np.interp(dose_threshold, dvh.dose_bins, dvh.cum_volume))
    return vol_cc / dvh.total_volume_cc * 100.0


def dvh_v_dose_cc(dvh: DVH, dose_threshold: float) -> float:
    """V-metric: absolute volume (cc) receiving >= *dose_threshold*."""
    if dvh.total_volume_cc <= 0:
        return 0.0
    return float(np.interp(dose_threshold, dvh.dose_bins, dvh.cum_volume))


def dvh_statistics(dvh: DVH) -> dict:
    """Compute standard DVH statistics.

    Returns dict with Dmin, Dmax, Dmean, D2, D50, D95, D98 (cGy)
    and V5Gy, V10Gy, V20Gy (%).
    """
    return {
        "roi_name": dvh.roi_name,
        "volume_cc": round(dvh.total_volume_cc, 2),
        "Dmin_cGy": round(dvh_min(dvh), 2),
        "Dmax_cGy": round(dvh_max(dvh), 2),
        "Dmean_cGy": round(dvh_mean(dvh), 2),
        "D2_cGy": round(dvh_d_percent(dvh, 2), 2),
        "D50_cGy": round(dvh_d_percent(dvh, 50), 2),
        "D95_cGy": round(dvh_d_percent(dvh, 95), 2),
        "D98_cGy": round(dvh_d_percent(dvh, 98), 2),
        "V5Gy_pct": round(dvh_v_dose(dvh, 500), 2),
        "V10Gy_pct": round(dvh_v_dose(dvh, 1000), 2),
        "V20Gy_pct": round(dvh_v_dose(dvh, 2000), 2),
    }


# ---------------------------------------------------------------------------
# Radiobiological dose metrics
# ---------------------------------------------------------------------------

def bed(
    total_dose: float,
    dose_per_fraction: float,
    alpha_beta: float,
) -> float:
    """Biologically Effective Dose (BED).

    BED = D * (1 + d / (alpha/beta))

    Parameters
    ----------
    total_dose : float
        Total prescribed dose (same units as output, e.g. cGy or Gy).
    dose_per_fraction : float
        Dose per fraction (same units as total_dose).
    alpha_beta : float
        Alpha/beta ratio (same units as dose).
        Common values: 10 Gy (tumors), 3 Gy (late tissue), 2 Gy (cord).

    Returns
    -------
    BED in same units as input dose.
    """
    if alpha_beta <= 0:
        raise ValueError(f"alpha_beta must be positive, got {alpha_beta}")
    return total_dose * (1.0 + dose_per_fraction / alpha_beta)


def eqd2(
    total_dose: float,
    dose_per_fraction: float,
    alpha_beta: float,
    ref_dose_per_fraction: float = 200.0,
) -> float:
    """Equivalent Dose in 2 Gy fractions (EQD2).

    EQD2 = D * (d + alpha/beta) / (d_ref + alpha/beta)

    All parameters must use the same dose unit.  With our cGy convention:
    ``ref_dose_per_fraction`` defaults to **200 cGy** (= 2 Gy).  Set to
    2.0 if working in Gy.

    Parameters
    ----------
    total_dose : float
        Total prescribed dose.
    dose_per_fraction : float
        Dose per fraction (same units).
    alpha_beta : float
        Alpha/beta ratio (same units).
    ref_dose_per_fraction : float
        Reference fraction dose (default 200 cGy = 2 Gy).

    Returns
    -------
    EQD2 in same units as input dose.
    """
    if alpha_beta <= 0:
        raise ValueError(f"alpha_beta must be positive, got {alpha_beta}")
    return total_dose * (dose_per_fraction + alpha_beta) / (
        ref_dose_per_fraction + alpha_beta)


def eqd2_array(
    dose_array: np.ndarray,
    n_fractions: int,
    alpha_beta: float,
    ref_dose_per_fraction: float = 200.0,
) -> np.ndarray:
    """Compute EQD2 for an entire dose distribution array.

    Parameters
    ----------
    dose_array : array
        Dose distribution (e.g. cGy per voxel).
    n_fractions : int
        Number of fractions.
    alpha_beta : float
        Alpha/beta ratio (same units as dose values).
    ref_dose_per_fraction : float
        Reference fraction dose (default 200 cGy = 2 Gy).

    Returns
    -------
    EQD2 array (same shape and units as input).
    """
    if alpha_beta <= 0:
        raise ValueError(f"alpha_beta must be positive, got {alpha_beta}")
    if n_fractions <= 0:
        raise ValueError(f"n_fractions must be positive, got {n_fractions}")
    d = dose_array.astype(np.float64) / n_fractions
    return dose_array * (d + alpha_beta) / (
        ref_dose_per_fraction + alpha_beta)


def dvh_eqd2_statistics(
    dvh: DVH,
    n_fractions: int,
    alpha_beta: float,
    ref_dose_per_fraction: float = 200.0,
) -> dict:
    """Compute EQD2-corrected DVH statistics.

    Applies EQD2 conversion to key dose metrics.

    Parameters
    ----------
    dvh : DVH
    n_fractions : int
        Number of fractions in the treatment plan.
    alpha_beta : float
        Alpha/beta ratio (same units as dose in DVH).
    ref_dose_per_fraction : float
        Reference fraction dose (default 200 cGy = 2 Gy).

    Returns
    -------
    dict with EQD2-corrected Dmin, Dmax, Dmean, D2, D95, D98 (same units).
    """
    stats = dvh_statistics(dvh)
    dose_keys = [k for k in stats if k.endswith("_cGy")]
    eqd2_stats = {"roi_name": dvh.roi_name, "n_fractions": n_fractions,
                   "alpha_beta": alpha_beta}

    for key in dose_keys:
        total_d = stats[key]
        d_per_fx = total_d / n_fractions if n_fractions > 0 else 0.0
        eqd2_val = (
            eqd2(total_d, d_per_fx, alpha_beta, ref_dose_per_fraction)
            if total_d > 0 else 0.0
        )
        eqd2_key = key.replace("_cGy", "_EQD2_cGy")
        eqd2_stats[eqd2_key] = round(eqd2_val, 2)

    return eqd2_stats


# ---------------------------------------------------------------------------
# DVH comparison
# ---------------------------------------------------------------------------

def compare_dvh(dvh_a: DVH, dvh_b: DVH) -> dict:
    """Compare two DVHs (e.g., original vs defaced).

    Returns dict with metric differences.
    """
    stats_a = dvh_statistics(dvh_a)
    stats_b = dvh_statistics(dvh_b)

    diffs = {"roi_name": dvh_a.roi_name}
    for key in stats_a:
        if key in ("roi_name", "volume_cc"):
            continue
        val_a = stats_a[key]
        val_b = stats_b[key]
        diffs[f"{key}_diff"] = round(val_b - val_a, 4)

    diffs["volume_cc_a"] = stats_a["volume_cc"]
    diffs["volume_cc_b"] = stats_b["volume_cc"]
    diffs["max_metric_diff"] = max(
        abs(v) for k, v in diffs.items()
        if k.endswith("_diff") and isinstance(v, (int, float))
    )

    return diffs


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

def export_dvh_csv(
    dvhs: dict[str, DVH],
    output_path: str | Path,
    n_points: int = 500,
):
    """Export DVH curves to CSV.

    Columns: Dose (cGy), ROI1_Volume_cc, ROI1_Volume_pct, ...
    Resamples all DVHs to a common dose axis.
    """
    output_path = Path(output_path)

    # Find global dose range
    all_max = max(
        (float(d.dose_bins[-1]) for d in dvhs.values() if d.total_volume_cc > 0),
        default=1.0,
    )
    common_dose = np.linspace(0, all_max, n_points)

    # Build columns
    lines = []
    header_parts = ["Dose (cGy)"]
    for name in sorted(dvhs.keys()):
        header_parts.append(f"{name} (cc)")
        header_parts.append(f"{name} (%)")
    lines.append(",".join(header_parts))

    for dose_val in common_dose:
        row = [f"{dose_val:.2f}"]
        for name in sorted(dvhs.keys()):
            dvh = dvhs[name]
            vol_cc = float(np.interp(dose_val, dvh.dose_bins, dvh.cum_volume))
            vol_pct = vol_cc / dvh.total_volume_cc * 100 if dvh.total_volume_cc > 0 else 0
            row.append(f"{vol_cc:.4f}")
            row.append(f"{vol_pct:.2f}")
        lines.append(",".join(row))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(lines), encoding="utf-8")
    logger.info("DVH CSV exported: %s (%d ROIs, %d points)", output_path,
                len(dvhs), n_points)


def plot_dvh(
    dvhs: dict[str, DVH],
    output_path: str | Path | None = None,
    title: str = "Dose-Volume Histogram",
    show: bool = False,
):
    """Plot DVH curves using matplotlib.

    Parameters
    ----------
    dvhs : dict[str, DVH]
    output_path : path, optional
        Save plot to file (PNG, PDF, etc.).
    title : str
    show : bool
        Call plt.show() interactively.
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        logger.warning("matplotlib not installed — cannot plot DVH")
        return

    fig, ax = plt.subplots(figsize=(10, 6))

    for name in sorted(dvhs.keys()):
        dvh = dvhs[name]
        if dvh.total_volume_cc <= 0:
            continue
        ax.plot(
            dvh.dose_bins,
            dvh.cum_volume_pct,
            label=f"{name} ({dvh.total_volume_cc:.1f} cc)",
            linewidth=1.5,
        )

    ax.set_xlabel(f"Dose ({dvhs[next(iter(dvhs))].dose_unit})")
    ax.set_ylabel("Volume (%)")
    ax.set_title(title)
    ax.set_ylim(0, 105)
    ax.set_xlim(left=0)
    ax.legend(loc="best", fontsize=8)
    ax.grid(True, alpha=0.3)

    if output_path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(str(output_path), dpi=150, bbox_inches="tight")
        logger.info("DVH plot saved: %s", output_path)

    if show:
        plt.show()
    else:
        plt.close(fig)
