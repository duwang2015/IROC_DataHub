"""Run ``iroc_qa.preprocess.dicom_qc.generate_qc_report`` on a batch as a derived run."""

from __future__ import annotations

import json
import logging

from ..derived import DerivedRun, SeriesRef, derive, series_refs
from ..store import CaseRef, Store

logger = logging.getLogger(__name__)
DICOM_QC_VERSION = "1.0.0"
DICOM_MODALITIES = ("CT", "MR", "PT", "RTSTRUCT", "RTDOSE", "RTPLAN")


def build_series_groups(series: list[SeriesRef]) -> dict:
    """``{series_uid: [(filepath, Dataset), ...]}`` as the preprocess tools expect."""
    import pydicom

    groups: dict = {}
    for s in series:
        for f in s.files:
            try:
                ds = pydicom.dcmread(str(f), stop_before_pixels=True, force=True)
            except Exception as exc:
                logger.warning("skipping unreadable %s: %s", f, exc)
                continue
            groups.setdefault(s.series_uid, []).append((str(f), ds))
    return groups


def _tool():
    try:
        from iroc_qa.preprocess.dicom_qc import generate_qc_report
    except ImportError as exc:
        logger.warning("dicom_qc unavailable (%s); install iroc-qa[imaging]", exc)
        return None
    return generate_qc_report


def run_dicom_qc(store: Store, case: CaseRef, batch: str | None = None,
                 force: bool = False) -> DerivedRun | None:
    generate_qc_report = _tool()
    if generate_qc_report is None:
        return None
    series = [s for s in series_refs(store, case, batch=batch)
              if s.modality in DICOM_MODALITIES]
    if not series:
        return None
    params = {"batch": series[0].batch}
    with derive(store, case, "dicom_qc", DICOM_QC_VERSION, params, {"series": series},
                force=force) as run:
        if run.cached:
            return run
        groups = build_series_groups(series)
        result = generate_qc_report(case.case_id, groups, str(run.dir / "qc_report.xlsx"))
        (run.dir / "qc_report.json").write_text(json.dumps(result, indent=1, default=str),
                                                encoding="utf-8")
        run.add_output("report", run.dir / "qc_report.json", "json", parents=["series"])
        if (run.dir / "qc_report.xlsx").exists():
            run.add_output("report_xlsx", run.dir / "qc_report.xlsx", "table_xlsx",
                           parents=["series"])
        run.log.info("QC %s: %s", case.case_id, result.get("overall_status"))
    return run
