"""Medical image display utilities for NIfTI data.

Side-by-side multi-modality comparison and overlay visualization
(RTSTRUCT contours on anatomy, dose wash on CT).  All functions
accept either NIfTI file paths or numpy arrays.

Modality conventions
--------------------
- CT : gray colormap, soft-tissue window (center=40, width=400 HU)
- MRI: gray colormap, p1–p99 dynamic range
- PET: hot colormap, 0 – p99 of nonzero
- Dose: jet colormap, 0 – p99 of nonzero (cGy)

Usage
-----
    from Eval.display import display_side_by_side, display_contour_overlay

    display_side_by_side(
        ["ct.nii.gz", "dose.nii.gz"],
        titles=["CT", "Dose"],
        output_path="comparison.png",
    )

    display_contour_overlay(
        "ct.nii.gz", "labels.nii.gz",
        roi_mapping={1: "GTV", 2: "Brainstem"},
        output_path="overlay.png",
    )
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path

import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
from scipy.ndimage import binary_erosion

logger = logging.getLogger(__name__)


# ============================================================================
# Modality presets
# ============================================================================

MODALITY_PRESETS = {
    "CT": {"cmap": "gray", "window": (40, 400)},
    "MRI": {"cmap": "gray", "window": None},
    "PET": {"cmap": "hot", "window": None},
    "DOSE": {"cmap": "jet", "window": None},
}

# Filename patterns for modality detection (case-insensitive)
_MODALITY_PATTERNS = [
    (r"(?:^|[_\-])CT(?:[_\-.]|$)", "CT"),
    (r"(?:^|[_\-])(?:MR|MRI|T1|T2|FLAIR|DWI|ADC|SWI|PD|STIR)(?:[_\-.]|$)", "MRI"),
    (r"(?:^|[_\-])(?:PET|SUV|PETCT)(?:[_\-.]|$)", "PET"),
    (r"(?:^|[_\-])(?:[Dd]ose|[Dd]ose[Mm]ap|dosemap)(?:[_\-.]|$)", "DOSE"),
]


# ============================================================================
# Helpers — loading and input normalization
# ============================================================================

def _load_nifti(
    path: str | Path,
) -> tuple[np.ndarray, np.ndarray, tuple[float, float, float]]:
    """Load NIfTI → (data, affine, spacing)."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"NIfTI not found: {path}")
    nii = nib.load(str(path))
    spacing = tuple(float(s) for s in nii.header.get_zooms()[:3])
    return nii.get_fdata(), nii.affine, spacing


def _normalize_input(
    image: str | Path | np.ndarray,
) -> tuple[np.ndarray, str]:
    """Accept path or ndarray → (data, filename_str)."""
    if isinstance(image, np.ndarray):
        return image, ""
    path = Path(image)
    data, _, _ = _load_nifti(path)
    return data, path.stem


# ============================================================================
# Modality detection and window/level
# ============================================================================

def detect_modality(data: np.ndarray, filename: str = "") -> str:
    """Auto-detect imaging modality from filename or value range.

    Priority: filename pattern > value-range heuristic.

    Returns one of: "CT", "MRI", "PET", "DOSE", "UNKNOWN".
    """
    # Filename-based detection
    stem = Path(filename).stem if filename else ""
    for pattern, modality in _MODALITY_PATTERNS:
        if re.search(pattern, stem, re.IGNORECASE):
            return modality

    # Value-range heuristics
    flat = data[data != 0] if np.any(data != 0) else data.ravel()
    if len(flat) == 0:
        return "UNKNOWN"

    has_negatives = float(flat.min()) < -100
    neg_frac = float((flat < 0).sum()) / max(len(flat), 1)

    if has_negatives and neg_frac > 0.05:
        return "CT"

    dmax = float(flat.max())
    dmean = float(flat.mean())

    # PET-SUV: typically 0-20
    if dmax < 50 and dmean < 10:
        return "PET"

    # Dose: float64, large values (cGy)
    if data.dtype == np.float64 and dmax > 1000:
        return "DOSE"

    # Default to MRI for positive-only images
    return "MRI"


def compute_window_level(
    data: np.ndarray,
    modality: str = "CT",
    window: tuple[float, float] | None = None,
) -> tuple[float, float]:
    """Compute (vmin, vmax) for display.

    Parameters
    ----------
    data : array
        Image data.
    modality : str
        "CT", "MRI", "PET", "DOSE".
    window : (center, width), optional
        Custom window.  Overrides preset.

    Returns
    -------
    (vmin, vmax) tuple.
    """
    if window is not None:
        center, width = window
        return center - width / 2, center + width / 2

    preset_win = MODALITY_PRESETS.get(modality, {}).get("window")
    if preset_win is not None:
        center, width = preset_win
        return center - width / 2, center + width / 2

    # Percentile-based for MRI, PET, Dose
    nonzero = data[data != 0]
    if len(nonzero) == 0:
        return 0.0, 1.0

    if modality == "PET":
        return 0.0, float(np.percentile(nonzero, 99))

    if modality == "DOSE":
        return 0.0, float(np.percentile(nonzero, 99))

    # MRI / default
    return float(np.percentile(nonzero, 1)), float(np.percentile(nonzero, 99))


# ============================================================================
# Slice extraction
# ============================================================================

_AXIS_MAP = {"axial": 2, "sagittal": 0, "coronal": 1}


def _extract_slice(data: np.ndarray, axis: str, index: int) -> np.ndarray:
    """Extract a 2D slice for display (transposed for imshow).

    Uses nibabel (x, y, z) ordering with .T and origin='lower'.
    """
    dim = _AXIS_MAP.get(axis, 2)
    slc = [slice(None)] * 3
    slc[dim] = index
    return data[tuple(slc)].T


def _select_slices(
    data: np.ndarray,
    axis: str,
    n_slices: int,
    mask: np.ndarray | None = None,
) -> list[int]:
    """Pick evenly-spaced slice indices along *axis*.

    If *mask* is provided, restrict to the mask's nonzero extent.
    """
    dim = _AXIS_MAP.get(axis, 2)
    n_total = data.shape[dim]

    if mask is not None and mask.any():
        # Find extent of mask along this axis
        axes_to_reduce = tuple(i for i in range(3) if i != dim)
        projection = np.any(mask, axis=axes_to_reduce)
        nonzero_idx = np.where(projection)[0]
        lo, hi = int(nonzero_idx[0]), int(nonzero_idx[-1])
    else:
        margin = max(1, n_total // 20)
        lo, hi = margin, n_total - margin - 1

    if hi <= lo:
        return [n_total // 2]

    indices = np.linspace(lo, hi, n_slices).astype(int).tolist()
    return indices


# ============================================================================
# ROI colors
# ============================================================================

def _get_roi_colors(n_rois: int) -> list[tuple[float, ...]]:
    """Generate distinct colors for ROIs using tab20 colormap."""
    cmap = plt.cm.get_cmap("tab20")
    return [cmap(i % 20) for i in range(n_rois)]


# ============================================================================
# Side-by-side display
# ============================================================================

def display_side_by_side(
    images: list[str | Path | np.ndarray],
    titles: list[str] | None = None,
    modalities: list[str] | None = None,
    axis: str = "axial",
    slice_index: int | None = None,
    window: tuple[float, float] | None = None,
    output_path: str | Path | None = None,
    show: bool = False,
    figsize: tuple[float, float] | None = None,
    dpi: int = 150,
) -> plt.Figure:
    """Display multiple images side by side on the same slice.

    Parameters
    ----------
    images : list
        NIfTI paths or numpy arrays (2–6 images).
    titles : list of str, optional
        Subplot titles.  Default: filename stems or "Image N".
    modalities : list of str, optional
        Per-image modality ("CT", "MRI", "PET", "DOSE").
        None = auto-detect.
    axis : str
        "axial", "sagittal", or "coronal".
    slice_index : int, optional
        Slice to display.  None = center of first image.
    window : (center, width), optional
        Custom window/level applied to ALL images.
    output_path : path, optional
        Save figure to file.
    show : bool
        Call plt.show().
    """
    n = len(images)
    loaded = [_normalize_input(img) for img in images]

    if titles is None:
        titles = [name or f"Image {i+1}" for i, (_, name) in enumerate(loaded)]
    if modalities is None:
        modalities = [
            detect_modality(d, name) for d, name in loaded
        ]

    dim = _AXIS_MAP.get(axis, 2)
    if slice_index is None:
        slice_index = loaded[0][0].shape[dim] // 2

    if figsize is None:
        figsize = (5 * n, 5)

    fig, axes = plt.subplots(1, n, figsize=figsize, dpi=dpi)
    if n == 1:
        axes = [axes]

    for i, (data, _) in enumerate(loaded):
        sl = _extract_slice(data, axis, slice_index)
        mod = modalities[i]
        cmap = MODALITY_PRESETS.get(mod, {}).get("cmap", "gray")
        vmin, vmax = compute_window_level(data, mod, window)

        axes[i].imshow(sl, cmap=cmap, vmin=vmin, vmax=vmax, origin="lower")
        axes[i].set_title(titles[i], fontsize=11)
        axes[i].axis("off")

    fig.suptitle(f"{axis.capitalize()} — slice {slice_index}", fontsize=12)
    plt.tight_layout()
    _save_or_show(fig, output_path, show, dpi)
    return fig


def display_montage(
    images: list[str | Path | np.ndarray],
    titles: list[str] | None = None,
    modalities: list[str] | None = None,
    axis: str = "axial",
    n_slices: int = 5,
    slice_indices: list[int] | None = None,
    window: tuple[float, float] | None = None,
    output_path: str | Path | None = None,
    show: bool = False,
    dpi: int = 150,
) -> plt.Figure:
    """Multi-slice montage: rows = images, columns = slices.

    Parameters
    ----------
    images : list
        NIfTI paths or numpy arrays.
    titles : list of str, optional
        Row labels.
    n_slices : int
        Number of slices (columns).
    slice_indices : list of int, optional
        Explicit slice indices.  None = auto evenly-spaced.
    """
    n_imgs = len(images)
    loaded = [_normalize_input(img) for img in images]

    if titles is None:
        titles = [name or f"Image {i+1}" for i, (_, name) in enumerate(loaded)]
    if modalities is None:
        modalities = [detect_modality(d, n) for d, n in loaded]

    if slice_indices is None:
        slice_indices = _select_slices(loaded[0][0], axis, n_slices)
    n_cols = len(slice_indices)

    fig, axes = plt.subplots(
        n_imgs, n_cols,
        figsize=(3.5 * n_cols, 3.5 * n_imgs),
        dpi=dpi,
    )
    if n_imgs == 1:
        axes = [axes]
    if n_cols == 1:
        axes = [[ax] for ax in axes]

    for r, (data, _) in enumerate(loaded):
        mod = modalities[r]
        cmap = MODALITY_PRESETS.get(mod, {}).get("cmap", "gray")
        vmin, vmax = compute_window_level(data, mod, window)

        for c, si in enumerate(slice_indices):
            sl = _extract_slice(data, axis, si)
            axes[r][c].imshow(
                sl, cmap=cmap, vmin=vmin, vmax=vmax, origin="lower",
            )
            axes[r][c].axis("off")
            if r == 0:
                axes[r][c].set_title(f"slice {si}", fontsize=9)
        axes[r][0].set_ylabel(titles[r], fontsize=10, rotation=0, labelpad=60)

    fig.suptitle(f"{axis.capitalize()} montage", fontsize=12)
    plt.tight_layout()
    _save_or_show(fig, output_path, show, dpi)
    return fig


def display_triplanar(
    image: str | Path | np.ndarray,
    title: str | None = None,
    modality: str | None = None,
    slice_indices: dict[str, int] | None = None,
    window: tuple[float, float] | None = None,
    output_path: str | Path | None = None,
    show: bool = False,
    dpi: int = 150,
) -> plt.Figure:
    """Tri-planar view: axial + sagittal + coronal.

    Parameters
    ----------
    image : path or array
    slice_indices : dict, optional
        {"axial": int, "sagittal": int, "coronal": int}.
        None = center slices.
    """
    data, name = _normalize_input(image)
    if title is None:
        title = name or "Image"
    if modality is None:
        modality = detect_modality(data, name)

    if slice_indices is None:
        slice_indices = {
            ax: data.shape[_AXIS_MAP[ax]] // 2
            for ax in ("axial", "sagittal", "coronal")
        }

    cmap = MODALITY_PRESETS.get(modality, {}).get("cmap", "gray")
    vmin, vmax = compute_window_level(data, modality, window)

    fig, axes = plt.subplots(1, 3, figsize=(18, 6), dpi=dpi)
    for i, ax_name in enumerate(("axial", "sagittal", "coronal")):
        si = slice_indices.get(ax_name, data.shape[_AXIS_MAP[ax_name]] // 2)
        sl = _extract_slice(data, ax_name, si)
        axes[i].imshow(sl, cmap=cmap, vmin=vmin, vmax=vmax, origin="lower")
        axes[i].set_title(f"{ax_name.capitalize()} — slice {si}", fontsize=11)
        axes[i].axis("off")

    fig.suptitle(title, fontsize=13)
    plt.tight_layout()
    _save_or_show(fig, output_path, show, dpi)
    return fig


# ============================================================================
# Overlay — contour
# ============================================================================

def _extract_contours(
    label_slice: np.ndarray,
    labels: list[int],
) -> dict[int, np.ndarray]:
    """Extract contour boundaries for each label in a 2D slice.

    Returns dict: label_int → boolean boundary array.
    """
    contours = {}
    for lbl in labels:
        mask = label_slice == lbl
        if not mask.any():
            continue
        eroded = binary_erosion(mask, iterations=1)
        boundary = mask & ~eroded
        if boundary.any():
            contours[lbl] = boundary
    return contours


def display_contour_overlay(
    anatomy: str | Path | np.ndarray,
    label_map: str | Path | np.ndarray,
    roi_mapping: dict[int, str] | str | Path | None = None,
    axis: str = "axial",
    slice_index: int | None = None,
    n_slices: int = 1,
    modality: str | None = None,
    window: tuple[float, float] | None = None,
    linewidth: float = 1.5,
    output_path: str | Path | None = None,
    show: bool = False,
    dpi: int = 150,
) -> plt.Figure:
    """Display RTSTRUCT contour overlay on anatomical image.

    Parameters
    ----------
    anatomy : path or array
        Background image (CT, MRI).
    label_map : path or array
        Integer label map (each int = one ROI).
    roi_mapping : dict, JSON path, or None
        Label int → ROI name.  None = auto "ROI-N".
    axis : str
    slice_index : int, optional
    n_slices : int
        If > 1, display multiple slices side by side.
    modality : str, optional
    linewidth : float
        Contour line width (rendered by dilation).
    """
    anat_data, anat_name = _normalize_input(anatomy)
    lbl_data, _ = _normalize_input(label_map)
    lbl_arr = np.round(lbl_data).astype(int)

    if anat_data.shape != lbl_arr.shape:
        raise ValueError(
            f"Shape mismatch: anatomy {anat_data.shape} "
            f"vs labels {lbl_arr.shape}"
        )

    roi_mapping = _resolve_roi_mapping(roi_mapping, lbl_arr)
    if modality is None:
        modality = detect_modality(anat_data, anat_name)

    labels = sorted(roi_mapping.keys())
    colors = _get_roi_colors(len(labels))
    color_map = dict(zip(labels, colors))

    # Select slices
    if n_slices == 1:
        if slice_index is None:
            slice_index = _find_label_center(lbl_arr, axis)
        slice_list = [slice_index]
    else:
        mask = lbl_arr > 0
        slice_list = _select_slices(anat_data, axis, n_slices, mask=mask)

    fig, axes = plt.subplots(
        1, len(slice_list),
        figsize=(5 * len(slice_list), 5),
        dpi=dpi,
    )
    if len(slice_list) == 1:
        axes = [axes]

    vmin, vmax = compute_window_level(anat_data, modality, window)
    cmap = MODALITY_PRESETS.get(modality, {}).get("cmap", "gray")

    for col, si in enumerate(slice_list):
        anat_sl = _extract_slice(anat_data, axis, si)
        lbl_sl = _extract_slice(lbl_arr, axis, si)
        _render_slice_with_contours(
            axes[col], anat_sl, lbl_sl, labels, color_map,
            cmap, vmin, vmax, linewidth,
        )
        axes[col].set_title(f"slice {si}", fontsize=10)
        axes[col].axis("off")

    _add_roi_legend(fig, labels, color_map, roi_mapping)
    fig.suptitle(f"Contour Overlay — {axis.capitalize()}", fontsize=12, y=1.02)
    plt.tight_layout()
    _save_or_show(fig, output_path, show, dpi)
    return fig


def _render_slice_with_contours(
    ax: plt.Axes,
    anat_sl: np.ndarray,
    lbl_sl: np.ndarray,
    labels: list[int],
    color_map: dict,
    cmap: str,
    vmin: float,
    vmax: float,
    linewidth: float,
) -> None:
    """Render anatomy + contour overlays on a single axes."""
    ax.imshow(anat_sl, cmap=cmap, vmin=vmin, vmax=vmax, origin="lower")

    contours = _extract_contours(lbl_sl, labels)
    if not contours:
        return

    # Build RGBA overlay
    h, w = anat_sl.shape
    overlay = np.zeros((h, w, 4), dtype=np.float32)

    # Thicken contours if linewidth > 1
    iterations = max(1, int(linewidth))
    for lbl, boundary in contours.items():
        if iterations > 1:
            from scipy.ndimage import binary_dilation
            boundary = binary_dilation(boundary, iterations=iterations - 1)
        rgba = color_map[lbl]
        overlay[boundary, :3] = rgba[:3]
        overlay[boundary, 3] = 0.9

    ax.imshow(overlay, origin="lower")


def _add_roi_legend(
    fig: plt.Figure,
    labels: list[int],
    color_map: dict,
    roi_mapping: dict[int, str],
) -> None:
    """Add ROI color legend below the figure."""
    import matplotlib.patches as mpatches
    patches = [
        mpatches.Patch(color=color_map[lbl], label=roi_mapping[lbl])
        for lbl in labels
    ]
    fig.legend(
        handles=patches, loc="lower center",
        ncol=min(len(patches), 5), fontsize=8,
        bbox_to_anchor=(0.5, -0.05),
    )


def _find_label_center(lbl_arr: np.ndarray, axis: str) -> int:
    """Find the slice with the most labeled voxels."""
    dim = _AXIS_MAP.get(axis, 2)
    axes_to_sum = tuple(i for i in range(3) if i != dim)
    counts = np.sum(lbl_arr > 0, axis=axes_to_sum)
    return int(np.argmax(counts))


def _resolve_roi_mapping(
    roi_mapping: dict[int, str] | str | Path | None,
    lbl_arr: np.ndarray,
) -> dict[int, str]:
    """Resolve ROI mapping from various input types."""
    if roi_mapping is None:
        unique = sorted(set(lbl_arr[lbl_arr > 0].astype(int).ravel()))
        return {int(v): f"ROI-{v}" for v in unique}

    if isinstance(roi_mapping, (str, Path)):
        path = Path(roi_mapping)
        if not path.exists():
            raise FileNotFoundError(f"ROI mapping not found: {path}")
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
        return {int(k): v for k, v in raw.items()}

    return roi_mapping


# ============================================================================
# Overlay — dose wash
# ============================================================================

def display_dose_wash(
    ct_image: str | Path | np.ndarray,
    dose_image: str | Path | np.ndarray,
    axis: str = "axial",
    slice_index: int | None = None,
    n_slices: int = 1,
    dose_threshold_pct: float = 5.0,
    alpha: float = 0.4,
    ct_window: tuple[float, float] | None = None,
    output_path: str | Path | None = None,
    show: bool = False,
    dpi: int = 150,
) -> plt.Figure:
    """Semi-transparent dose color wash overlay on grayscale CT.

    Parameters
    ----------
    ct_image : path or array
    dose_image : path or array (same shape as CT, cGy)
    dose_threshold_pct : float
        Minimum dose as % of max to display (below = transparent).
    alpha : float
        Dose overlay transparency (0=invisible, 1=opaque).
    ct_window : (center, width), optional
        CT window/level.  Default: soft-tissue (40, 400).
    """
    ct_data, _ = _normalize_input(ct_image)
    dose_data, _ = _normalize_input(dose_image)

    if ct_data.shape != dose_data.shape:
        raise ValueError(
            f"Shape mismatch: CT {ct_data.shape} vs Dose {dose_data.shape}"
        )

    dose_max = float(dose_data.max())
    if dose_max <= 0:
        logger.warning("Dose max is <= 0 — nothing to display")

    # Select slices
    if n_slices == 1:
        if slice_index is None:
            slice_index = _find_dose_center(dose_data, axis)
        slice_list = [slice_index]
    else:
        mask = dose_data > (dose_max * dose_threshold_pct / 100.0)
        slice_list = _select_slices(ct_data, axis, n_slices, mask=mask)

    fig, axes = plt.subplots(
        1, len(slice_list),
        figsize=(5 * len(slice_list), 5),
        dpi=dpi,
    )
    if len(slice_list) == 1:
        axes = [axes]

    vmin, vmax = compute_window_level(ct_data, "CT", ct_window)
    dose_cutoff = dose_max * dose_threshold_pct / 100.0
    mappable = None

    for col, si in enumerate(slice_list):
        ct_sl = _extract_slice(ct_data, axis, si)
        dose_sl = _extract_slice(dose_data, axis, si)
        mappable = _render_dose_wash_slice(
            axes[col], ct_sl, dose_sl, vmin, vmax,
            dose_max, dose_cutoff, alpha,
        )
        axes[col].set_title(f"slice {si}", fontsize=10)
        axes[col].axis("off")

    if mappable is not None:
        cbar = fig.colorbar(mappable, ax=axes, shrink=0.8, pad=0.02)
        cbar.set_label("Dose (cGy)", fontsize=10)

    fig.suptitle(f"Dose Wash — {axis.capitalize()}", fontsize=12)
    plt.tight_layout()
    _save_or_show(fig, output_path, show, dpi)
    return fig


def _render_dose_wash_slice(
    ax: plt.Axes,
    ct_sl: np.ndarray,
    dose_sl: np.ndarray,
    vmin: float,
    vmax: float,
    dose_max: float,
    dose_cutoff: float,
    alpha: float,
) -> plt.cm.ScalarMappable | None:
    """Render CT + dose wash on a single axes."""
    ax.imshow(ct_sl, cmap="gray", vmin=vmin, vmax=vmax, origin="lower")

    if dose_max <= 0:
        return None

    # Normalize dose to [0, 1]
    dose_norm = np.clip(dose_sl / dose_max, 0, 1)

    # Create RGBA overlay using jet colormap
    jet = plt.cm.get_cmap("jet")
    rgba = jet(dose_norm)

    # Make sub-threshold regions transparent
    rgba[..., 3] = np.where(dose_sl >= dose_cutoff, alpha, 0.0)

    ax.imshow(rgba, origin="lower")

    # Return ScalarMappable for colorbar
    sm = plt.cm.ScalarMappable(
        cmap="jet",
        norm=plt.Normalize(vmin=0, vmax=dose_max),
    )
    return sm


def _find_dose_center(dose_data: np.ndarray, axis: str) -> int:
    """Find the slice with the highest mean dose."""
    dim = _AXIS_MAP.get(axis, 2)
    axes_to_mean = tuple(i for i in range(3) if i != dim)
    means = np.mean(dose_data, axis=axes_to_mean)
    return int(np.argmax(means))


# ============================================================================
# Combined overlay — dose wash + contours
# ============================================================================

def display_dose_wash_with_contours(
    ct_image: str | Path | np.ndarray,
    dose_image: str | Path | np.ndarray,
    label_map: str | Path | np.ndarray,
    roi_mapping: dict[int, str] | str | Path | None = None,
    axis: str = "axial",
    slice_index: int | None = None,
    dose_threshold_pct: float = 5.0,
    alpha: float = 0.4,
    ct_window: tuple[float, float] | None = None,
    linewidth: float = 1.5,
    output_path: str | Path | None = None,
    show: bool = False,
    dpi: int = 150,
) -> plt.Figure:
    """Combined dose wash + ROI contour overlay on CT.

    Parameters
    ----------
    ct_image : path or array
    dose_image : path or array
    label_map : path or array
    roi_mapping : dict, JSON path, or None
    """
    ct_data, _ = _normalize_input(ct_image)
    dose_data, _ = _normalize_input(dose_image)
    lbl_data, _ = _normalize_input(label_map)
    lbl_arr = np.round(lbl_data).astype(int)

    for name, arr in [("Dose", dose_data), ("Labels", lbl_arr)]:
        if ct_data.shape != arr.shape:
            raise ValueError(
                f"Shape mismatch: CT {ct_data.shape} vs {name} {arr.shape}"
            )

    roi_mapping = _resolve_roi_mapping(roi_mapping, lbl_arr)
    labels = sorted(roi_mapping.keys())
    colors = _get_roi_colors(len(labels))
    color_map = dict(zip(labels, colors))

    dose_max = float(dose_data.max())
    dose_cutoff = dose_max * dose_threshold_pct / 100.0

    if slice_index is None:
        slice_index = _find_label_center(lbl_arr, axis)

    fig, ax = plt.subplots(1, 1, figsize=(7, 7), dpi=dpi)
    vmin, vmax = compute_window_level(ct_data, "CT", ct_window)

    # Layer 1: CT
    ct_sl = _extract_slice(ct_data, axis, slice_index)
    ax.imshow(ct_sl, cmap="gray", vmin=vmin, vmax=vmax, origin="lower")

    # Layer 2: Dose wash
    dose_sl = _extract_slice(dose_data, axis, slice_index)
    mappable = _render_dose_wash_slice(
        ax, ct_sl, dose_sl, vmin, vmax,
        dose_max, dose_cutoff, alpha,
    )

    # Layer 3: Contours
    lbl_sl = _extract_slice(lbl_arr, axis, slice_index)
    contours = _extract_contours(lbl_sl, labels)
    if contours:
        h, w = ct_sl.shape
        overlay = np.zeros((h, w, 4), dtype=np.float32)
        iterations = max(1, int(linewidth))
        for lbl, boundary in contours.items():
            if iterations > 1:
                from scipy.ndimage import binary_dilation
                boundary = binary_dilation(boundary, iterations=iterations - 1)
            rgba = color_map[lbl]
            overlay[boundary, :3] = rgba[:3]
            overlay[boundary, 3] = 0.9
        ax.imshow(overlay, origin="lower")

    ax.set_title(
        f"Dose + Contours — {axis.capitalize()} slice {slice_index}",
        fontsize=11,
    )
    ax.axis("off")

    if mappable is not None:
        cbar = fig.colorbar(mappable, ax=ax, shrink=0.8, pad=0.02)
        cbar.set_label("Dose (cGy)", fontsize=10)

    _add_roi_legend(fig, labels, color_map, roi_mapping)
    plt.tight_layout()
    _save_or_show(fig, output_path, show, dpi)
    return fig


# ============================================================================
# Save / show helper
# ============================================================================

def _save_or_show(
    fig: plt.Figure,
    output_path: str | Path | None,
    show: bool,
    dpi: int,
) -> None:
    """Save figure to file and/or display interactively."""
    if output_path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(str(output_path), dpi=dpi, bbox_inches="tight")
        logger.info("Saved: %s", output_path)

    if show:
        plt.show()
    elif not output_path:
        # Neither saving nor showing — close to avoid memory leak
        plt.close(fig)
