"""DVH extraction and metric computation.

Reads cumulative DVH CSV files (one column per structure) and computes
standard dose-volume metrics: mean dose, V-dose, D-volume.

Ported from DPS_v2 notebook (IROC Service).
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd


def extract_dvh(
    file_path: str | Path,
    structure_name: str,
) -> tuple[pd.DataFrame, str]:
    """Extract a single structure's DVH from a CSV file.

    The CSV is expected to have a dose column (first column) and one or more
    structure volume columns.  Column matching is case-insensitive and allows
    trailing characters (e.g. ``"PTV_6000 (1)"`` matches ``"PTV_6000"``).

    Parameters
    ----------
    file_path : str or Path
        Path to the cumulative DVH CSV.
    structure_name : str
        Exact structure name prefix to match (e.g. ``"CTV_6000"``).

    Returns
    -------
    dvh_df : DataFrame
        Two-column DataFrame with ``"Dose (Gy)"`` and the matched volume column.
    actual_col : str
        Actual column name that was matched.

    Raises
    ------
    ValueError
        If no column matches *structure_name*.
    """
    df = pd.read_csv(file_path, skiprows=1, header=0)
    df = df.reset_index(drop=True)

    # Clean column names: strip whitespace, remove " (1)" suffixes
    df.columns = (
        df.columns.astype(str).str.strip().str.replace(r"\s\(\d+\)", "", regex=True)
    )

    # First column is always dose
    dose_column = df.columns[0]
    df.rename(columns={dose_column: "Dose (Gy)"}, inplace=True)

    # Match structure by prefix (case-insensitive)
    pattern = r"^" + re.escape(structure_name)
    matched_col = None
    for col in df.columns:
        if col != "Dose (Gy)" and re.match(pattern, col, re.IGNORECASE):
            matched_col = col
            break

    if not matched_col:
        raise ValueError(
            f"Structure '{structure_name}' not found in {file_path}."
        )

    # Drop NaN rows and return clean two-column DataFrame
    mask = df["Dose (Gy)"].notna() & df[matched_col].notna()
    dvh_df = pd.DataFrame({
        "Dose (Gy)": df.loc[mask, "Dose (Gy)"].reset_index(drop=True),
        matched_col: df.loc[mask, matched_col].reset_index(drop=True),
    })
    return dvh_df, matched_col


def get_total_volume(dvh: pd.DataFrame, vol_col: str) -> float:
    """Return total organ volume (first value in the volume column)."""
    return float(dvh[vol_col].iloc[0])


def compute_mean_dose(
    dvh: pd.DataFrame, total_volume: float, vol_col: str,
) -> float:
    """Compute mean dose via trapezoidal integration of the cumulative DVH."""
    dose = dvh["Dose (Gy)"].to_numpy()
    volume = dvh[vol_col].to_numpy()
    integrated = np.trapezoid(volume, dose)
    return abs(integrated / total_volume)


def volume_at_threshold(
    dvh: pd.DataFrame, threshold_gy: float, vol_col: str,
) -> float:
    """Return absolute volume (cc) receiving >= *threshold_gy*."""
    rows = dvh[dvh["Dose (Gy)"] >= threshold_gy]
    if not rows.empty:
        return float(rows[vol_col].iloc[0])
    return 0.0


def dose_at_volume_fraction(
    dvh: pd.DataFrame,
    fraction: float,
    total_volume: float,
    vol_col: str,
) -> float:
    """Return dose (Gy) at which cumulative volume = *fraction* of total.

    Uses linear interpolation on the cumulative DVH curve.
    """
    target_volume = fraction * total_volume
    dose = dvh["Dose (Gy)"].to_numpy()
    volume = dvh[vol_col].to_numpy()
    if volume[0] > volume[-1]:
        dose = dose[::-1]
        volume = volume[::-1]
    return float(np.interp(target_volume, volume, dose))


def dose_at_absolute_volume(
    dvh: pd.DataFrame, abs_volume_cc: float, vol_col: str,
) -> float:
    """Return dose (Gy) where cumulative volume = *abs_volume_cc* (cc).

    Uses linear interpolation on the cumulative DVH curve.
    """
    dose = dvh["Dose (Gy)"].to_numpy()
    volume = dvh[vol_col].to_numpy()
    if volume[0] > volume[-1]:
        dose = dose[::-1]
        volume = volume[::-1]
    return float(np.interp(abs_volume_cc, volume, dose))
