using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;

namespace VMS.TPS
{
  public class Script
  {
    public void Execute(ScriptContext context)
    {
      if (context.PlanSetup == null || !context.PlanSetup.IsDoseValid)
      {
        MessageBox.Show("No valid dose found.");
        return;
      }

      PlanSetup plan = context.PlanSetup;

      // Define the structures and metrics we care about
      var structureMetrics = new Dictionary<string, List<string>>
      {
        { "Spinal cord", new List<string> { "Dmean", "D0.03cc" } },
        { "Parotid glands", new List<string> { "Dmean", "D50%" } },
        { "Glottic larynx", new List<string> { "D0.03cc" } },
        { "Brachial plexus", new List<string> { "D0.03cc" } },
        { "PTVHD", new List<string> { "D20%", "D1%", "D95%" } },
        { "PTVED", new List<string> { "D1%" } },
        { "E-PTVs", new List<string> { "D1%" } },
      };

      var output = new List<string>();
      var header = "Structure,Dmean (Gy),D0.03cc (Gy),D1% (Gy),D20% (Gy),D50% (Gy),D95% (Gy)";
      output.Add(header);

      foreach (var entry in structureMetrics)
      {
        string structId = entry.Key;
        Structure structure = plan.StructureSet.Structures.FirstOrDefault(s => s.Id.Equals(structId, StringComparison.OrdinalIgnoreCase));
        string[] row = new string[] { structId, "", "", "", "", "", "" };

        if (structure != null)
        {
          DVHData dvh = plan.GetDVHCumulativeData(structure, DoseValuePresentation.Absolute, VolumePresentation.Relative, 0.1);
          if (dvh != null)
          {
            foreach (string metric in entry.Value)
            {
              if (metric == "Dmean") row[1] = dvh.MeanDose.Dose.ToString("F2");
              else if (metric == "D0.03cc") row[2] = plan.GetDoseAtVolume(structure, 0.03, VolumePresentation.AbsoluteCm3, DoseValuePresentation.Absolute).Dose.ToString("F2");
              else if (metric == "D1%") row[3] = plan.GetDoseAtVolume(structure, 1.0, VolumePresentation.Relative, DoseValuePresentation.Absolute).Dose.ToString("F2");
              else if (metric == "D20%") row[4] = plan.GetDoseAtVolume(structure, 20.0, VolumePresentation.Relative, DoseValuePresentation.Absolute).Dose.ToString("F2");
              else if (metric == "D50%") row[5] = plan.GetDoseAtVolume(structure, 50.0, VolumePresentation.Relative, DoseValuePresentation.Absolute).Dose.ToString("F2");
              else if (metric == "D95%") row[6] = plan.GetDoseAtVolume(structure, 95.0, VolumePresentation.Relative, DoseValuePresentation.Absolute).Dose.ToString("F2");
            }
          }
        }

        output.Add(string.Join(",", row));
      }

      Microsoft.Win32.SaveFileDialog dialog = new Microsoft.Win32.SaveFileDialog();
      dialog.Filter = "CSV files (*.csv)|*.csv";
      dialog.Title = "Save DVH Summary CSV";
      dialog.FileName = string.Format("DVH_Summary_{0:yyyyMMdd_HHmmss}.csv", DateTime.Now);

      bool? result = dialog.ShowDialog();
      if (result == true)
      {
        File.WriteAllLines(dialog.FileName, output);
        MessageBox.Show("DVH summary exported to: " + dialog.FileName);
      }
    }
  }
}
