"""Producers: thin adapters that run existing iroc_qa tools through ``store.derive``."""

from __future__ import annotations

import logging

from ..store import CaseRef, Store

logger = logging.getLogger(__name__)

NAMES = ("dicom_qc", "dcm2nii")


def run_named(store: Store, name: str, case: CaseRef, batch_id: str | None = None) -> None:
    """Hook used after each ingested batch (``ingest.on_ingest``)."""
    batch = batch_id.rsplit("/", 1)[-1] if batch_id else None
    if name == "dicom_qc":
        from .dicom_qc import run_dicom_qc

        run_dicom_qc(store, case, batch=batch)
    elif name == "dcm2nii":
        from .dcm2nii import run_dcm2nii

        run_dcm2nii(store, case, batch=batch)
    else:
        logger.warning("unknown on_ingest producer %r (known: %s)", name, ", ".join(NAMES))


def run_named_cli(store: Store, args) -> int:
    case = store.case(args.trial, args.case)
    if store.catalog.get_case(case.pk) is None:
        print(f"unknown case {case.pk}")
        return 1
    if args.producer == "dicom-qc":
        from .dicom_qc import run_dicom_qc

        run = run_dicom_qc(store, case, batch=args.batch, force=args.force)
    else:
        from .dcm2nii import run_dcm2nii

        run = run_dcm2nii(store, case, batch=args.batch, no_resample=args.no_resample,
                          skip_suv=args.skip_suv, skip_rtstruct=args.skip_rtstruct,
                          force=args.force)
    if run is None:
        print("nothing to run (no matching series or tool unavailable)")
        return 2
    print(f"{'cached' if run.cached else 'completed'}: {run.dir}")
    return 0
