"""Check the catalog against the tree: existence, size, hashes, orphans."""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from .fsutil import iter_files, sha256_file
from .layout import BATCH_MANIFEST
from .store import Store


@dataclass
class VerifyReport:
    checked: int = 0
    hashed: int = 0
    problems: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.problems

    def summary(self) -> str:
        head = f"verified {self.checked} catalog files ({self.hashed} hashed): " + \
            ("OK" if self.ok else f"{len(self.problems)} problem(s)")
        return "\n".join([head] + [f"  {p}" for p in self.problems[:200]])


def verify(store: Store, trial: str | None = None, case_id: str | None = None,
           sample: int | None = None, full_hash: bool = True) -> VerifyReport:
    rep = VerifyReport()
    cat = store.catalog
    sql = "SELECT rel_path, size, sha256, case_pk FROM file"
    args: list = []
    if trial and case_id:
        sql += " WHERE case_pk=?"
        args.append(store.case(trial, case_id).pk)
    elif trial:
        sql += " WHERE case_pk LIKE ?"
        args.append(store.cfg.trial(trial).id + "/%")
    rows = cat.conn.execute(sql, args).fetchall()
    to_hash = set(range(len(rows)))
    if sample is not None and sample < len(rows):
        to_hash = set(random.sample(range(len(rows)), sample))
    for i, (rel, size, sha, _) in enumerate(rows):
        p = store.abs(rel)
        rep.checked += 1
        if not p.exists():
            rep.problems.append(f"missing: {rel}")
            continue
        if p.stat().st_size != size:
            rep.problems.append(f"size mismatch: {rel}")
            continue
        if full_hash and i in to_hash:
            rep.hashed += 1
            if sha256_file(p) != sha:
                rep.problems.append(f"sha256 mismatch: {rel}")
    known = {r[0].lower() for r in cat.conn.execute("SELECT rel_path FROM file")}
    pattern = f"{store.cfg.trial(trial).id}/*/original/batch-*" if trial else "*/*/original/batch-*"
    for bdir in store.root.glob(pattern):
        if not bdir.is_dir():
            continue
        for f in iter_files(bdir):
            rel = store.rel(f)
            if f.name == BATCH_MANIFEST:
                continue
            if rel.lower() not in known:
                rep.problems.append(f"orphan: {rel}")
    return rep
