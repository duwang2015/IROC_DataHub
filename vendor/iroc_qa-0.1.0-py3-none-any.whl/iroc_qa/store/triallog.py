"""Per-trial append-only log: ``<trial>/TRIAL_LOG.md`` mirrored into the catalog.

The file is the source of truth; the catalog table only indexes it. Lines look like::

    | 2026-10-01T14:30Z | hdu@IROC-WS07 | ingest | BN011-0007 | batch-20261001-01: CT x2 ... |
"""

from __future__ import annotations

import json
import re
import socket
from datetime import datetime, timezone
from pathlib import Path

from .fsutil import append_line
from .layout import TRIAL_LOG, sanitize_component
from .lock import StoreLock, _username

ACTIONS = ("note", "ingest", "holding", "resolve", "derive", "export", "access", "current",
           "discard")
_LINE = re.compile(r"^\|\s*(?P<at>[^|]+?)\s*\|\s*(?P<who>[^|]+?)\s*\|\s*(?P<action>[^|]+?)\s*\|"
                   r"\s*(?P<case>[^|]*?)\s*\|\s*(?P<msg>.*?)\s*\|\s*$")


def _esc(s: str) -> str:
    return str(s).replace("\\", "\\\\").replace("|", "\\|").replace("\n", " ")


def _unesc(s: str) -> str:
    return s.replace("\\|", "|").replace("\\\\", "\\")


def header_text(trial_id: str) -> str:
    return (f"# {trial_id} — data access & operations log\n"
            "# One line per event. Add your own with: iroc-store note "
            f"{trial_id} -m \"...\"\n"
            "# | time (UTC) | user@host | action | case | message |\n")


def format_line(at: str, who: str, action: str, case_id: str | None, message: str) -> str:
    return f"| {at} | {_esc(who)} | {action} | {_esc(case_id or '-')} | {_esc(message)} |"


def parse_line(line: str) -> dict | None:
    m = _LINE.match(line.rstrip("\n"))
    if not m:
        return None
    who = _unesc(m.group("who"))
    user, _, host = who.partition("@")
    case = _unesc(m.group("case"))
    return {"at": m.group("at"), "username": user, "host": host,
            "action": m.group("action").strip(), "case_id": None if case == "-" else case,
            "message": _unesc(m.group("msg"))}


def parse_log_file(path: Path) -> list[dict]:
    out = []
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError:
        return out
    for line in text.splitlines():
        if line.startswith("|"):
            rec = parse_line(line)
            if rec:
                out.append(rec)
    return out


class TrialLog:
    def __init__(self, root: Path, catalog=None, lock_stale_minutes: int = 5, path_for=None):
        self.root = Path(root)
        self.catalog = catalog
        self.path_for = path_for   # collection id -> collection directory
        self.lock_stale_minutes = lock_stale_minutes
        self.user = _username()
        self.host = socket.gethostname()

    def path(self, trial_id: str) -> Path:
        if self.path_for is not None:
            try:
                return Path(self.path_for(trial_id)) / TRIAL_LOG
            except Exception:
                pass
        return self.root / sanitize_component(trial_id, 60) / TRIAL_LOG

    def append(self, trial_id: str, action: str, message: str, case_id: str | None = None,
               details: dict | None = None, at: str | None = None) -> dict:
        if action not in ACTIONS:
            raise ValueError(f"unknown log action {action!r}")
        at = at or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%MZ")
        p = self.path(trial_id)
        p.parent.mkdir(parents=True, exist_ok=True)
        who = f"{self.user}@{self.host}"
        line = format_line(at, who, action, case_id, message)
        lock = StoreLock(p.with_name(".log.lock"), stale_minutes=self.lock_stale_minutes,
                         heartbeat_seconds=0, cmd="trial-log")
        lock.acquire(wait_seconds=30)
        try:
            if not p.exists():
                p.write_text(header_text(trial_id), encoding="utf-8")
            append_line(p, line)
        finally:
            lock.release()
        rec = {"trial_id": trial_id, "case_id": case_id, "at": at, "username": self.user,
               "host": self.host, "action": action, "message": message, "details": details}
        if self.catalog is not None:
            self.catalog.insert_trial_log(trial_id, case_id, at, self.user, self.host, action,
                                          message, details)
        return rec

    def reindex(self, trial_id: str) -> int:
        """Rebuild the catalog rows for one trial from the log file."""
        if self.catalog is None:
            return 0
        recs = parse_log_file(self.path(trial_id))
        self.catalog.conn.execute("DELETE FROM trial_log WHERE trial_id=?", (trial_id,))
        for r in recs:
            self.catalog.insert_trial_log(trial_id, r["case_id"], r["at"], r["username"],
                                          r["host"], r["action"], r["message"], None)
        return len(recs)


def details_json(d: dict | None) -> str:
    return json.dumps(d, ensure_ascii=False) if d else ""
