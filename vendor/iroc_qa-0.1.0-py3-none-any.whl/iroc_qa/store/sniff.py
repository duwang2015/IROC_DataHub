"""Byte-level file kind detection. Never trusts the extension alone."""

from __future__ import annotations

import gzip
import zipfile
from pathlib import Path

KINDS = ("dicom", "nifti", "zip", "docx", "xlsx", "pptx", "pdf", "csv", "json", "txt",
         "tiff", "png", "jpeg", "unknown")

_DICOM_EXTS = {".dcm", ".dicom", ".ima", ".img", ""}
_TEXT_EXTS = {".csv": "csv", ".tsv": "csv", ".json": "json", ".txt": "txt", ".md": "txt",
              ".log": "txt", ".xml": "txt", ".html": "txt", ".htm": "txt", ".yaml": "txt",
              ".yml": "txt"}


def _head(path: Path, n: int) -> bytes:
    try:
        with open(path, "rb") as fh:
            return fh.read(n)
    except OSError:
        return b""


def is_dicom(path: Path) -> bool:
    head = _head(path, 132)
    if len(head) >= 132 and head[128:132] == b"DICM":
        return True
    if Path(path).suffix.lower() in _DICOM_EXTS and head:
        try:
            import pydicom

            ds = pydicom.dcmread(str(path), stop_before_pixels=True, force=True)
            return "SOPClassUID" in ds and bool(ds.SOPClassUID)
        except Exception:
            return False
    return False


def _nifti_magic(buf: bytes) -> bool:
    return len(buf) >= 348 and buf[344:348] in (b"n+1\x00", b"ni1\x00", b"n+2\x00", b"ni2\x00")


def is_nifti(path: Path) -> bool:
    head = _head(path, 352)
    if _nifti_magic(head):
        return True
    if head[:2] == b"\x1f\x8b":
        try:
            with gzip.open(path, "rb") as gz:
                return _nifti_magic(gz.read(352))
        except OSError:
            return False
    return False


def _zip_kind(path: Path) -> str:
    try:
        with zipfile.ZipFile(path) as zf:
            names = set(zf.namelist())
    except (zipfile.BadZipFile, OSError):
        return "unknown"
    if "[Content_Types].xml" in names:
        if any(n.startswith("word/") for n in names):
            return "docx"
        if any(n.startswith("xl/") for n in names):
            return "xlsx"
        if any(n.startswith("ppt/") for n in names):
            return "pptx"
    return "zip"


def _looks_text(buf: bytes) -> bool:
    if not buf:
        return False
    if b"\x00" in buf:
        return False
    try:
        buf.decode("utf-8")
        return True
    except UnicodeDecodeError:
        try:
            buf.decode("latin-1")
            return sum(c < 32 and c not in (9, 10, 13) for c in buf) < len(buf) * 0.02
        except UnicodeDecodeError:
            return False


def sniff(path: Path | str) -> str:
    path = Path(path)
    head = _head(path, 352)
    if not head:
        return "unknown"
    if len(head) >= 132 and head[128:132] == b"DICM":
        return "dicom"
    if head[:4] == b"PK\x03\x04":
        return _zip_kind(path)
    if head[:4] == b"%PDF":
        return "pdf"
    if head[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if head[:3] == b"\xff\xd8\xff":
        return "jpeg"
    if head[:4] in (b"II*\x00", b"MM\x00*"):
        return "tiff"
    if _nifti_magic(head):
        return "nifti"
    if head[:2] == b"\x1f\x8b":
        return "nifti" if is_nifti(path) else "unknown"
    if is_dicom(path):
        return "dicom"
    ext = path.suffix.lower()
    if ext in _TEXT_EXTS and _looks_text(head):
        return _TEXT_EXTS[ext]
    if _looks_text(head):
        s = head.lstrip()
        if s[:1] in (b"{", b"["):
            return "json"
        if b"," in head and b"\n" in head:
            return "csv"
        return "txt"
    return "unknown"


def platform_kind(sniffed: str, modality: str = "") -> str:
    """Map a sniffed kind (plus DICOM modality) to a platform file kind."""
    if sniffed == "dicom":
        return f"dicom_{(modality or 'other').lower()}"
    return {
        "nifti": "nifti_image", "zip": "archive_zip", "docx": "document_docx",
        "xlsx": "table_xlsx", "pptx": "document_pptx", "pdf": "pdf_report",
        "csv": "table_csv", "json": "json", "txt": "document_txt", "tiff": "tiff_stack",
        "png": "image_png", "jpeg": "image_jpeg",
    }.get(sniffed, "unknown")


def subdir_for_kind(sniffed: str) -> str:
    """Which batch sub-directory a non-DICOM file goes into."""
    if sniffed in ("docx", "xlsx", "pptx", "pdf", "csv", "json", "txt"):
        return "documents"
    if sniffed in ("nifti", "tiff", "png", "jpeg"):
        return "images"
    if sniffed == "zip":
        return "archives"
    return "misc"
