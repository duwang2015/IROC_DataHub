"""Combine multiple dose Excel files into a single spreadsheet.

Reads the "Achieved" column from each Excel file in a directory and
concatenates them side-by-side.

Ported from KBP/BN001/Old/Py Code/Combine_dose.py.
"""

from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)


def combine_dose_files(
    input_dir: str | Path,
    output_path: str | Path,
    column_name: str = "Achieved",
) -> pd.DataFrame:
    """Read Excel files from *input_dir* and merge the *column_name* column.

    Each file contributes one column to the output, named after the file.

    Parameters
    ----------
    input_dir : Path
        Directory containing ``.xlsx`` files.
    output_path : Path
        Output Excel file path.
    column_name : str
        Column to extract from each file (default ``"Achieved"``).

    Returns
    -------
    DataFrame
        Combined DataFrame with one column per input file.
    """
    input_dir = Path(input_dir)
    output_path = Path(output_path)

    frames: list[pd.DataFrame] = []
    for xlsx in sorted(input_dir.glob("*.xlsx")):
        try:
            df = pd.read_excel(xlsx)
            if column_name not in df.columns:
                logger.warning("Column '%s' not found in %s — skipping", column_name, xlsx.name)
                continue
            col = df[[column_name]].rename(columns={column_name: xlsx.name})
            frames.append(col)
        except Exception as exc:
            logger.warning("Failed to read %s: %s", xlsx.name, exc)

    if not frames:
        logger.warning("No files processed from %s", input_dir)
        return pd.DataFrame()

    combined = pd.concat(frames, axis=1)
    combined.to_excel(output_path, index=False)
    logger.info("Combined %d files → %s", len(frames), output_path)
    return combined
