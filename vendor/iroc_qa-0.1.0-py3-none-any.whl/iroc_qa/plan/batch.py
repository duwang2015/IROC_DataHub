"""Batch DVH processing — process multiple CSV files to Excel.

Ported from DPS_v2 notebook (IROC Service).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from .dvh import (
    compute_mean_dose,
    dose_at_absolute_volume,
    dose_at_volume_fraction,
    extract_dvh,
    get_total_volume,
    volume_at_threshold,
)

logger = logging.getLogger(__name__)


@dataclass
class DVHConfig:
    """Configuration for DVH metric extraction."""

    structures: list[str] = field(default_factory=list)
    v_thresholds_gy: list[float] = field(default_factory=list)
    v_percent_thresholds: list[float] = field(default_factory=list)
    d_percent_thresholds: list[float] = field(default_factory=list)
    d_cc_thresholds: list[float] = field(default_factory=list)
    rx_dose_gy: float | None = None


def process_file(file_path: Path, config: DVHConfig) -> dict:
    """Process one DVH CSV and compute metrics for each structure.

    Returns a dict with keys like ``"PTV_Total_volume"``, ``"PTV_Mean_Dose"``,
    ``"PTV_V20Gy[cc]"``, etc.  Missing structures get ``"NA"`` values.
    """
    results: dict = {"File Name": file_path.stem}

    for struct in config.structures:
        try:
            dvh, actual_col = extract_dvh(file_path, struct)
            total_vol = get_total_volume(dvh, actual_col)
            mean_dose = compute_mean_dose(dvh, total_vol, actual_col)

            results[f"{struct}_Total_volume"] = total_vol
            results[f"{struct}_Mean_Dose"] = mean_dose

            for thr in config.v_thresholds_gy:
                results[f"{struct}_V{thr}Gy[cc]"] = volume_at_threshold(
                    dvh, thr, actual_col,
                )

            if config.rx_dose_gy is not None:
                for pct in config.v_percent_thresholds:
                    key = f"{struct}_V{int(pct * 100)}%Rx[cc]"
                    results[key] = volume_at_threshold(
                        dvh, config.rx_dose_gy * pct, actual_col,
                    )

            for frac in config.d_percent_thresholds:
                key = f"{struct}_D{int(frac * 100)}pct[Gy]"
                results[key] = dose_at_volume_fraction(
                    dvh, frac, total_vol, actual_col,
                )

            for thr in config.d_cc_thresholds:
                results[f"{struct}_Dcc_{thr}[Gy]"] = dose_at_absolute_volume(
                    dvh, thr, actual_col,
                )

        except (ValueError, KeyError):
            logger.warning(
                "%s not found in %s — setting to NA", struct, file_path.name,
            )
            _fill_na(results, struct, config)

    return results


def process_files(
    folder: str | Path,
    output_excel: str | Path,
    config: DVHConfig,
) -> pd.DataFrame:
    """Process all CSV files in *folder* and write consolidated Excel.

    Returns the results DataFrame (one row per CSV).
    """
    folder = Path(folder)
    output_excel = Path(output_excel)

    all_results = []
    for csv_path in sorted(folder.glob("*.csv")):
        row = process_file(csv_path, config)
        all_results.append(row)

    df = pd.DataFrame(all_results)
    df.to_excel(output_excel, index=False)
    logger.info("Results written to %s (%d files)", output_excel, len(df))
    return df


def _fill_na(results: dict, struct: str, config: DVHConfig) -> None:
    """Fill all metric keys for *struct* with ``"NA"``."""
    results[f"{struct}_Total_volume"] = "NA"
    results[f"{struct}_Mean_Dose"] = "NA"
    for thr in config.v_thresholds_gy:
        results[f"{struct}_V{thr}Gy[cc]"] = "NA"
    if config.rx_dose_gy is not None:
        for pct in config.v_percent_thresholds:
            results[f"{struct}_V{int(pct * 100)}%Rx[cc]"] = "NA"
    for frac in config.d_percent_thresholds:
        results[f"{struct}_D{int(frac * 100)}pct[Gy]"] = "NA"
    for thr in config.d_cc_thresholds:
        results[f"{struct}_Dcc_{thr}[Gy]"] = "NA"
