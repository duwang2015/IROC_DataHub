#!/usr/bin/env python
"""
dcm2nii.py - Convert DICOM (CT, MRI, PET, RTDose) to NIfTI (.nii.gz).

Supports three input modes:
  - flat:        .dcm files directly in folder (mixed series)
  - single_case: modality subfolders like CT/, PET/ under one case
  - multi_case:  case-ID subfolders each with modality subfolders

Usage examples:
  python dcm2nii.py -i ./test -o ./output                          # multi-case
  python dcm2nii.py -i ./test/ALL_DCM -o ./output                  # flat mixed
  python dcm2nii.py -i ./test/HN-CHUM-005 -o ./output              # single case
  python dcm2nii.py -i ./test -o ./output --cases GBM-005 HN-CHUM-005
  python dcm2nii.py -i ./test -o ./output --no-resample --skip-suv -v
"""

import argparse
import json
import logging
import os
import sys
from collections import defaultdict
from datetime import datetime

import numpy as np
import pydicom
import SimpleITK as sitk  # noqa: N813

try:
    import openpyxl
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

try:
    from rt_utils import RTStructBuilder
    HAS_RT_UTILS = True
except ImportError:
    HAS_RT_UTILS = False

logger = logging.getLogger(__name__)

# Modalities we can convert to NIfTI (image data)
CONVERTIBLE_MODALITIES = {"CT", "MR", "PT", "RTDOSE"}
# Modalities to skip silently
SKIP_MODALITIES = {"RTPLAN", "REG", "SR", "KO", "PR", "SEG"}
# Keywords that hint at MRI sequence type
MRI_SEQUENCE_KEYWORDS = ["T1", "T2", "FLAIR", "DWI", "ADC", "SWI", "PD", "STIR"]


# ---------------------------------------------------------------------------
# RTSTRUCT helper
# ---------------------------------------------------------------------------

def extract_rtstruct_names(series_files):
    """Extract ROI names from an RTSTRUCT series.
    Returns sorted list of structure name strings."""
    names = []
    fp = series_files[0][0]
    try:
        ds = pydicom.dcmread(fp, stop_before_pixels=True, force=True)
        if hasattr(ds, "StructureSetROISequence"):
            for roi in ds.StructureSetROISequence:
                name = getattr(roi, "ROIName", None)
                if name:
                    names.append(name)
    except Exception as exc:
        logger.debug("Cannot read RTSTRUCT %s: %s", fp, exc)
    return sorted(names)


# ---------------------------------------------------------------------------
# Excel report writer
# ---------------------------------------------------------------------------

def write_excel_report(report_rows, output_path):
    """Write conversion summary to Excel.

    Each row: Case ID | Modalities | NIfTI Files | Structures
    """
    if not HAS_OPENPYXL:
        logger.warning("openpyxl not installed - skipping Excel report. "
                        "Install with: pip install openpyxl")
        return

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Conversion Summary"

    # Header
    headers = ["Case ID", "Modalities", "NIfTI Files", "Structures"]
    ws.append(headers)
    from openpyxl.styles import Alignment, Font, PatternFill
    header_font = Font(bold=True)
    header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2",
                              fill_type="solid")
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill

    # Data rows
    for row in sorted(report_rows, key=lambda r: r["case_id"]):
        ws.append([
            row["case_id"],
            ", ".join(sorted(row["modalities"])),
            "\n".join(sorted(row["nifti_files"])),
            ", ".join(row["structures"]) if row["structures"] else "",
        ])

    # Column widths
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 45
    ws.column_dimensions["D"].width = 70

    # Wrap text for NIfTI files and structures columns
    for row_cells in ws.iter_rows(min_row=2, max_row=ws.max_row):
        for cell in row_cells:
            cell.alignment = Alignment(wrap_text=True, vertical="top")

    wb.save(output_path)
    logger.info("Excel report saved: %s", output_path)


# ---------------------------------------------------------------------------
# Resampling utility
# ---------------------------------------------------------------------------

def resample_to_reference(source, reference, interpolator=sitk.sitkBSpline,
                          default_value=0.0):
    """Resample *source* image onto the grid of *reference* image."""
    resampler = sitk.ResampleImageFilter()
    resampler.SetReferenceImage(reference)
    resampler.SetInterpolator(interpolator)
    resampler.SetDefaultPixelValue(default_value)
    resampler.SetTransform(sitk.Transform())  # identity
    return resampler.Execute(source)


# ---------------------------------------------------------------------------
# DICOM scanning helpers
# ---------------------------------------------------------------------------

def _read_dicom_header(filepath):
    """Read a DICOM file header only (no pixel data)."""
    try:
        ds = pydicom.dcmread(filepath, stop_before_pixels=True, force=True)
        return ds
    except Exception as exc:
        logger.debug("Cannot read %s: %s", filepath, exc)
        return None


def scan_dicom_files(root_dir):
    """Walk *root_dir* and return list of (filepath, pydicom.Dataset) for every
    readable .dcm file (or extensionless DICOM)."""
    results = []
    for dirpath, _, filenames in os.walk(root_dir):
        for fn in filenames:
            fp = os.path.join(dirpath, fn)
            # Accept .dcm or extensionless files (common in DICOM)
            if not (fn.lower().endswith(".dcm") or "." not in fn):
                continue
            ds = _read_dicom_header(fp)
            if ds is not None and hasattr(ds, "SOPClassUID"):
                results.append((fp, ds))
    return results


def group_by_series(file_list):
    """Group (filepath, dataset) pairs by SeriesInstanceUID.
    Returns dict[series_uid] -> list of (filepath, dataset)."""
    groups = defaultdict(list)
    for fp, ds in file_list:
        uid = getattr(ds, "SeriesInstanceUID", "UNKNOWN")
        groups[uid].append((fp, ds))
    return dict(groups)


def detect_modality(series_files):
    """Return modality string for a series group."""
    ds = series_files[0][1]
    modality = getattr(ds, "Modality", "").upper().strip()
    return modality


def detect_mri_sequence(series_files, folder_hint=""):
    """Try to determine MRI sequence name (T1, T2, FLAIR, etc.)."""
    ds = series_files[0][1]
    candidates = [
        getattr(ds, "SeriesDescription", ""),
        getattr(ds, "ProtocolName", ""),
        getattr(ds, "SequenceName", ""),
        folder_hint,
    ]
    for text in candidates:
        upper = text.upper()
        for kw in MRI_SEQUENCE_KEYWORDS:
            if kw in upper:
                return kw
    return "MR"


def get_patient_id(series_files):
    """Extract PatientID from first file in series."""
    ds = series_files[0][1]
    pid = getattr(ds, "PatientID", None)
    if pid:
        return pid.strip()
    return "UNKNOWN"


# ---------------------------------------------------------------------------
# Input-mode detection
# ---------------------------------------------------------------------------

def _has_dcm_files(directory):
    """Check if directory directly contains .dcm files."""
    for fn in os.listdir(directory):
        if fn.lower().endswith(".dcm"):
            return True
    return False


def _has_modality_subdirs(directory):
    """Check if directory has subdirectories that look like modality folders."""
    modality_names = {"CT", "MR", "PET", "PT", "MRI", "RTDOSE", "RTSTRUCT",
                      "RTPLAN", "T1", "T2", "FLAIR", "DWI"}
    for entry in os.listdir(directory):
        full = os.path.join(directory, entry)
        if os.path.isdir(full) and entry.upper().split("-")[0].strip() in modality_names:
            return True
        # Also check partial matches like "RTDose", "RTst"
        if os.path.isdir(full):
            upper = entry.upper()
            if any(upper.startswith(m) for m in ["CT", "PET", "MR", "T1", "T2",
                                                  "FLAIR", "RTDOSE", "RTST",
                                                  "RTPLAN", "DWI", "ADC"]):
                return True
    return False


def detect_input_mode(input_dir):
    """Detect whether input is flat, single_case, or multi_case.

    Returns:
        (mode, case_dirs) where case_dirs is a dict mapping case_id -> path
    """
    # Check if dcm files are directly in input_dir -> flat mode
    if _has_dcm_files(input_dir):
        logger.info("Detected input mode: flat")
        return "flat", {}

    # Check if input_dir has modality subdirectories -> single_case
    if _has_modality_subdirs(input_dir):
        case_id = os.path.basename(os.path.normpath(input_dir))
        logger.info("Detected input mode: single_case (%s)", case_id)
        return "single_case", {case_id: input_dir}

    # Otherwise assume multi_case: subdirectories are case IDs
    case_dirs = {}
    for entry in sorted(os.listdir(input_dir)):
        full = os.path.join(input_dir, entry)
        if os.path.isdir(full):
            # Skip hidden dirs
            if entry.startswith("."):
                continue
            case_dirs[entry] = full
    if case_dirs:
        logger.info("Detected input mode: multi_case (%d cases)", len(case_dirs))
    else:
        logger.warning("No cases found in %s", input_dir)
    return "multi_case", case_dirs


# ---------------------------------------------------------------------------
# Conversion functions
# ---------------------------------------------------------------------------

def convert_ct_or_mri(series_files, output_path):
    """Convert a CT or MR series to NIfTI using SimpleITK ImageSeriesReader."""
    filepaths = [fp for fp, _ in series_files]

    # Try GDCM-sorted reading first
    reader = sitk.ImageSeriesReader()
    try:
        # Get the directory - all files should be in same dir for series reader
        series_dir = os.path.dirname(filepaths[0])
        ds0 = series_files[0][1]
        series_uid = getattr(ds0, "SeriesInstanceUID", "")

        # Get properly sorted file list from GDCM
        sorted_names = reader.GetGDCMSeriesFileNames(series_dir, series_uid)
        if sorted_names:
            reader.SetFileNames(sorted_names)
            image = reader.Execute()
            sitk.WriteImage(image, output_path, useCompression=True)
            logger.info("  Saved: %s", output_path)
            return image
    except Exception as exc:
        logger.debug("GDCM series read failed: %s. Trying manual sort.", exc)

    # Fallback: manual sort by ImagePositionPatient z-coordinate
    try:
        sorted_files = sorted(
            series_files,
            key=lambda x: float(getattr(x[1], "ImagePositionPatient", [0, 0, 0])[2])
        )
        reader.SetFileNames([fp for fp, _ in sorted_files])
        image = reader.Execute()
        sitk.WriteImage(image, output_path, useCompression=True)
        logger.info("  Saved: %s", output_path)
        return image
    except Exception as exc:
        logger.error("  Failed to convert series: %s", exc)
        return None


def _parse_dicom_time(time_str, date_str=""):
    """Parse DICOM time string (HHMMSS.frac) into datetime or total seconds."""
    if not time_str:
        return None
    time_str = time_str.strip()
    # Remove fractional seconds for parsing, keep for precision
    parts = time_str.split(".")
    base = parts[0]
    frac = float("0." + parts[1]) if len(parts) > 1 else 0.0

    h = int(base[0:2]) if len(base) >= 2 else 0
    m = int(base[2:4]) if len(base) >= 4 else 0
    s = int(base[4:6]) if len(base) >= 6 else 0
    total_seconds = h * 3600 + m * 60 + s + frac

    if date_str:
        date_str = date_str.strip()
        try:
            dt = datetime(
                int(date_str[0:4]), int(date_str[4:6]), int(date_str[6:8]),
                h, m, s
            )
            return dt, total_seconds
        except (ValueError, IndexError):
            pass
    return None, total_seconds


def compute_suv_bw(series_files):
    """Compute SUVbw scaling factor from DICOM tags.

    Returns (weight_g, dose_bq, half_life, decay_time_sec) or None if tags missing.
    """
    ds = series_files[0][1]  # read from first file

    # Patient weight in kg
    weight_kg = getattr(ds, "PatientWeight", None)
    if weight_kg is None:
        logger.warning("  PatientWeight missing - cannot compute SUV")
        return None
    weight_kg = float(weight_kg)
    weight_g = weight_kg * 1000.0

    # Radiopharmaceutical info
    radio_seq = getattr(ds, "RadiopharmaceuticalInformationSequence", None)
    if radio_seq is None or len(radio_seq) == 0:
        logger.warning("  RadiopharmaceuticalInformationSequence missing - cannot compute SUV")
        return None

    radio = radio_seq[0]
    total_dose = getattr(radio, "RadionuclideTotalDose", None)
    half_life = getattr(radio, "RadionuclideHalfLife", None)
    radio_start_time = getattr(radio, "RadiopharmaceuticalStartTime", None)
    radio_start_dt = getattr(radio, "RadiopharmaceuticalStartDateTime", None)

    if total_dose is None or half_life is None:
        logger.warning("  RadionuclideTotalDose or HalfLife missing - cannot compute SUV")
        return None

    total_dose = float(total_dose)
    half_life = float(half_life)

    # Determine injection time-of-day (seconds since midnight)
    injection_seconds = None

    if radio_start_dt:
        # RadiopharmaceuticalStartDateTime: YYYYMMDDHHMMSS.frac
        dt_str = str(radio_start_dt).strip()
        if len(dt_str) >= 14:
            injection_time_str = dt_str[8:]
            _, injection_seconds = _parse_dicom_time(injection_time_str)
    if injection_seconds is None and radio_start_time:
        _, injection_seconds = _parse_dicom_time(str(radio_start_time))

    if injection_seconds is None:
        logger.warning("  RadiopharmaceuticalStartTime missing - cannot compute SUV")
        return None

    # Acquisition/Series time-of-day
    acq_time = getattr(ds, "AcquisitionTime", None) or getattr(ds, "SeriesTime", None)
    if acq_time is None:
        logger.warning("  AcquisitionTime/SeriesTime missing - cannot compute SUV")
        return None

    _, acq_seconds = _parse_dicom_time(str(acq_time))

    # Decay time using time-of-day only (dates are often anonymized
    # inconsistently across DICOM tags, making date-based calculation
    # unreliable)
    decay_time = acq_seconds - injection_seconds
    if decay_time < 0:
        decay_time += 86400  # crossed midnight

    # Sanity check: decay time should be positive and < 24 hours
    if decay_time <= 0 or decay_time > 86400:
        logger.warning("  Computed decay time %.1f s seems invalid - skipping SUV",
                        decay_time)
        return None

    logger.info("  SUV params: weight=%.1f kg, dose=%.1f Bq, T½=%.1f s, decay=%.1f s",
                weight_kg, total_dose, half_life, decay_time)

    return weight_g, total_dose, half_life, decay_time


def convert_pet(series_files, output_raw, output_suv, skip_suv=False):
    """Convert PET series to raw NIfTI and optionally SUVbw NIfTI."""
    # Read the image series
    filepaths = [fp for fp, _ in series_files]
    reader = sitk.ImageSeriesReader()

    series_dir = os.path.dirname(filepaths[0])
    ds0 = series_files[0][1]
    series_uid = getattr(ds0, "SeriesInstanceUID", "")

    image = None
    try:
        sorted_names = reader.GetGDCMSeriesFileNames(series_dir, series_uid)
        if sorted_names:
            reader.SetFileNames(sorted_names)
            image = reader.Execute()
    except Exception:
        pass

    if image is None:
        sorted_files = sorted(
            series_files,
            key=lambda x: float(getattr(x[1], "ImagePositionPatient", [0, 0, 0])[2])
        )
        reader.SetFileNames([fp for fp, _ in sorted_files])
        image = reader.Execute()

    # Save raw PET
    sitk.WriteImage(image, output_raw, useCompression=True)
    logger.info("  Saved raw PET: %s", output_raw)

    if skip_suv:
        return image, None

    # Compute SUV
    suv_params = compute_suv_bw(series_files)
    if suv_params is None:
        logger.warning("  Skipping SUV computation (missing tags)")
        return image, None

    weight_g, total_dose, half_life, decay_time = suv_params

    # Decay-corrected dose
    decay_factor = 2.0 ** (-decay_time / half_life) if half_life > 0 else 1.0
    corrected_dose = total_dose * decay_factor

    if corrected_dose <= 0:
        logger.warning("  Corrected dose is zero or negative - skipping SUV")
        return image, None

    # Get RescaleSlope and Intercept from first file
    ds0_full = pydicom.dcmread(series_files[0][0], stop_before_pixels=True)
    slope = float(getattr(ds0_full, "RescaleSlope", 1.0))
    intercept = float(getattr(ds0_full, "RescaleIntercept", 0.0))

    # Apply SUV formula: SUVbw = (pixel * slope + intercept) * weight_g / corrected_dose
    # Note: SimpleITK already applies RescaleSlope/Intercept for some readers,
    # so check if values are already in Bq/ml range
    arr = sitk.GetArrayFromImage(image).astype(np.float64)

    # Check if rescaling is already applied by SimpleITK
    # If values are very large (> 1e6), likely already rescaled
    # If values are small integers, need manual rescale
    if arr.max() < 1000 and slope != 1.0:
        arr = arr * slope + intercept

    suv_arr = arr * weight_g / corrected_dose

    suv_image = sitk.GetImageFromArray(suv_arr)
    suv_image.CopyInformation(image)
    sitk.WriteImage(suv_image, output_suv, useCompression=True)
    logger.info("  Saved SUVbw: %s", output_suv)

    return image, suv_image


def convert_rtdose(series_files, output_path, ct_image=None, no_resample=False):
    """Convert RTDose DICOM to NIfTI in cGy, optionally resampled to CT grid."""
    fp = series_files[0][0]  # RTDose is typically a single file

    # Read with SimpleITK
    dose_image = sitk.ReadImage(fp)

    # Read DoseGridScaling from pydicom
    ds = pydicom.dcmread(fp, stop_before_pixels=True)
    dose_grid_scaling = float(getattr(ds, "DoseGridScaling", 1.0))
    dose_units = getattr(ds, "DoseUnits", "GY").upper()

    # Convert to float64 and apply scaling
    arr = sitk.GetArrayFromImage(dose_image).astype(np.float64)
    arr = arr * dose_grid_scaling  # now in Gy (or whatever DoseUnits says)

    # Convert Gy -> cGy
    if dose_units == "GY":
        arr = arr * 100.0

    dose_scaled = sitk.GetImageFromArray(arr)
    dose_scaled.CopyInformation(dose_image)

    # Resample to CT grid if available
    if ct_image is not None and not no_resample:
        logger.info("  Resampling RTDose to CT grid...")
        dose_scaled = resample_to_reference(dose_scaled, ct_image,
                                            interpolator=sitk.sitkBSpline,
                                            default_value=0.0)

    sitk.WriteImage(dose_scaled, output_path, useCompression=True)
    logger.info("  Saved RTDose (cGy): %s", output_path)
    return dose_scaled


def convert_rtstruct(rtstruct_file, ct_series_dir, ct_image, case_id, case_out,
                     roi_filter=None):
    """Convert RTSTRUCT contours to a single combined label-map NIfTI.

    Each ROI gets a unique integer label (1, 2, 3, ...).
    Returns (saved_filename, roi_mapping_dict) where roi_mapping_dict maps
    label int -> ROI name, or (None, {}) on failure.
    """
    if not HAS_RT_UTILS:
        logger.warning("  rt_utils not installed - skipping RTSTRUCT conversion. "
                        "Install with: pip install rt_utils")
        return None, {}

    try:
        rts = RTStructBuilder.create_from(
            dicom_series_path=ct_series_dir,
            rt_struct_path=rtstruct_file,
        )
    except Exception as exc:
        logger.error("  Failed to load RTSTRUCT %s: %s", rtstruct_file, exc)
        return None, {}

    roi_names = rts.get_roi_names()
    if roi_filter:
        selected = [n for n in roi_names
                    if any(f.lower() in n.lower() for f in roi_filter)]
        logger.info("  ROI filter matched %d/%d: %s",
                    len(selected), len(roi_names), selected)
        roi_names = selected
    logger.info("  Converting %d RTSTRUCT ROIs to combined label map...",
                len(roi_names))

    # Get CT array shape for the combined label volume
    ct_arr = sitk.GetArrayFromImage(ct_image)  # (slices, rows, cols)
    label_arr = np.zeros(ct_arr.shape, dtype=np.uint16)
    roi_mapping = {}  # label_int -> roi_name
    label_idx = 0

    for name in roi_names:
        try:
            mask_3d = rts.get_roi_mask_by_name(name)
            # rt_utils returns (rows, cols, slices) ->
            # SimpleITK array convention is (slices, rows, cols)
            mask_arr = mask_3d.transpose(2, 0, 1).astype(bool)
            label_idx += 1
            # Write this label; later ROIs overwrite earlier ones at
            # overlapping voxels (last-wins), which is the standard
            # behaviour for combined label maps.
            label_arr[mask_arr] = label_idx
            roi_mapping[label_idx] = name
        except Exception as exc:
            logger.warning("  Skipped structure '%s': %s", name, exc)

    if not roi_mapping:
        return None, {}

    label_img = sitk.GetImageFromArray(label_arr)
    label_img.CopyInformation(ct_image)

    fname = f"{case_id}_RTSTRUCT.nii.gz"
    out_path = os.path.join(case_out, fname)
    sitk.WriteImage(label_img, out_path, useCompression=True)
    logger.info("  Saved combined label map (%d ROIs): %s", len(roi_mapping),
                out_path)
    return fname, roi_mapping


# ---------------------------------------------------------------------------
# Per-case processing
# ---------------------------------------------------------------------------

def process_case(case_id, series_groups, output_dir, no_resample=False,
                 skip_suv=False, roi_filter=None, skip_rtstruct=False):
    """Process all series for one patient case.

    Returns a report dict with keys: case_id, modalities, nifti_files, structures.
    """
    case_out = os.path.join(output_dir, case_id)
    os.makedirs(case_out, exist_ok=True)

    logger.info("Processing case: %s", case_id)

    report = {
        "case_id": case_id,
        "modalities": set(),
        "nifti_files": [],
        "structures": [],
        "roi_mapping": {},
    }

    ct_image = None  # reference for resampling
    pet_series = []
    rtdose_series = []
    mr_series = []
    ct_series = []
    rtstruct_series = []

    # Classify series by modality
    for uid, files in series_groups.items():
        modality = detect_modality(files)
        if modality == "CT":
            ct_series.append((uid, files))
            report["modalities"].add("CT")
        elif modality == "MR":
            mr_series.append((uid, files))
            report["modalities"].add("MR")
        elif modality == "PT":
            pet_series.append((uid, files))
            report["modalities"].add("PET")
        elif modality == "RTDOSE":
            rtdose_series.append((uid, files))
            report["modalities"].add("RTDose")
        elif modality == "RTSTRUCT":
            rtstruct_series.append((uid, files))
            report["modalities"].add("RTSTRUCT")
            logger.info("  Found RTSTRUCT series: %s", uid[:20])
        elif modality == "RTPLAN":
            report["modalities"].add("RTPLAN")
            logger.info("  Skipping RTPLAN series: %s", uid[:20])
        elif modality in SKIP_MODALITIES:
            logger.info("  Skipping %s series: %s", modality, uid[:20])
        else:
            logger.debug("  Unknown modality '%s' for series %s", modality, uid[:20])

    # Extract RTSTRUCT names (merge from all RTSTRUCT series)
    all_structures = set()
    for uid, files in rtstruct_series:
        names = extract_rtstruct_names(files)
        all_structures.update(names)
    report["structures"] = sorted(all_structures)
    if report["structures"]:
        logger.info("  Structures (%d): %s", len(report["structures"]),
                     ", ".join(report["structures"][:10])
                     + ("..." if len(report["structures"]) > 10 else ""))

    # Convert CT (use first/largest series as reference)
    ct_series_dir = None  # directory containing the primary CT DICOMs
    if ct_series:
        ct_series.sort(key=lambda x: len(x[1]), reverse=True)
        uid, files = ct_series[0]
        ct_series_dir = os.path.dirname(files[0][0])
        fname = f"{case_id}_CT.nii.gz"
        out_path = os.path.join(case_out, fname)
        logger.info("  Converting CT (%d files)...", len(files))
        ct_image = convert_ct_or_mri(files, out_path)
        if ct_image is not None:
            report["nifti_files"].append(fname)

        for i, (uid, files) in enumerate(ct_series[1:], 2):
            fname = f"{case_id}_CT_{i}.nii.gz"
            out_path = os.path.join(case_out, fname)
            logger.info("  Converting CT series %d (%d files)...", i, len(files))
            if convert_ct_or_mri(files, out_path) is not None:
                report["nifti_files"].append(fname)

    # Convert MRI
    for uid, files in mr_series:
        folder_name = os.path.basename(os.path.dirname(files[0][0]))
        seq = detect_mri_sequence(files, folder_hint=folder_name)
        fname = f"{case_id}_{seq}.nii.gz"
        out_path = os.path.join(case_out, fname)
        if os.path.exists(out_path):
            ds0 = files[0][1]
            snum = getattr(ds0, "SeriesNumber", uid[:8])
            fname = f"{case_id}_{seq}_{snum}.nii.gz"
            out_path = os.path.join(case_out, fname)
        logger.info("  Converting MR-%s (%d files)...", seq, len(files))
        if convert_ct_or_mri(files, out_path) is not None:
            report["nifti_files"].append(fname)

    # Convert PET
    for uid, files in pet_series:
        fname_raw = f"{case_id}_PET.nii.gz"
        fname_suv = f"{case_id}_SUVbw.nii.gz"
        out_raw = os.path.join(case_out, fname_raw)
        out_suv = os.path.join(case_out, fname_suv)
        logger.info("  Converting PET (%d files)...", len(files))
        _, suv_img = convert_pet(files, out_raw, out_suv, skip_suv=skip_suv)
        report["nifti_files"].append(fname_raw)
        if suv_img is not None:
            report["nifti_files"].append(fname_suv)

    # Convert RTDose
    for i, (uid, files) in enumerate(rtdose_series):
        suffix = "" if i == 0 else f"_{i + 1}"
        fname = f"{case_id}_RTDose_cGy{suffix}.nii.gz"
        out_path = os.path.join(case_out, fname)
        logger.info("  Converting RTDose...")
        convert_rtdose(files, out_path, ct_image=ct_image,
                       no_resample=no_resample)
        report["nifti_files"].append(fname)

    # Convert RTSTRUCT to combined label map (requires CT as reference grid)
    if skip_rtstruct:
        logger.info("  Skipping RTSTRUCT conversion (--skip-rtstruct)")
    elif rtstruct_series and ct_image is not None and ct_series_dir is not None:
        for uid, files in rtstruct_series:
            rs_file = files[0][0]
            fname, roi_map = convert_rtstruct(rs_file, ct_series_dir,
                                              ct_image, case_id, case_out,
                                              roi_filter=roi_filter)
            if fname:
                report["nifti_files"].append(fname)
                report["roi_mapping"] = roi_map
                break  # use first successful RTSTRUCT only
    elif rtstruct_series and ct_image is None:
        logger.warning("  Cannot convert RTSTRUCT without a CT reference image")

    logger.info("  Case %s complete.\n", case_id)
    return report


# ---------------------------------------------------------------------------
# Flat-directory processing
# ---------------------------------------------------------------------------

def process_flat(input_dir, output_dir, no_resample=False, skip_suv=False,
                 roi_filter=None, skip_rtstruct=False):
    """Process a flat directory of mixed .dcm files.

    Returns list of report dicts (one per patient found).
    """
    logger.info("Scanning flat directory: %s", input_dir)
    file_list = scan_dicom_files(input_dir)
    if not file_list:
        logger.error("No DICOM files found in %s", input_dir)
        return []

    logger.info("Found %d DICOM files", len(file_list))

    # Group by SeriesInstanceUID
    series_map = group_by_series(file_list)
    logger.info("Found %d series", len(series_map))

    # Group series by PatientID
    patient_series = defaultdict(dict)
    for uid, files in series_map.items():
        pid = get_patient_id(files)
        patient_series[pid][uid] = files

    logger.info("Found %d patients", len(patient_series))

    reports = []
    for pid, series_groups in patient_series.items():
        case_id = pid if pid != "UNKNOWN" else os.path.basename(
            os.path.normpath(input_dir))
        rpt = process_case(case_id, series_groups, output_dir,
                           no_resample=no_resample, skip_suv=skip_suv,
                           roi_filter=roi_filter,
                           skip_rtstruct=skip_rtstruct)
        reports.append(rpt)
    return reports


# ---------------------------------------------------------------------------
# Main orchestration
# ---------------------------------------------------------------------------

def process_directory(input_dir, output_dir, cases_filter=None,
                      no_resample=False, skip_suv=False,
                      roi_filter=None, skip_rtstruct=False):
    """Main entry point: detect mode and dispatch.

    Returns list of report dicts for all processed cases.
    """
    all_reports = []
    mode, case_dirs = detect_input_mode(input_dir)

    if mode == "flat":
        reports = process_flat(input_dir, output_dir,
                               no_resample=no_resample, skip_suv=skip_suv,
                               roi_filter=roi_filter,
                               skip_rtstruct=skip_rtstruct)
        all_reports.extend(reports)
        return all_reports

    if mode == "single_case":
        case_id = list(case_dirs.keys())[0]
        case_path = case_dirs[case_id]
        logger.info("Scanning single case: %s", case_id)
        file_list = scan_dicom_files(case_path)
        series_map = group_by_series(file_list)
        logger.info("Found %d DICOM files in %d series", len(file_list),
                     len(series_map))
        rpt = process_case(case_id, series_map, output_dir,
                           no_resample=no_resample, skip_suv=skip_suv,
                           roi_filter=roi_filter,
                           skip_rtstruct=skip_rtstruct)
        all_reports.append(rpt)
        return all_reports

    # multi_case
    if cases_filter:
        case_dirs = {k: v for k, v in case_dirs.items() if k in cases_filter}
        if not case_dirs:
            logger.error("None of the specified cases found: %s", cases_filter)
            return all_reports

    for case_id, case_path in sorted(case_dirs.items()):
        # Detect if this subfolder is itself a flat directory
        if _has_dcm_files(case_path):
            logger.info("Scanning flat subfolder: %s", case_id)
            reports = process_flat(case_path, output_dir,
                                   no_resample=no_resample, skip_suv=skip_suv,
                                   roi_filter=roi_filter,
                                   skip_rtstruct=skip_rtstruct)
            all_reports.extend(reports)
            continue

        logger.info("Scanning case: %s", case_id)
        file_list = scan_dicom_files(case_path)
        if not file_list:
            logger.warning("No DICOM files in %s - skipping", case_path)
            continue
        series_map = group_by_series(file_list)
        logger.info("Found %d DICOM files in %d series", len(file_list),
                     len(series_map))
        rpt = process_case(case_id, series_map, output_dir,
                           no_resample=no_resample, skip_suv=skip_suv,
                           roi_filter=roi_filter,
                           skip_rtstruct=skip_rtstruct)
        all_reports.append(rpt)

    return all_reports


def main():
    parser = argparse.ArgumentParser(
        description="Convert DICOM (CT, MRI, PET, RTDose) to NIfTI (.nii.gz)")
    parser.add_argument("-i", "--input_dir", required=True,
                        help="Input directory containing DICOM data")
    parser.add_argument("-o", "--output_dir", required=True,
                        help="Output directory for NIfTI files")
    parser.add_argument("--cases", nargs="+", default=None,
                        help="Process only these case IDs (multi_case mode)")
    parser.add_argument("--no-resample", action="store_true",
                        help="Skip resampling RTDose/PET to CT grid")
    parser.add_argument("--skip-suv", action="store_true",
                        help="Skip SUVbw computation for PET")
    parser.add_argument("--rois", nargs="+", default=None,
                        help="Convert only these ROI names (substring match, "
                             "case-insensitive)")
    parser.add_argument("--skip-rtstruct", action="store_true",
                        help="Skip RTSTRUCT conversion entirely")
    parser.add_argument("--qc", action="store_true",
                        help="Run DICOM QC validation and generate QC report")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Enable verbose/debug logging")
    args = parser.parse_args()

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    input_dir = os.path.abspath(args.input_dir)
    output_dir = os.path.abspath(args.output_dir)

    if not os.path.isdir(input_dir):
        logger.error("Input directory does not exist: %s", input_dir)
        sys.exit(1)

    os.makedirs(output_dir, exist_ok=True)
    logger.info("Input:  %s", input_dir)
    logger.info("Output: %s", output_dir)

    roi_filter = args.rois if not args.skip_rtstruct else None
    reports = process_directory(input_dir, output_dir, cases_filter=args.cases,
                                no_resample=args.no_resample,
                                skip_suv=args.skip_suv,
                                roi_filter=roi_filter,
                                skip_rtstruct=args.skip_rtstruct)

    # Write Excel summary and ROI mapping JSON
    if reports:
        excel_path = os.path.join(output_dir, "conversion_summary.xlsx")
        write_excel_report(reports, excel_path)

        # Save per-case roi_mapping JSON inside each case folder
        for rpt in reports:
            mapping = rpt.get("roi_mapping", {})
            if mapping:
                case_id = rpt["case_id"]
                case_dir = os.path.join(output_dir, case_id)
                json_path = os.path.join(case_dir, f"{case_id}_roi_mapping.json")
                str_mapping = {str(k): v for k, v in mapping.items()}
                with open(json_path, "w", encoding="utf-8") as f:
                    json.dump(str_mapping, f, indent=2, ensure_ascii=False)
                logger.info("ROI mapping saved: %s", json_path)

    # Optional QC report
    if args.qc:
        try:
            from .dicom_qc import generate_qc_report, summarize_conversion

            logger.info("Running DICOM QC validation...")
            qc_reports = []
            mode, case_dirs = detect_input_mode(input_dir)
            if mode == "flat":
                file_list = scan_dicom_files(input_dir)
                series_map = group_by_series(file_list)
                qc = generate_qc_report(
                    "flat", series_map,
                    os.path.join(output_dir, "qc_report.xlsx"),
                )
                qc_reports.append(qc)
            else:
                for case_id, case_path in sorted(case_dirs.items()):
                    file_list = scan_dicom_files(case_path)
                    if not file_list:
                        continue
                    series_map = group_by_series(file_list)
                    qc = generate_qc_report(
                        case_id, series_map,
                        os.path.join(output_dir, case_id, "qc_report.xlsx"),
                    )
                    qc_reports.append(qc)

            if qc_reports:
                summarize_conversion(
                    qc_reports,
                    os.path.join(output_dir, "qc_summary.xlsx"),
                )
        except ImportError:
            logger.warning("dicom_qc module not found — skipping QC report")

    logger.info("Done.")


if __name__ == "__main__":
    main()
