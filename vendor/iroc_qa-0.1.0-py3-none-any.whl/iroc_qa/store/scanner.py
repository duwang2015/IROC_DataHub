"""Walk a drop, read DICOM headers, and group instances into series groups."""

from __future__ import annotations

import logging
import zipfile
from collections import OrderedDict
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path

from .config import StoreConfig
from .fsutil import is_ignored, iter_files, sha256_file
from .sniff import sniff

logger = logging.getLogger(__name__)

DICOMDIR_SOP = "1.2.840.10008.1.3.10"
MAX_ZIP_DEPTH = 3
KEY_TAGS = ("Rows", "Columns", "PixelSpacing", "SliceThickness", "SpacingBetweenSlices",
            "ImageOrientationPatient", "Manufacturer", "ManufacturerModelName",
            "PatientWeight", "DoseUnits", "DoseGridScaling", "DoseSummationType",
            "StructureSetLabel", "RTPlanLabel", "NumberOfFrames", "BodyPartExamined")


@dataclass
class DicomHeader:
    path: Path
    size: int
    sop_instance_uid: str = ""
    sop_class_uid: str = ""
    series_uid: str = ""
    study_uid: str = ""
    for_uid: str = ""
    modality: str = ""
    series_number: int | None = None
    instance_number: int | None = None
    series_description: str = ""
    protocol_name: str = ""
    study_date: str = ""
    study_description: str = ""
    patient_id: str = ""
    patient_name: str = ""
    trial_protocol_id: str = ""
    trial_subject_id: str = ""
    trial_site_id: str = ""
    label: str = ""
    ref_series_uid: str = ""
    ref_sop_uid: str = ""
    key_tags: dict = field(default_factory=dict)
    folder_hints: list[str] = field(default_factory=list)
    source_relpath: str = ""
    sha256: str = ""


@dataclass
class SeriesGroup:
    key: tuple[str, str, str, str]
    headers: list[DicomHeader]
    modality: str = ""
    folder_hints: list[str] = field(default_factory=list)
    problems: list[str] = field(default_factory=list)
    dropped_duplicates: list[DicomHeader] = field(default_factory=list)

    @property
    def patient_id(self) -> str:
        return self.key[0]

    @property
    def study_uid(self) -> str:
        return self.key[1]

    @property
    def series_uid(self) -> str:
        return self.key[2]

    @property
    def for_uid(self) -> str:
        return self.key[3]

    @property
    def series_number(self) -> int | None:
        for h in self.headers:
            if h.series_number is not None:
                return h.series_number
        return None

    @property
    def description(self) -> str:
        h = self.headers[0]
        if h.modality == "RTSTRUCT" and h.label:
            return h.label
        if h.modality == "RTPLAN" and h.label:
            return h.label
        if h.modality == "RTDOSE":
            parts = [p for p in (h.label, h.series_description) if p]
            return " ".join(parts)
        return h.series_description or h.protocol_name

    @property
    def n_instances(self) -> int:
        return len(self.headers)

    @property
    def total_bytes(self) -> int:
        return sum(h.size for h in self.headers)

    @property
    def source_dirs(self) -> set[str]:
        return {str(Path(h.source_relpath).parent.as_posix()) for h in self.headers}


@dataclass
class OtherFile:
    path: Path
    size: int
    kind: str
    folder_hints: list[str] = field(default_factory=list)
    source_relpath: str = ""


@dataclass
class ScanResult:
    groups: list[SeriesGroup] = field(default_factory=list)
    others: list[OtherFile] = field(default_factory=list)
    ignored: list[Path] = field(default_factory=list)
    archives: list[Path] = field(default_factory=list)
    unreadable: list[OtherFile] = field(default_factory=list)


# ---------------------------------------------------------------------------
# header reading
# ---------------------------------------------------------------------------

def _str(ds, name: str) -> str:
    v = ds.get(name, "")
    if v is None:
        return ""
    try:
        if hasattr(v, "original_string") and isinstance(v.original_string, bytes):
            pass
        s = str(v)
    except Exception:
        return ""
    return s.strip()


def _int(ds, name: str) -> int | None:
    v = ds.get(name, None)
    if v in (None, ""):
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _rt_refs(ds, modality: str) -> tuple[str, str, str]:
    """Return (frame_of_reference_uid, ref_series_uid, ref_sop_uid) for RT objects."""
    for_uid = _str(ds, "FrameOfReferenceUID")
    ref_series = ""
    ref_sop = ""
    try:
        if modality == "RTSTRUCT":
            seq = ds.get("ReferencedFrameOfReferenceSequence", [])
            if seq:
                item = seq[0]
                for_uid = for_uid or _str(item, "FrameOfReferenceUID")
                studies = item.get("RTReferencedStudySequence", [])
                if studies:
                    series = studies[0].get("RTReferencedSeriesSequence", [])
                    if series:
                        ref_series = _str(series[0], "SeriesInstanceUID")
            if not for_uid:
                rois = ds.get("StructureSetROISequence", [])
                if rois:
                    for_uid = _str(rois[0], "ReferencedFrameOfReferenceUID")
        elif modality == "RTDOSE":
            seq = ds.get("ReferencedRTPlanSequence", [])
            if seq:
                ref_sop = _str(seq[0], "ReferencedSOPInstanceUID")
        elif modality == "RTPLAN":
            seq = ds.get("ReferencedStructureSetSequence", [])
            if seq:
                ref_sop = _str(seq[0], "ReferencedSOPInstanceUID")
    except Exception as exc:  # malformed sequences must never abort a scan
        logger.debug("reference extraction failed: %s", exc)
    return for_uid, ref_series, ref_sop


def read_header(path: Path) -> DicomHeader | None:
    import pydicom

    path = Path(path)
    try:
        ds = pydicom.dcmread(str(path), stop_before_pixels=True, force=True)
    except Exception as exc:
        logger.debug("not readable as DICOM: %s (%s)", path, exc)
        return None
    sop_class = _str(ds, "SOPClassUID")
    if not sop_class:
        return None
    modality = _str(ds, "Modality").upper()
    for_uid, ref_series, ref_sop = _rt_refs(ds, modality)
    label = ""
    if modality == "RTSTRUCT":
        label = _str(ds, "StructureSetLabel")
    elif modality == "RTPLAN":
        label = _str(ds, "RTPlanLabel")
    elif modality == "RTDOSE":
        label = _str(ds, "DoseSummationType")
    key_tags = {}
    for name in KEY_TAGS:
        if name in ds:
            v = ds.get(name)
            try:
                key_tags[name] = [float(x) for x in v] if hasattr(v, "__iter__") and \
                    not isinstance(v, (str, bytes)) else (str(v) if v is not None else "")
            except (TypeError, ValueError):
                key_tags[name] = str(v)
    try:
        size = path.stat().st_size
    except OSError:
        size = 0
    return DicomHeader(
        path=path, size=size,
        sop_instance_uid=_str(ds, "SOPInstanceUID"), sop_class_uid=sop_class,
        series_uid=_str(ds, "SeriesInstanceUID"), study_uid=_str(ds, "StudyInstanceUID"),
        for_uid=for_uid, modality=modality,
        series_number=_int(ds, "SeriesNumber"), instance_number=_int(ds, "InstanceNumber"),
        series_description=_str(ds, "SeriesDescription"), protocol_name=_str(ds, "ProtocolName"),
        study_date=_str(ds, "StudyDate"), study_description=_str(ds, "StudyDescription"),
        patient_id=_str(ds, "PatientID"), patient_name=_str(ds, "PatientName"),
        trial_protocol_id=_str(ds, "ClinicalTrialProtocolID"),
        trial_subject_id=_str(ds, "ClinicalTrialSubjectID"),
        trial_site_id=_str(ds, "ClinicalTrialSiteID"),
        label=label, ref_series_uid=ref_series, ref_sop_uid=ref_sop, key_tags=key_tags,
    )


# ---------------------------------------------------------------------------
# walking a drop
# ---------------------------------------------------------------------------

def folder_hints_for(file_path: Path, drop_root: Path, extra_first: list[str] | None = None,
                     drop_name: str | None = None) -> list[str]:
    """Ancestor directory names relative to the drop root, nearest first, then the drop name."""
    try:
        relparts = Path(file_path).resolve().relative_to(Path(drop_root).resolve()).parts[:-1]
    except ValueError:
        relparts = ()
    hints: list[str] = list(extra_first or [])
    hints.extend(reversed(relparts))
    name = drop_name if drop_name is not None else Path(drop_root).name
    if name:
        hints.append(name)
    out: list[str] = []
    for h in hints:
        if h and h not in out:
            out.append(h)
    return out


def _safe_extract(zpath: Path, dest: Path) -> int:
    dest.mkdir(parents=True, exist_ok=True)
    n = 0
    with zipfile.ZipFile(zpath) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            target = (dest / info.filename).resolve()
            if dest.resolve() not in target.parents:
                raise ValueError(f"zip-slip entry rejected: {info.filename} in {zpath}")
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, open(target, "wb") as dst:
                while True:
                    chunk = src.read(1 << 20)
                    if not chunk:
                        break
                    dst.write(chunk)
            n += 1
    return n


def scan_tree(drop: Path, cfg: StoreConfig, extract_dir: Path | None = None,
              _depth: int = 0, _hint_prefix: list[str] | None = None,
              _source_prefix: str = "", _drop_name: str | None = None,
              result: ScanResult | None = None) -> ScanResult:
    """Scan one drop (file or folder). Archives are extracted into ``extract_dir`` if given."""
    drop = Path(drop)
    res = result if result is not None else ScanResult()
    headers: list[DicomHeader] = []
    drop_name = drop.name if _drop_name is None else _drop_name
    for f in iter_files(drop, cfg.ignore_globs):
        if is_ignored(f.name, cfg.ignore_globs):
            res.ignored.append(f)
            continue
        try:
            rel_src = f.relative_to(drop).as_posix() if drop.is_dir() else f.name
        except ValueError:
            rel_src = f.name
        source_relpath = f"{_source_prefix}{rel_src}" if _source_prefix else rel_src
        kind = sniff(f)
        hints = folder_hints_for(f, drop if drop.is_dir() else drop.parent, _hint_prefix,
                                 drop_name)
        if kind == "dicom":
            h = read_header(f)
            if h is None:
                res.unreadable.append(OtherFile(f, f.stat().st_size, "dicom_unreadable", hints,
                                                source_relpath))
                continue
            if h.sop_class_uid == DICOMDIR_SOP:
                res.ignored.append(f)
                continue
            h.folder_hints = hints
            h.source_relpath = source_relpath
            headers.append(h)
        elif kind == "zip" and extract_dir is not None and _depth < MAX_ZIP_DEPTH:
            res.archives.append(f)
            sub = extract_dir / f"{f.stem}-{_depth}"
            try:
                n = _safe_extract(f, sub)
            except (zipfile.BadZipFile, ValueError, OSError) as exc:
                logger.warning("archive %s not extracted: %s", f, exc)
                res.others.append(OtherFile(f, f.stat().st_size, "zip", hints, source_relpath))
                continue
            logger.info("extracted %d entries from %s", n, f)
            scan_tree(sub, cfg, extract_dir, _depth + 1, [f.stem, *hints[:-1]],
                      f"{source_relpath}!/", drop_name, res)
        else:
            try:
                size = f.stat().st_size
            except OSError:
                size = 0
            res.others.append(OtherFile(f, size, kind, hints, source_relpath))
    res.groups.extend(group_instances(headers))
    return res


# ---------------------------------------------------------------------------
# grouping
# ---------------------------------------------------------------------------

def _merge_hints(groups_hints: Iterable[list[str]]) -> list[str]:
    out: list[str] = []
    for hints in groups_hints:
        for h in hints:
            if h not in out:
                out.append(h)
    return out


def group_instances(headers: Iterable[DicomHeader]) -> list[SeriesGroup]:
    buckets: dict[tuple[str, str, str, str], list[DicomHeader]] = OrderedDict()
    for h in headers:
        key = (h.patient_id, h.study_uid, h.series_uid or "UNKNOWN", h.for_uid)
        buckets.setdefault(key, []).append(h)
    by_series: dict[str, list[tuple]] = {}
    for key in buckets:
        by_series.setdefault(key[2], []).append(key)
    groups: list[SeriesGroup] = []
    for key, hs in buckets.items():
        hs.sort(key=lambda h: (h.instance_number if h.instance_number is not None else 1 << 30,
                               str(h.path)))
        g = SeriesGroup(key=key, headers=hs)
        g.modality = next((h.modality for h in hs if h.modality), "") or "OT"
        g.folder_hints = _merge_hints(h.folder_hints for h in hs)
        if len(by_series.get(key[2], [])) > 1:
            g.problems.append("series UID shared across different patient/study/frame-of-reference")
        if len({h.modality for h in hs}) > 1:
            g.problems.append("mixed modalities within one series")
        # duplicate SOP instances inside the drop
        seen: dict[str, DicomHeader] = {}
        keep: list[DicomHeader] = []
        for h in hs:
            if not h.sop_instance_uid:
                keep.append(h)
                continue
            prev = seen.get(h.sop_instance_uid)
            if prev is None:
                seen[h.sop_instance_uid] = h
                keep.append(h)
                continue
            if not prev.sha256:
                prev.sha256 = sha256_file(prev.path)
            h.sha256 = sha256_file(h.path)
            if h.sha256 == prev.sha256:
                g.dropped_duplicates.append(h)
            else:
                g.problems.append(f"duplicate SOPInstanceUID with different content: "
                                  f"{h.sop_instance_uid}")
                keep.append(h)
        g.headers = keep
        groups.append(g)
    return groups
