"""Filesystem helpers that are safe on SMB shares: verified copies, retries, settle checks."""

from __future__ import annotations

import fnmatch
import hashlib
import logging
import os
import shutil
import time
from collections.abc import Iterable
from pathlib import Path

logger = logging.getLogger(__name__)

CHUNK = 4 * 1024 * 1024
RETRY_DELAYS = (2.0, 8.0, 30.0)


class CopyError(OSError):
    """A verified copy failed after all retries."""


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _copy_once(src: Path, dst: Path, verify_full: bool) -> str:
    part = dst.with_name(dst.name + ".part")
    dst.parent.mkdir(parents=True, exist_ok=True)
    h = hashlib.sha256()
    size = 0
    with open(src, "rb") as fi, open(part, "wb") as fo:
        for chunk in iter(lambda: fi.read(CHUNK), b""):
            h.update(chunk)
            fo.write(chunk)
            size += len(chunk)
        fo.flush()
        os.fsync(fo.fileno())
    digest = h.hexdigest()
    if part.stat().st_size != size:
        raise CopyError(f"size mismatch after copy: {src} -> {part}")
    if verify_full and sha256_file(part) != digest:
        raise CopyError(f"sha256 mismatch after copy: {src} -> {part}")
    os.replace(part, dst)
    return digest


def copy_verified(src: Path, dst: Path, verify_full: bool = True,
                  delays: Iterable[float] = RETRY_DELAYS, sleep=time.sleep) -> str:
    """Copy ``src`` to ``dst`` via a ``.part`` file, verify, retry on OSError. Returns sha256."""
    last: Exception | None = None
    for attempt, delay in enumerate([0.0, *delays]):
        if delay:
            logger.warning("retrying copy of %s in %.0fs (attempt %d): %s", src, delay, attempt + 1,
                           last)
            sleep(delay)
        try:
            return _copy_once(Path(src), Path(dst), verify_full)
        except OSError as exc:  # includes CopyError
            last = exc
            part = Path(dst).with_name(Path(dst).name + ".part")
            try:
                if part.exists():
                    part.unlink()
            except OSError:
                pass
    raise CopyError(f"copy failed after retries: {src} -> {dst}: {last}") from last


def move_file(src: Path, dst: Path) -> None:
    """Rename within a volume; fall back to verified copy + delete."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.replace(src, dst)
    except OSError:
        copy_verified(src, dst, verify_full=True)
        os.unlink(src)


def remove_tree(path: Path) -> None:
    def _onerror(func, p, exc_info):
        try:
            os.chmod(p, 0o700)
            func(p)
        except OSError:
            logger.warning("could not remove %s", p)

    if path.exists():
        shutil.rmtree(path, onerror=_onerror)


def is_ignored(name: str, globs: Iterable[str]) -> bool:
    return any(fnmatch.fnmatch(name, g) or fnmatch.fnmatch(name.lower(), g.lower()) for g in globs)


def iter_files(root: Path, ignore_globs: Iterable[str] = ()) -> Iterable[Path]:
    root = Path(root)
    if root.is_file():
        if not is_ignored(root.name, ignore_globs):
            yield root
        return
    globs = list(ignore_globs)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if not is_ignored(d, globs))
        for fn in sorted(filenames):
            if not is_ignored(fn, globs):
                yield Path(dirpath) / fn


def is_settled(path: Path, settle_seconds: int, ignore_globs: Iterable[str] = (),
               now: float | None = None) -> bool:
    """True when no file under ``path`` changed within ``settle_seconds`` and all are openable."""
    now = time.time() if now is None else now
    try:
        for f in iter_files(path, ignore_globs):
            st = f.stat()
            if now - st.st_mtime < settle_seconds:
                return False
            with open(f, "rb+"):
                pass
    except OSError:
        return False
    return True


def dir_size(path: Path) -> int:
    return sum(f.stat().st_size for f in iter_files(path))


def atomic_write_text(path: Path, text: str) -> None:
    part = path.with_name(path.name + ".part")
    with open(part, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(part, path)


def append_line(path: Path, line: str) -> None:
    with open(path, "a", encoding="utf-8", newline="\n") as fh:
        fh.write(line.rstrip("\n") + "\n")
        fh.flush()
        os.fsync(fh.fileno())
