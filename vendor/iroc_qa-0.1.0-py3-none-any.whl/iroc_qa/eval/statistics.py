"""Percentile statistics for QA reporting.

Computes the standard RTOG percentile set (P1, P2, P5, P10, P15, P85, P90,
P95, P98, P99) used across all IROC evaluation tools.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

RTOG_PERCENTILES = [1, 2, 5, 10, 15, 85, 90, 95, 98, 99]


def compute_percentiles(
    values: np.ndarray | pd.Series,
    percentiles: list[int] | None = None,
) -> dict[str, float]:
    """Compute percentile statistics for a numeric array.

    Parameters
    ----------
    values : array-like
        Numeric values (NaN/inf are excluded).
    percentiles : list of int, optional
        Percentile levels to compute.  Defaults to RTOG standard set.

    Returns
    -------
    dict
        ``{"P1": value, "P2": value, ...}``.
    """
    if percentiles is None:
        percentiles = RTOG_PERCENTILES

    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]

    if len(arr) == 0:
        return {f"P{p}": float("nan") for p in percentiles}

    return {
        f"P{p}": float(np.percentile(arr, p))
        for p in percentiles
    }


def summarize_scores(
    data: pd.DataFrame,
    score_columns: list[str],
    unacceptable_value: int = 3,
) -> pd.DataFrame:
    """Compute unacceptable rate per score column.

    Parameters
    ----------
    data : DataFrame
        Rows are cases, columns include the score columns.
    score_columns : list of str
        Which columns contain QA scores.
    unacceptable_value : int
        Score value meaning "unacceptable" (default 3, per RTOG convention).

    Returns
    -------
    DataFrame
        One row per score column with count, total, and unacceptable rate.
    """
    rows = []
    for col in score_columns:
        if col not in data.columns:
            continue
        valid = data[col].dropna()
        total = len(valid)
        n_unacc = int((valid == unacceptable_value).sum())
        rate = n_unacc / total if total > 0 else 0.0
        rows.append({
            "Metric": col,
            "Total": total,
            "Unacceptable": n_unacc,
            "Unacceptable_Rate": rate,
        })
    return pd.DataFrame(rows)
