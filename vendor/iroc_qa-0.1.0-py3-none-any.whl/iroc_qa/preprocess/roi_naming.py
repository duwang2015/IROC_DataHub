"""ROI name standardization to AAPM TG-263 nomenclature.

Maps institution-specific structure names to the standardized naming
convention defined in AAPM Task Group 263 (2018).  Supports exact,
case-insensitive, and fuzzy matching with laterality normalization.

References
----------
- AAPM Report No. 263 (https://www.aapm.org/pubs/reports/RPT_263.pdf)
- TG-263 Supplemental Worksheet
- LAMBDA consortium HN naming variants (PMC9873496)
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path

import pydicom

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# TG-263 alias dictionary
# Maps common institutional variants → TG-263 standard name.
# ---------------------------------------------------------------------------

TG263_ALIASES: dict[str, str] = {
    # === HEAD & NECK ===

    # Parotid glands
    "Parotid_L": "Parotid_L",
    "Left Parotid": "Parotid_L",
    "Lt Parotid": "Parotid_L",
    "L Parotid": "Parotid_L",
    "Parotid Lt": "Parotid_L",
    "Parotid left": "Parotid_L",
    "LT PAROTID": "Parotid_L",
    "L_Parotid": "Parotid_L",
    "ParotidL": "Parotid_L",
    "parotid_l": "Parotid_L",
    "PAROTID_L": "Parotid_L",
    "Parotid_R": "Parotid_R",
    "Right Parotid": "Parotid_R",
    "Rt Parotid": "Parotid_R",
    "R Parotid": "Parotid_R",
    "Parotid Rt": "Parotid_R",
    "Parotid right": "Parotid_R",
    "RT PAROTID": "Parotid_R",
    "R_Parotid": "Parotid_R",
    "ParotidR": "Parotid_R",
    "parotid_r": "Parotid_R",
    "PAROTID_R": "Parotid_R",

    # Submandibular glands
    "Glnd_Submand_L": "Glnd_Submand_L",
    "Submandibular_L": "Glnd_Submand_L",
    "SubMandibular_L": "Glnd_Submand_L",
    "Lt Submandibular": "Glnd_Submand_L",
    "L Submandibular": "Glnd_Submand_L",
    "Submand_L": "Glnd_Submand_L",
    "SMG_L": "Glnd_Submand_L",
    "Left Submandibular": "Glnd_Submand_L",
    "SUBMAND_L": "Glnd_Submand_L",
    "SubMand L": "Glnd_Submand_L",
    "Glnd_Submand_R": "Glnd_Submand_R",
    "Submandibular_R": "Glnd_Submand_R",
    "SubMandibular_R": "Glnd_Submand_R",
    "Rt Submandibular": "Glnd_Submand_R",
    "R Submandibular": "Glnd_Submand_R",
    "Submand_R": "Glnd_Submand_R",
    "SMG_R": "Glnd_Submand_R",
    "Right Submandibular": "Glnd_Submand_R",
    "SUBMAND_R": "Glnd_Submand_R",
    "SubMand R": "Glnd_Submand_R",

    # Mandible
    "Bone_Mandible": "Bone_Mandible",
    "Mandible": "Bone_Mandible",
    "MANDIBLE": "Bone_Mandible",
    "mandible": "Bone_Mandible",
    "Jaw": "Bone_Mandible",
    "Mandible_Bone": "Bone_Mandible",

    # Spinal cord
    "SpinalCord": "SpinalCord",
    "Spinal Cord": "SpinalCord",
    "SPINAL CORD": "SpinalCord",
    "Cord": "SpinalCord",
    "CORD": "SpinalCord",
    "cord": "SpinalCord",
    "Spinal_Cord": "SpinalCord",
    "SC": "SpinalCord",
    "SpinalCanal": "SpinalCord",

    # Brainstem
    "Brainstem": "Brainstem",
    "Brain Stem": "Brainstem",
    "BrainStem": "Brainstem",
    "BRAINSTEM": "Brainstem",
    "brainstem": "Brainstem",
    "Brain_Stem": "Brainstem",
    "BStem": "Brainstem",
    "BRAIN STEM": "Brainstem",

    # Larynx
    "Larynx": "Larynx",
    "LARYNX": "Larynx",
    "larynx": "Larynx",
    "Larynx_SG": "Larynx_SG",
    "Larynx_G": "Larynx_G",

    # Oral cavity
    "Cavity_Oral": "Cavity_Oral",
    "Oral_Cavity": "Cavity_Oral",
    "OralCavity": "Cavity_Oral",
    "Oral Cavity": "Cavity_Oral",
    "ORAL CAVITY": "Cavity_Oral",
    "Mouth": "Cavity_Oral",
    "oral_cavity": "Cavity_Oral",

    # Esophagus
    "Esophagus": "Esophagus",
    "ESOPHAGUS": "Esophagus",
    "Oesophagus": "Esophagus",
    "esophagus": "Esophagus",
    "Esoph": "Esophagus",

    # Pharyngeal constrictors
    "Musc_Constrict_S": "Musc_Constrict_S",
    "Constrictor_Sup": "Musc_Constrict_S",
    "Superior Constrictor": "Musc_Constrict_S",
    "Sup_Constrictor": "Musc_Constrict_S",
    "PharConst_S": "Musc_Constrict_S",
    "Musc_Constrict_M": "Musc_Constrict_M",
    "Constrictor_Mid": "Musc_Constrict_M",
    "Middle Constrictor": "Musc_Constrict_M",
    "PharConst_M": "Musc_Constrict_M",
    "Musc_Constrict_I": "Musc_Constrict_I",
    "Constrictor_Inf": "Musc_Constrict_I",
    "Inferior Constrictor": "Musc_Constrict_I",
    "PharConst_I": "Musc_Constrict_I",

    # Thyroid
    "Glnd_Thyroid": "Glnd_Thyroid",
    "Thyroid": "Glnd_Thyroid",
    "THYROID": "Glnd_Thyroid",
    "thyroid": "Glnd_Thyroid",
    "Thyroid_Gland": "Glnd_Thyroid",

    # Hyoid
    "Bone_Hyoid": "Bone_Hyoid",
    "Hyoid": "Bone_Hyoid",
    "HYOID": "Bone_Hyoid",
    "Hyoid_Bone": "Bone_Hyoid",

    # Pharynx
    "Pharynx": "Pharynx",
    "PHARYNX": "Pharynx",
    "pharynx": "Pharynx",

    # Lips
    "Lips": "Lips",
    "LIPS": "Lips",
    "lips": "Lips",
    "Lip": "Lips",

    # Brachial plexus
    "BrachialPlex_L": "BrachialPlex_L",
    "BrachialPlexus_L": "BrachialPlex_L",
    "Brachial_Plexus_L": "BrachialPlex_L",
    "L Brachial Plexus": "BrachialPlex_L",
    "BP_L": "BrachialPlex_L",
    "BrachialPlex_R": "BrachialPlex_R",
    "BrachialPlexus_R": "BrachialPlex_R",
    "Brachial_Plexus_R": "BrachialPlex_R",
    "R Brachial Plexus": "BrachialPlex_R",
    "BP_R": "BrachialPlex_R",

    # Lacrimal glands
    "Glnd_Lacrimal_L": "Glnd_Lacrimal_L",
    "Lacrimal_L": "Glnd_Lacrimal_L",
    "Lt Lacrimal": "Glnd_Lacrimal_L",
    "L Lacrimal Gland": "Glnd_Lacrimal_L",
    "Glnd_Lacrimal_R": "Glnd_Lacrimal_R",
    "Lacrimal_R": "Glnd_Lacrimal_R",
    "Rt Lacrimal": "Glnd_Lacrimal_R",
    "R Lacrimal Gland": "Glnd_Lacrimal_R",

    # === BRAIN / GBM ===

    # Brain
    "Brain": "Brain",
    "BRAIN": "Brain",
    "brain": "Brain",
    "WholeBrain": "Brain",
    "Whole_Brain": "Brain",
    "BrainMask": "Brain",
    "Cerebrum": "Brain",

    # Optic chiasm
    "OpticChiasm": "OpticChiasm",
    "Optic_Chiasm": "OpticChiasm",
    "Chiasm": "OpticChiasm",
    "CHIASM": "OpticChiasm",
    "chiasm": "OpticChiasm",
    "Optic Chiasm": "OpticChiasm",
    "OC": "OpticChiasm",
    "OpticXiasm": "OpticChiasm",

    # Optic nerves (TG-263 abbreviates to OpticNrv)
    "OpticNrv_L": "OpticNrv_L",
    "OpticNerve_L": "OpticNrv_L",
    "Optic_Nerve_L": "OpticNrv_L",
    "L Optic Nerve": "OpticNrv_L",
    "Lt Optic Nerve": "OpticNrv_L",
    "Left Optic Nerve": "OpticNrv_L",
    "ON_L": "OpticNrv_L",
    "OpticN_L": "OpticNrv_L",
    "OPTIC NERVE L": "OpticNrv_L",
    "OpticNrv_R": "OpticNrv_R",
    "OpticNerve_R": "OpticNrv_R",
    "Optic_Nerve_R": "OpticNrv_R",
    "R Optic Nerve": "OpticNrv_R",
    "Rt Optic Nerve": "OpticNrv_R",
    "Right Optic Nerve": "OpticNrv_R",
    "ON_R": "OpticNrv_R",
    "OpticN_R": "OpticNrv_R",
    "OPTIC NERVE R": "OpticNrv_R",

    # Eyes
    "Eye_L": "Eye_L",
    "Globe_L": "Eye_L",
    "L Eye": "Eye_L",
    "Lt Eye": "Eye_L",
    "Left Eye": "Eye_L",
    "EYE_L": "Eye_L",
    "eye_l": "Eye_L",
    "Left Globe": "Eye_L",
    "Eye_R": "Eye_R",
    "Globe_R": "Eye_R",
    "R Eye": "Eye_R",
    "Rt Eye": "Eye_R",
    "Right Eye": "Eye_R",
    "EYE_R": "Eye_R",
    "eye_r": "Eye_R",
    "Right Globe": "Eye_R",

    # Lenses
    "Lens_L": "Lens_L",
    "L Lens": "Lens_L",
    "Lt Lens": "Lens_L",
    "Left Lens": "Lens_L",
    "LENS_L": "Lens_L",
    "lens_l": "Lens_L",
    "Lens_R": "Lens_R",
    "R Lens": "Lens_R",
    "Rt Lens": "Lens_R",
    "Right Lens": "Lens_R",
    "LENS_R": "Lens_R",
    "lens_r": "Lens_R",

    # Cochlea
    "Cochlea_L": "Cochlea_L",
    "L Cochlea": "Cochlea_L",
    "Lt Cochlea": "Cochlea_L",
    "Left Cochlea": "Cochlea_L",
    "COCHLEA_L": "Cochlea_L",
    "cochlea_l": "Cochlea_L",
    "InnerEar_L": "Cochlea_L",
    "Cochlea_R": "Cochlea_R",
    "R Cochlea": "Cochlea_R",
    "Rt Cochlea": "Cochlea_R",
    "Right Cochlea": "Cochlea_R",
    "COCHLEA_R": "Cochlea_R",
    "cochlea_r": "Cochlea_R",
    "InnerEar_R": "Cochlea_R",

    # Pituitary
    "Pituitary": "Pituitary",
    "PITUITARY": "Pituitary",
    "pituitary": "Pituitary",
    "Glnd_Pituitary": "Pituitary",
    "Pituitary_Gland": "Pituitary",

    # Hippocampus
    "Hippocampus_L": "Hippocampus_L",
    "L Hippocampus": "Hippocampus_L",
    "Hippocampus Lt": "Hippocampus_L",
    "HIPPOCAMPUS_L": "Hippocampus_L",
    "Hippocampus_R": "Hippocampus_R",
    "R Hippocampus": "Hippocampus_R",
    "Hippocampus Rt": "Hippocampus_R",
    "HIPPOCAMPUS_R": "Hippocampus_R",

    # Cerebellum
    "Cerebellum": "Cerebellum",
    "CEREBELLUM": "Cerebellum",
    "cerebellum": "Cerebellum",

    # Temporal lobes
    "TemporalLobe_L": "TemporalLobe_L",
    "TempLobe_L": "TemporalLobe_L",
    "L Temporal Lobe": "TemporalLobe_L",
    "TemporalLobe_R": "TemporalLobe_R",
    "TempLobe_R": "TemporalLobe_R",
    "R Temporal Lobe": "TemporalLobe_R",

    # Retina
    "Retina_L": "Retina_L",
    "L Retina": "Retina_L",
    "Retina Lt": "Retina_L",
    "Retina_R": "Retina_R",
    "R Retina": "Retina_R",
    "Retina Rt": "Retina_R",

    # Cranial nerves
    "CN_V_L": "CN_V_L",
    "Trigeminal_L": "CN_V_L",
    "CN_V_R": "CN_V_R",
    "Trigeminal_R": "CN_V_R",
    "CN_VII_L": "CN_VII_L",
    "FacialNerve_L": "CN_VII_L",
    "CN_VII_R": "CN_VII_R",
    "FacialNerve_R": "CN_VII_R",
    "CN_VIII_L": "CN_VIII_L",
    "AcousticNerve_L": "CN_VIII_L",
    "VestibuloCochlear_L": "CN_VIII_L",
    "CN_VIII_R": "CN_VIII_R",
    "AcousticNerve_R": "CN_VIII_R",
    "VestibuloCochlear_R": "CN_VIII_R",

    # === THORAX / ABDOMEN / PELVIS ===

    # Lungs
    "Lung_L": "Lung_L",
    "L Lung": "Lung_L",
    "Lt Lung": "Lung_L",
    "Left Lung": "Lung_L",
    "LUNG_L": "Lung_L",
    "lung_l": "Lung_L",
    "Lung_R": "Lung_R",
    "R Lung": "Lung_R",
    "Rt Lung": "Lung_R",
    "Right Lung": "Lung_R",
    "LUNG_R": "Lung_R",
    "lung_r": "Lung_R",
    "Lungs": "Lungs",
    "Total Lung": "Lungs",
    "Both Lungs": "Lungs",
    "LUNGS": "Lungs",
    "Lung_Total": "Lungs",
    "BilateralLung": "Lungs",

    # Heart
    "Heart": "Heart",
    "HEART": "Heart",
    "heart": "Heart",
    "Cardiac": "Heart",

    # Liver
    "Liver": "Liver",
    "LIVER": "Liver",
    "liver": "Liver",

    # Kidneys
    "Kidney_L": "Kidney_L",
    "L Kidney": "Kidney_L",
    "Lt Kidney": "Kidney_L",
    "Left Kidney": "Kidney_L",
    "KIDNEY_L": "Kidney_L",
    "Kidney_R": "Kidney_R",
    "R Kidney": "Kidney_R",
    "Rt Kidney": "Kidney_R",
    "Right Kidney": "Kidney_R",
    "KIDNEY_R": "Kidney_R",
    "Kidneys": "Kidneys",
    "Both Kidneys": "Kidneys",
    "KIDNEYS": "Kidneys",

    # Femur
    "Femur_L": "Femur_L",
    "FEMORAL LT": "Femur_L",
    "Femur_LT": "Femur_L",
    "Femoral Head Lt": "Femur_L",
    "Lt Fem Head": "Femur_L",
    "LFH": "Femur_L",
    "left_femhead": "Femur_L",
    "L_FEM HEAD": "Femur_L",
    "Femur L": "Femur_L",
    "Hip Left": "Femur_L",
    "Femur_R": "Femur_R",
    "FEMORAL RT": "Femur_R",
    "Femur_RT": "Femur_R",
    "Femoral Head Rt": "Femur_R",
    "Rt Fem Head": "Femur_R",
    "RFH": "Femur_R",
    "right_femhead": "Femur_R",
    "R_FEM HEAD": "Femur_R",
    "Femur R": "Femur_R",
    "Hip Right": "Femur_R",

    # Bladder / Rectum / Bowel
    "Bladder": "Bladder",
    "BLADDER": "Bladder",
    "bladder": "Bladder",
    "Urinary_Bladder": "Bladder",
    "Rectum": "Rectum",
    "RECTUM": "Rectum",
    "rectum": "Rectum",
    "SmallBowel": "SmallBowel",
    "Small_Bowel": "SmallBowel",
    "SMALL BOWEL": "SmallBowel",
    "Bowel_Small": "SmallBowel",
    "SBowel": "SmallBowel",
    "LargeBowel": "LargeBowel",
    "Large_Bowel": "LargeBowel",
    "Colon": "LargeBowel",
    "LARGE BOWEL": "LargeBowel",
    "Bowel_LG": "LargeBowel",
    "Spc_Bowel": "Spc_Bowel",
    "Bowel_Bag": "Spc_Bowel",
    "BowelBag": "Spc_Bowel",
    "Bowel": "Spc_Bowel",
    "BOWEL": "Spc_Bowel",
    "Penile_Bulb": "Penile_Bulb",
    "PenileBulb": "Penile_Bulb",
    "Penile Bulb": "Penile_Bulb",
    "PENILE_BULB": "Penile_Bulb",

    # External / body contour
    "External": "External",
    "EXTERNAL": "External",
    "Body": "External",
    "BODY": "External",
    "Outer": "External",
    "body": "External",

    # === TARGET VOLUMES (pass-through) ===
    "GTV": "GTV",
    "CTV": "CTV",
    "PTV": "PTV",
    "ITV": "ITV",
}

# Set of all valid TG-263 standard names (values in the alias dict)
TG263_STANDARD_NAMES: set[str] = set(TG263_ALIASES.values())

# Pre-built case-insensitive lookup: lowered key → standard name
_LOWER_LOOKUP: dict[str, str] = {k.lower(): v for k, v in TG263_ALIASES.items()}


# ---------------------------------------------------------------------------
# Fuzzy normalization helpers
# ---------------------------------------------------------------------------

_LATERALITY_MAP = {
    "left": "l", "right": "r",
    "lt": "l", "rt": "r",
    "lft": "l", "rgt": "r",
}

_LATERALITY_RE = re.compile(
    r"\b(left|right|lt|rt|lft|rgt)\b", re.IGNORECASE,
)


def _normalize_key(name: str) -> str:
    """Normalize a name for fuzzy matching.

    1. Lowercase
    2. Strip dots, commas
    3. Collapse whitespace/underscores/hyphens to single underscore
    4. Normalize laterality words to single letter
    """
    s = name.lower().strip()
    s = s.replace(".", "").replace(",", "")

    # Normalize laterality words
    def _replace_lat(m):
        return _LATERALITY_MAP.get(m.group(0).lower(), m.group(0))

    s = _LATERALITY_RE.sub(_replace_lat, s)

    # Collapse separators
    s = re.sub(r"[\s_\-]+", "_", s)
    s = s.strip("_")
    return s


# Pre-built fuzzy lookup: normalized key → standard name
_FUZZY_LOOKUP: dict[str, str] = {}
for _alias, _standard in TG263_ALIASES.items():
    _nk = _normalize_key(_alias)
    if _nk not in _FUZZY_LOOKUP:
        _FUZZY_LOOKUP[_nk] = _standard


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def standardize_name(name: str) -> tuple[str, str]:
    """Map a single ROI name to TG-263 standard.

    Parameters
    ----------
    name : str
        Institution-specific ROI name.

    Returns
    -------
    (standard_name, confidence)
        confidence is one of: "exact", "case", "fuzzy", "unknown".
        If "unknown", standard_name == original name (unchanged).
    """
    # Step 1: exact match
    if name in TG263_ALIASES:
        return TG263_ALIASES[name], "exact"

    # Step 2: case-insensitive match
    lower = name.lower()
    if lower in _LOWER_LOOKUP:
        return _LOWER_LOOKUP[lower], "case"

    # Step 3: fuzzy match (normalize separators + laterality)
    normed = _normalize_key(name)
    if normed in _FUZZY_LOOKUP:
        return _FUZZY_LOOKUP[normed], "fuzzy"

    return name, "unknown"


def standardize_names(
    names: list[str],
) -> dict[str, tuple[str, str]]:
    """Batch standardize ROI names.

    Returns dict mapping each input name to (standard_name, confidence).
    """
    return {n: standardize_name(n) for n in names}


def check_compliance(names: list[str]) -> dict:
    """Check TG-263 compliance for a list of ROI names.

    Returns
    -------
    dict with keys:
        compliant   : list of (name, standard_name) that matched
        non_compliant: list of (name, suggested_name, confidence) that
                       matched but differ from input
        unknown     : list of names with no match
        compliance_pct: float (0-100)
    """
    compliant = []
    non_compliant = []
    unknown = []

    for name in names:
        std, conf = standardize_name(name)
        if conf == "unknown":
            unknown.append(name)
        elif std == name:
            compliant.append((name, std))
        else:
            non_compliant.append((name, std, conf))

    total = len(names) if names else 1
    pct = len(compliant) / total * 100

    return {
        "compliant": compliant,
        "non_compliant": non_compliant,
        "unknown": unknown,
        "compliance_pct": pct,
    }


def rename_rtstruct_rois(
    rtstruct_path: str | Path,
    mapping: dict[str, str],
    output_path: str | Path,
) -> list[tuple[str, str]]:
    """Apply name mapping to RTSTRUCT DICOM file.

    Parameters
    ----------
    rtstruct_path : path
        Input RTSTRUCT DICOM file.
    mapping : dict
        Old name → new name mapping.  Names not in the mapping are
        left unchanged.
    output_path : path
        Where to save the modified RTSTRUCT.

    Returns
    -------
    List of (old_name, new_name) for all ROIs that were renamed.
    """
    rtstruct_path = Path(rtstruct_path)
    output_path = Path(output_path)

    if not rtstruct_path.exists():
        raise FileNotFoundError(f"RTSTRUCT not found: {rtstruct_path}")

    ds = pydicom.dcmread(str(rtstruct_path))
    renamed = []

    if hasattr(ds, "StructureSetROISequence"):
        for roi in ds.StructureSetROISequence:
            old_name = getattr(roi, "ROIName", "")
            if old_name in mapping:
                new_name = mapping[old_name]
                roi.ROIName = new_name
                renamed.append((old_name, new_name))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    ds.save_as(str(output_path))
    logger.info(
        "Renamed %d ROIs in RTSTRUCT: %s -> %s",
        len(renamed), rtstruct_path, output_path,
    )
    return renamed


def rename_nifti_labels(
    roi_json_path: str | Path,
    mapping: dict[str, str],
    output_path: str | Path | None = None,
) -> dict[str, str]:
    """Update ROI mapping JSON to use standardized names.

    Parameters
    ----------
    roi_json_path : path
        JSON file mapping label int (as string key) → ROI name.
    mapping : dict
        Old ROI name → new ROI name.
    output_path : path, optional
        Where to write the updated JSON.  Defaults to overwriting input.

    Returns
    -------
    Updated mapping dict (string keys → new ROI names).
    """
    roi_json_path = Path(roi_json_path)
    if not roi_json_path.exists():
        raise FileNotFoundError(f"ROI JSON not found: {roi_json_path}")

    with open(roi_json_path, encoding="utf-8") as f:
        raw = json.load(f)

    updated = {}
    for label_key, roi_name in raw.items():
        new_name = mapping.get(roi_name, roi_name)
        updated[label_key] = new_name

    out = Path(output_path) if output_path else roi_json_path
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(updated, f, indent=2, ensure_ascii=False)

    logger.info("Updated ROI JSON: %s", out)
    return updated


def auto_standardize_rtstruct(
    rtstruct_path: str | Path,
    output_path: str | Path,
) -> dict:
    """Auto-detect and apply TG-263 standardization to an RTSTRUCT.

    Reads all ROI names, standardizes each, and saves a new RTSTRUCT
    with the mapped names.

    Returns compliance report (same format as check_compliance).
    """
    rtstruct_path = Path(rtstruct_path)
    if not rtstruct_path.exists():
        raise FileNotFoundError(f"RTSTRUCT not found: {rtstruct_path}")

    ds = pydicom.dcmread(str(rtstruct_path))
    names = []
    if hasattr(ds, "StructureSetROISequence"):
        names = [
            getattr(roi, "ROIName", "") for roi in ds.StructureSetROISequence
        ]

    report = check_compliance(names)

    # Build mapping from non-compliant names
    mapping = {old: new for old, new, _ in report["non_compliant"]}
    if mapping:
        rename_rtstruct_rois(rtstruct_path, mapping, output_path)
    else:
        # No changes needed; copy as-is
        ds.save_as(str(output_path))

    return report
