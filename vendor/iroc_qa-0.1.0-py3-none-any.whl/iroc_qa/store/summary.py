"""Per-run ingest summaries written to ``_reports/`` as Markdown and JSON."""

from __future__ import annotations

import json
import secrets
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

from .fsutil import atomic_write_text

if TYPE_CHECKING:
    from .ingest import IngestReport

SUMMARY_SCHEMA = "iroc-store.ingest-summary/1"


def summary_name(started: datetime, mode: str, run_id: str = "", dry_run: bool = False) -> str:
    tag = "-dry" if dry_run else ""
    suffix = f"-{run_id}" if run_id else ""
    return f"{mode}{tag}-{started:%Y%m%d-%H%M%S}{suffix}"


def report_to_dict(rep: IngestReport, started: datetime, finished: datetime, mode: str,
                   user: str, host: str, root: Path) -> dict:
    drops = []
    for d in rep.drops:
        drops.append({
            "source": str(d.drop), "ingest_id": d.ingest_id, "dry_run": d.dry_run,
            "skipped_unsettled": d.skipped_unsettled, "n_files_scanned": d.n_files_scanned,
            "batches": d.batches, "held": d.held, "duplicates": d.duplicates,
            "failures": d.failures, "removed_source": d.removed_source,
        })
    return {
        "schema": SUMMARY_SCHEMA, "mode": mode, "run_id": secrets.token_hex(2),
        "dry_run": any(d.dry_run for d in rep.drops),
        "started_at": started.isoformat(timespec="milliseconds"),
        "finished_at": finished.isoformat(timespec="milliseconds"), "user": user, "host": host,
        "root": str(root), "lock_busy": rep.lock_busy,
        "totals": {
            "drops": len(rep.drops), "files_scanned": sum(d.n_files_scanned for d in rep.drops),
            "batches": rep.n_batches, "files_filed": sum(b["n_files"] for d in rep.drops
                                                         for b in d.batches),
            "held_groups": rep.n_held, "duplicates": sum(d.duplicates for d in rep.drops),
            "failures": rep.n_failures,
            "cases": sorted({f"{b['trial']}/{b['case']}" for d in rep.drops for b in d.batches}),
        },
        "drops": drops,
    }


def report_to_markdown(data: dict, resolve_cmd: str = "iroc-store resolve") -> str:
    t = data["totals"]
    mode = {"ingest": "Inbox ingest", "import": "Folder import"}.get(data["mode"], data["mode"])
    dry = any(d["dry_run"] for d in data["drops"])
    lines = [f"# {mode} summary {'(DRY RUN) ' if dry else ''}{data['started_at'][:16]}", "",
             f"- store: `{data['root']}`", f"- by: {data['user']}@{data['host']}",
             f"- started {data['started_at']}, finished {data['finished_at']}", ""]
    if data.get("lock_busy"):
        lines += ["**Nothing done: the store was locked by another ingest.**", ""]
        return "\n".join(lines) + "\n"
    lines += ["## Totals", "",
              "| sources | files scanned | batches created | files filed | duplicates skipped | "
              "holding groups | failures |", "|---|---|---|---|---|---|---|",
              f"| {t['drops']} | {t['files_scanned']} | {t['batches']} | {t['files_filed']} | "
              f"{t['duplicates']} | {t['held_groups']} | {t['failures']} |", ""]
    if t["cases"]:
        lines += ["Cases touched: " + ", ".join(f"`{c}`" for c in t["cases"]), ""]
    for d in data["drops"]:
        lines += [f"## {Path(d['source']).name}", "", f"- source: `{d['source']}`"]
        if d["skipped_unsettled"]:
            lines += ["- **skipped**: files were still changing; will be picked up next run", ""]
            continue
        lines.append(f"- {d['n_files_scanned']} files scanned, {d['duplicates']} already in the "
                     f"store (skipped)" + (", source folder removed" if d["removed_source"]
                                           else ", source left in place"))
        if d["batches"]:
            lines += ["", "| site / collection / case | batch | files | series |",
                      "|---|---|---|---|"]
            for b in d["batches"]:
                mods = ", ".join(f"{m}×{n}" for m, n in sorted(b["modalities"].items()))
                docs = f" + {b['n_documents']} document(s)" if b.get("n_documents") else ""
                site = f"{b['site']} / " if b.get("site") else ""
                lines.append(f"| {site}`{b['trial']}/{b['case']}` | {b['batch']} | "
                             f"{b['n_files']} | {mods or '-'}{docs} |")
        if d["held"]:
            lines += ["", "### Needs human review", ""]
            for h in d["held"]:
                sug = h.get("suggested")
                sug_s = f"{sug[0]}/{sug[1]}" if sug else "?"
                lines.append(f"- **group {h['group_no']}** `{h['reason']}`: {h['summary']} "
                             f"(header says {sug_s})")
                for n in h.get("notes", [])[:2]:
                    lines.append(f"  - {n}")
                lines.append(f"  - `{resolve_cmd} {h['ingest_id']} --group {h['group_no']} "
                             f"--trial {sug[0] if sug else '<TRIAL>'} "
                             f"--case {sug[1] if sug else '<CASE>'}`")
        if d["failures"]:
            lines += ["", "### Failures", ""] + [f"- {f}" for f in d["failures"]]
        lines.append("")
    return "\n".join(lines) + "\n"


def write_summary(reports_dir: Path, data: dict, resolve_cmd: str = "iroc-store resolve") -> Path:
    reports_dir.mkdir(parents=True, exist_ok=True)
    started = datetime.fromisoformat(data["started_at"])
    name = summary_name(started, data["mode"], data.get("run_id", ""), data.get("dry_run", False))
    atomic_write_text(reports_dir / f"{name}.json", json.dumps(data, indent=1, ensure_ascii=False))
    md = reports_dir / f"{name}.md"
    atomic_write_text(md, report_to_markdown(data, resolve_cmd))
    return md


def list_summaries(reports_dir: Path, limit: int = 50) -> list[dict]:
    if not reports_dir.is_dir():
        return []
    out = []
    for p in reports_dir.glob("*.json"):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        out.append({"name": p.stem, "mode": d.get("mode"), "started_at": d.get("started_at"),
                    "finished_at": d.get("finished_at"), "user": d.get("user"),
                    "totals": d.get("totals", {}),
                    "dry_run": bool(d.get("dry_run")) or any(x.get("dry_run")
                                                             for x in d.get("drops", [])),
                    "path": str(p.with_suffix(".md"))})
    out.sort(key=lambda r: (r.get("finished_at") or "", r["name"]), reverse=True)
    return out[:limit]
