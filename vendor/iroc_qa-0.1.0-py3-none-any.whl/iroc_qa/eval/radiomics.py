"""Radiomics feature extraction from NIfTI images.

Pure-numpy/scipy implementation of IBSI-compliant radiomics features:
  - First-order statistics (18 features)
  - Shape (14 features)
  - GLCM — Gray-Level Co-occurrence Matrix (24 features)
  - GLRLM — Gray-Level Run-Length Matrix (16 features)
  - GLSZM — Gray-Level Size Zone Matrix (16 features)

No pyradiomics dependency required.

Usage
-----
    from Eval.radiomics import extract_features, extract_features_batch

    # Single ROI
    features = extract_features("ct.nii.gz", "mask.nii.gz")

    # All ROIs in a label map
    results = extract_features_batch(
        "ct.nii.gz", "labels.nii.gz", {1: "GTV", 2: "Brainstem"}
    )
"""

from __future__ import annotations

import json
import logging
from collections import OrderedDict
from pathlib import Path

import nibabel as nib
import numpy as np
from scipy.ndimage import label as nd_label
from scipy.stats import kurtosis, skew

logger = logging.getLogger(__name__)

# Default bin width for intensity discretization
DEFAULT_BIN_WIDTH = 25


# ============================================================================
# NIfTI loading helpers
# ============================================================================

def _load_image(path: str | Path) -> tuple[np.ndarray, np.ndarray, tuple]:
    """Load NIfTI, return (data, affine, spacing)."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"NIfTI not found: {path}")
    nii = nib.load(str(path))
    data = nii.get_fdata()
    spacing = tuple(float(s) for s in nii.header.get_zooms()[:3])
    return data, nii.affine, spacing


def _load_mask(path: str | Path, label: int | None = None) -> np.ndarray:
    """Load NIfTI mask, return boolean array."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Mask not found: {path}")
    data = nib.load(str(path)).get_fdata()
    if label is not None:
        return np.round(data).astype(int) == label
    return data > 0.5


def _discretize(values: np.ndarray, bin_width: float) -> np.ndarray:
    """Discretize continuous values into integer gray levels (1-based)."""
    vmin = float(values.min())
    gl = np.floor((values - vmin) / bin_width).astype(int) + 1
    return gl


# ============================================================================
# First-Order Features (18)
# ============================================================================

def compute_firstorder_features(
    values: np.ndarray,
    bin_width: float = DEFAULT_BIN_WIDTH,
) -> OrderedDict:
    """Compute 18 IBSI first-order statistical features.

    Parameters
    ----------
    values : 1D array
        Voxel intensity values within the ROI.
    bin_width : float
        Bin width for histogram-based features (Entropy, Uniformity).

    Returns
    -------
    OrderedDict of feature_name -> float.
    """
    if len(values) == 0:
        return OrderedDict()

    n = len(values)
    v = values.astype(np.float64)
    features = OrderedDict()

    features["firstorder_10Percentile"] = float(np.percentile(v, 10))
    features["firstorder_90Percentile"] = float(np.percentile(v, 90))
    features["firstorder_Energy"] = float(np.sum(v ** 2))
    features["firstorder_Mean"] = float(np.mean(v))
    features["firstorder_Median"] = float(np.median(v))
    features["firstorder_Minimum"] = float(np.min(v))
    features["firstorder_Maximum"] = float(np.max(v))
    features["firstorder_Range"] = float(np.ptp(v))
    features["firstorder_Variance"] = float(np.var(v))
    features["firstorder_RootMeanSquared"] = float(np.sqrt(np.mean(v ** 2)))
    features["firstorder_MeanAbsoluteDeviation"] = float(
        np.mean(np.abs(v - np.mean(v))))
    features["firstorder_Skewness"] = (
        float(skew(v, bias=True)) if n > 2 else 0.0)
    features["firstorder_Kurtosis"] = (
        float(kurtosis(v, bias=True, fisher=True)) + 3.0 if n > 3 else 0.0)
    features["firstorder_InterquartileRange"] = float(
        np.percentile(v, 75) - np.percentile(v, 25))

    # Robust Mean Absolute Deviation (10th-90th percentile)
    p10, p90 = np.percentile(v, 10), np.percentile(v, 90)
    robust = v[(v >= p10) & (v <= p90)]
    features["firstorder_RobustMeanAbsoluteDeviation"] = (
        float(np.mean(np.abs(robust - np.mean(robust)))) if len(robust) > 0
        else 0.0)

    features["firstorder_TotalEnergy"] = features["firstorder_Energy"]

    # Histogram-based: Entropy and Uniformity
    val_range = float(np.ptp(v))
    if val_range > 0:
        n_bins = max(1, int(np.ceil(val_range / bin_width)))
        hist, _ = np.histogram(v, bins=n_bins)
        p = hist.astype(float) / hist.sum()
        p = p[p > 0]
        features["firstorder_Entropy"] = float(-np.sum(p * np.log2(p)))
        features["firstorder_Uniformity"] = float(np.sum(p ** 2))
    else:
        features["firstorder_Entropy"] = 0.0
        features["firstorder_Uniformity"] = 1.0

    return features


# ============================================================================
# Shape Features (14)
# ============================================================================

def compute_shape_features(
    mask: np.ndarray,
    spacing: tuple[float, float, float],
) -> OrderedDict:
    """Compute 14 IBSI shape features from a binary mask.

    Parameters
    ----------
    mask : 3D bool array
    spacing : (sx, sy, sz) in mm.

    Returns
    -------
    OrderedDict of feature_name -> float.
    """
    if not mask.any():
        return OrderedDict()

    sx, sy, sz = (float(s) for s in spacing)
    voxel_vol = sx * sy * sz
    n_voxels = int(mask.sum())

    features = OrderedDict()
    features["shape_VoxelVolume"] = float(n_voxels * voxel_vol)

    # Mesh-based volume and surface area
    try:
        from skimage.measure import marching_cubes, mesh_surface_area
        verts, faces, _, _ = marching_cubes(
            mask.astype(float), level=0.5, spacing=(sx, sy, sz))
        features["shape_SurfaceArea"] = float(mesh_surface_area(verts, faces))
        # Divergence theorem for mesh volume
        v0 = verts[faces[:, 0]]
        v1 = verts[faces[:, 1]]
        v2 = verts[faces[:, 2]]
        cross = np.cross(v1 - v0, v2 - v0)
        mesh_vol = abs(float(np.sum(v0 * cross) / 6.0))
        features["shape_MeshVolume"] = mesh_vol
    except Exception:
        features["shape_SurfaceArea"] = float(
            _estimate_surface_area(mask, spacing))
        features["shape_MeshVolume"] = features["shape_VoxelVolume"]

    vol = features["shape_MeshVolume"]
    sa = features["shape_SurfaceArea"]
    features["shape_SurfaceVolumeRatio"] = sa / vol if vol > 0 else 0.0

    if vol > 0 and sa > 0:
        features["shape_Sphericity"] = float(
            (36.0 * np.pi * vol ** 2) ** (1.0 / 3.0) / sa)
    else:
        features["shape_Sphericity"] = 0.0

    # PCA-based axes
    coords = np.argwhere(mask).astype(float)
    coords[:, 0] *= sx
    coords[:, 1] *= sy
    coords[:, 2] *= sz
    coords -= coords.mean(axis=0)

    if len(coords) >= 3:
        cov = np.cov(coords.T)
        eigvals = np.sort(np.linalg.eigvalsh(cov))[::-1]
        eigvals = np.maximum(eigvals, 0)
        axes = 2.0 * np.sqrt(eigvals)

        features["shape_MajorAxisLength"] = float(2.0 * axes[0]) if eigvals[0] > 0 else 0.0
        features["shape_MinorAxisLength"] = float(2.0 * axes[1]) if eigvals[1] > 0 else 0.0
        features["shape_LeastAxisLength"] = float(2.0 * axes[2]) if eigvals[2] > 0 else 0.0
        features["shape_Elongation"] = (
            float(np.sqrt(eigvals[1] / eigvals[0])) if eigvals[0] > 0 else 0.0)
        features["shape_Flatness"] = (
            float(np.sqrt(eigvals[2] / eigvals[0])) if eigvals[0] > 0 else 0.0)
    else:
        for name in ["MajorAxisLength", "MinorAxisLength", "LeastAxisLength",
                      "Elongation", "Flatness"]:
            features[f"shape_{name}"] = 0.0

    # Maximum diameters
    _compute_max_diameters(mask, spacing, features)

    return features


def _estimate_surface_area(
    mask: np.ndarray, spacing: tuple[float, float, float],
) -> float:
    """Estimate surface area from exposed voxel faces."""
    sx, sy, sz = (float(s) for s in spacing)
    sa = 0.0
    sa += np.sum(mask[1:] != mask[:-1]) * sy * sz
    sa += np.sum(mask[:, 1:] != mask[:, :-1]) * sx * sz
    sa += np.sum(mask[:, :, 1:] != mask[:, :, :-1]) * sx * sy
    sa += (mask[0].sum() + mask[-1].sum()) * sy * sz
    sa += (mask[:, 0].sum() + mask[:, -1].sum()) * sx * sz
    sa += (mask[:, :, 0].sum() + mask[:, :, -1].sum()) * sx * sy
    return float(sa)


def _compute_max_diameters(
    mask: np.ndarray,
    spacing: tuple[float, float, float],
    features: OrderedDict,
) -> None:
    """Compute Maximum 2D/3D diameters via extremal-point sampling."""
    sx, sy, sz = (float(s) for s in spacing)
    coords = np.argwhere(mask)

    if len(coords) < 2:
        for name in ["Maximum2DDiameterColumn", "Maximum2DDiameterRow",
                      "Maximum2DDiameterSlice", "Maximum3DDiameter"]:
            features[f"shape_{name}"] = 0.0
        return

    phys = coords.astype(float) * np.array([sx, sy, sz])
    rng = np.random.RandomState(42)

    # 3D maximum diameter
    sample = phys if len(phys) <= 5000 else phys[rng.choice(len(phys), 5000, replace=False)]
    max_3d = 0.0
    for dim in range(3):
        for pt in [sample[sample[:, dim].argmin()], sample[sample[:, dim].argmax()]]:
            dists = np.sqrt(np.sum((sample - pt) ** 2, axis=1))
            max_3d = max(max_3d, float(dists.max()))
    features["shape_Maximum3DDiameter"] = max_3d

    # 2D maximum diameters per plane
    for name, dims in [("Maximum2DDiameterSlice", (0, 1)),
                        ("Maximum2DDiameterColumn", (1, 2)),
                        ("Maximum2DDiameterRow", (0, 2))]:
        pts = phys[:, list(dims)]
        if len(pts) > 3000:
            pts = pts[rng.choice(len(pts), 3000, replace=False)]
        max_2d = 0.0
        for dim in range(2):
            for pt in [pts[pts[:, dim].argmin()], pts[pts[:, dim].argmax()]]:
                dists = np.sqrt(np.sum((pts - pt) ** 2, axis=1))
                max_2d = max(max_2d, float(dists.max()))
        features[f"shape_{name}"] = max_2d


# ============================================================================
# GLCM — Gray-Level Co-occurrence Matrix (24 features)
# ============================================================================

def _build_glcm(
    gl_image: np.ndarray,
    mask: np.ndarray,
    n_gl: int,
    distance: int = 1,
) -> np.ndarray:
    """Build averaged symmetric GLCM from 13 3D directions.

    Parameters
    ----------
    gl_image : 3D int array
        Discretized gray-level image (1-based levels).
    mask : 3D bool array
    n_gl : int
        Number of gray levels.
    distance : int
        Offset distance in voxels.

    Returns
    -------
    (n_gl, n_gl) normalized co-occurrence matrix (float64).
    """
    # 13 unique 3D directions (half of 26 neighbors → symmetry)
    offsets = []
    for dz in range(0, distance + 1):
        for dy in range(-distance, distance + 1):
            for dx in range(-distance, distance + 1):
                if (dz, dy, dx) == (0, 0, 0):
                    continue
                if dz == 0 and (dy < 0 or (dy == 0 and dx < 0)):
                    continue
                offsets.append((dz, dy, dx))

    glcm = np.zeros((n_gl, n_gl), dtype=np.float64)
    nz, ny, nx = gl_image.shape

    for dz, dy, dx in offsets:
        # Determine valid index ranges
        z0 = max(0, -dz)
        z1 = min(nz, nz - dz)
        y0 = max(0, -dy)
        y1 = min(ny, ny - dy)
        x0 = max(0, -dx)
        x1 = min(nx, nx - dx)

        src = gl_image[z0:z1, y0:y1, x0:x1]
        tgt = gl_image[z0 + dz:z1 + dz, y0 + dy:y1 + dy, x0 + dx:x1 + dx]
        m_src = mask[z0:z1, y0:y1, x0:x1]
        m_tgt = mask[z0 + dz:z1 + dz, y0 + dy:y1 + dy, x0 + dx:x1 + dx]
        valid = m_src & m_tgt

        if not valid.any():
            continue

        i_vals = src[valid] - 1  # 0-based index
        j_vals = tgt[valid] - 1

        # Accumulate both (i,j) and (j,i) for symmetry
        np.add.at(glcm, (i_vals, j_vals), 1)
        np.add.at(glcm, (j_vals, i_vals), 1)

    total = glcm.sum()
    if total > 0:
        glcm /= total

    return glcm


def compute_glcm_features(
    image: np.ndarray,
    mask: np.ndarray,
    bin_width: float = DEFAULT_BIN_WIDTH,
    distance: int = 1,
) -> OrderedDict:
    """Compute 24 GLCM texture features.

    Parameters
    ----------
    image : 3D array
        Intensity image.
    mask : 3D bool array
    bin_width : float
        Discretization bin width.
    distance : int
        GLCM offset distance in voxels.

    Returns
    -------
    OrderedDict of feature_name -> float.
    """
    values = image[mask].astype(np.float64)
    if len(values) < 2:
        return OrderedDict()

    gl_image = np.zeros_like(image, dtype=int)
    gl_image[mask] = _discretize(values, bin_width)
    n_gl = int(gl_image[mask].max())

    if n_gl < 2:
        return OrderedDict()

    p_glcm = _build_glcm(gl_image, mask, n_gl, distance)
    if p_glcm.sum() == 0:
        return OrderedDict()

    features = OrderedDict()

    # Pre-compute marginals and indices
    eps = 1e-16
    i_idx = np.arange(1, n_gl + 1, dtype=np.float64)
    j_idx = np.arange(1, n_gl + 1, dtype=np.float64)
    ii, jj = np.meshgrid(i_idx, j_idx, indexing="ij")

    px = p_glcm.sum(axis=1)  # marginal row
    py = p_glcm.sum(axis=0)  # marginal col
    mu_x = float(np.sum(i_idx * px))
    mu_y = float(np.sum(j_idx * py))
    sigma_x = float(np.sqrt(np.sum((i_idx - mu_x) ** 2 * px)))
    sigma_y = float(np.sqrt(np.sum((j_idx - mu_y) ** 2 * py)))

    # 1. Autocorrelation
    features["glcm_Autocorrelation"] = float(np.sum(ii * jj * p_glcm))

    # 2. Joint Average (cluster tendency prerequisite)
    mu_joint = float(np.sum(ii * p_glcm))
    features["glcm_JointAverage"] = mu_joint

    # 3. Cluster Prominence
    features["glcm_ClusterProminence"] = float(
        np.sum(((ii + jj - mu_x - mu_y) ** 4) * p_glcm))

    # 4. Cluster Shade
    features["glcm_ClusterShade"] = float(
        np.sum(((ii + jj - mu_x - mu_y) ** 3) * p_glcm))

    # 5. Cluster Tendency
    features["glcm_ClusterTendency"] = float(
        np.sum(((ii + jj - mu_x - mu_y) ** 2) * p_glcm))

    # 6. Contrast
    features["glcm_Contrast"] = float(np.sum((ii - jj) ** 2 * p_glcm))

    # 7. Correlation
    if sigma_x > 0 and sigma_y > 0:
        features["glcm_Correlation"] = float(
            np.sum((ii - mu_x) * (jj - mu_y) * p_glcm) / (sigma_x * sigma_y))
    else:
        features["glcm_Correlation"] = 0.0

    # 8. Difference Average
    k_range = np.arange(0, n_gl, dtype=np.float64)
    p_diff = np.zeros(n_gl, dtype=np.float64)
    for k in range(n_gl):
        p_diff[k] = np.sum(p_glcm[np.abs(ii - jj).astype(int) == k])
    features["glcm_DifferenceAverage"] = float(np.sum(k_range * p_diff))

    # 9. Difference Entropy
    pd_pos = p_diff[p_diff > 0]
    features["glcm_DifferenceEntropy"] = float(
        -np.sum(pd_pos * np.log2(pd_pos))) if len(pd_pos) > 0 else 0.0

    # 10. Difference Variance
    da = features["glcm_DifferenceAverage"]
    features["glcm_DifferenceVariance"] = float(
        np.sum((k_range - da) ** 2 * p_diff))

    # 11. Dissimilarity (= Difference Average for symmetric GLCM)
    features["glcm_Dissimilarity"] = float(np.sum(np.abs(ii - jj) * p_glcm))

    # 12. Joint Energy (Angular Second Moment)
    features["glcm_JointEnergy"] = float(np.sum(p_glcm ** 2))

    # 13. Joint Entropy
    p_pos = p_glcm[p_glcm > 0]
    features["glcm_JointEntropy"] = float(
        -np.sum(p_pos * np.log2(p_pos))) if len(p_pos) > 0 else 0.0

    # 14. Homogeneity (Inverse Difference Moment)
    features["glcm_Id"] = float(
        np.sum(p_glcm / (1.0 + (ii - jj) ** 2)))

    # 15. Idm (Inverse Difference Moment Normalized)
    features["glcm_Idm"] = float(
        np.sum(p_glcm / (1.0 + ((ii - jj) ** 2) / (n_gl ** 2))))

    # 16. Idn (Inverse Difference Normalized)
    features["glcm_Idn"] = float(
        np.sum(p_glcm / (1.0 + np.abs(ii - jj) / n_gl)))

    # 17. Idmn (Inverse Difference Moment Normalized)
    features["glcm_Idmn"] = float(
        np.sum(p_glcm / (1.0 + ((ii - jj) / n_gl) ** 2)))

    # 18. Imc1 (Informational Measure of Correlation 1)
    hxy = features["glcm_JointEntropy"]
    hx = float(-np.sum(px[px > 0] * np.log2(px[px > 0]))) if np.any(px > 0) else 0.0
    hy = float(-np.sum(py[py > 0] * np.log2(py[py > 0]))) if np.any(py > 0) else 0.0
    # HXY1 = -sum(P(i,j) * log2(px(i)*py(j)))
    pxpy = np.outer(px, py)
    hxy1 = float(-np.sum(p_glcm[pxpy > 0] * np.log2(pxpy[pxpy > 0] + eps)))
    denom = max(hx, hy)
    features["glcm_Imc1"] = (
        float((hxy - hxy1) / denom) if denom > 0 else 0.0)

    # 19. Imc2 (Informational Measure of Correlation 2)
    hxy2 = float(-np.sum(pxpy[pxpy > 0] * np.log2(pxpy[pxpy > 0])))
    arg = 1.0 - np.exp(-2.0 * (hxy2 - hxy))
    features["glcm_Imc2"] = float(np.sqrt(max(0, arg)))

    # 20. InverseVariance
    diff_sq = (ii - jj) ** 2
    nonzero = diff_sq > 0
    features["glcm_InverseVariance"] = float(
        np.sum(p_glcm[nonzero] / diff_sq[nonzero])) if nonzero.any() else 0.0

    # 21. Maximum Probability
    features["glcm_MaximumProbability"] = float(p_glcm.max())

    # 22. Sum Average
    k_sum = np.arange(2, 2 * n_gl + 1, dtype=np.float64)
    p_sum = np.zeros(len(k_sum), dtype=np.float64)
    for idx_k, k in enumerate(k_sum):
        p_sum[idx_k] = np.sum(p_glcm[(ii + jj) == k])
    features["glcm_SumAverage"] = float(np.sum(k_sum * p_sum))

    # 23. Sum Entropy
    ps_pos = p_sum[p_sum > 0]
    features["glcm_SumEntropy"] = float(
        -np.sum(ps_pos * np.log2(ps_pos))) if len(ps_pos) > 0 else 0.0

    # 24. Sum of Squares (Variance)
    features["glcm_SumSquares"] = float(
        np.sum((ii - mu_joint) ** 2 * p_glcm))

    return features


# ============================================================================
# GLRLM — Gray-Level Run-Length Matrix (16 features)
# ============================================================================

def _build_glrlm(
    gl_image: np.ndarray,
    mask: np.ndarray,
    n_gl: int,
) -> np.ndarray:
    """Build GLRLM summed over 13 3D directions.

    Returns (n_gl, max_run_length) matrix.
    """
    nz, ny, nx = gl_image.shape
    max_run = max(nz, ny, nx)
    glrlm = np.zeros((n_gl, max_run), dtype=np.float64)

    # 13 unique directions
    directions = [
        (0, 0, 1), (0, 1, 0), (1, 0, 0),
        (0, 1, 1), (0, 1, -1), (1, 1, 0), (1, -1, 0),
        (1, 0, 1), (1, 0, -1),
        (1, 1, 1), (1, 1, -1), (1, -1, 1), (1, -1, -1),
    ]

    for dz, dy, dx in directions:
        visited = np.zeros_like(mask, dtype=bool)

        for z in range(nz):
            for y in range(ny):
                for x in range(nx):
                    if not mask[z, y, x] or visited[z, y, x]:
                        continue

                    gl = gl_image[z, y, x]
                    run_len = 0
                    cz, cy, cx = z, y, x

                    while (0 <= cz < nz and 0 <= cy < ny and 0 <= cx < nx
                           and mask[cz, cy, cx] and gl_image[cz, cy, cx] == gl
                           and not visited[cz, cy, cx]):
                        visited[cz, cy, cx] = True
                        run_len += 1
                        cz += dz
                        cy += dy
                        cx += dx

                    if run_len > 0:
                        glrlm[gl - 1, run_len - 1] += 1

    return glrlm


def compute_glrlm_features(
    image: np.ndarray,
    mask: np.ndarray,
    bin_width: float = DEFAULT_BIN_WIDTH,
) -> OrderedDict:
    """Compute 16 IBSI GLRLM features.

    Parameters
    ----------
    image : 3D array
    mask : 3D bool array
    bin_width : float

    Returns
    -------
    OrderedDict of feature_name -> float.
    """
    values = image[mask].astype(np.float64)
    if len(values) < 2:
        return OrderedDict()

    gl_image = np.zeros_like(image, dtype=int)
    gl_image[mask] = _discretize(values, bin_width)
    n_gl = int(gl_image[mask].max())
    if n_gl < 2:
        return OrderedDict()

    r_mat = _build_glrlm(gl_image, mask, n_gl)

    # Trim zero columns
    max_col = r_mat.shape[1]
    while max_col > 1 and r_mat[:, max_col - 1].sum() == 0:
        max_col -= 1
    r_mat = r_mat[:, :max_col]

    n_r = r_mat.shape[1]
    n_s = float(r_mat.sum())  # total runs
    if n_s == 0:
        return OrderedDict()

    features = OrderedDict()

    # Index arrays (1-based)
    i_idx = np.arange(1, n_gl + 1, dtype=np.float64).reshape(-1, 1)
    j_idx = np.arange(1, n_r + 1, dtype=np.float64).reshape(1, -1)

    ri = r_mat.sum(axis=1)  # runs per gray level
    rj = r_mat.sum(axis=0)  # runs per length

    # 1. Short Run Emphasis
    features["glrlm_ShortRunEmphasis"] = float(
        np.sum(r_mat / j_idx ** 2) / n_s)

    # 2. Long Run Emphasis
    features["glrlm_LongRunEmphasis"] = float(
        np.sum(r_mat * j_idx ** 2) / n_s)

    # 3. Low Gray Level Run Emphasis
    features["glrlm_LowGrayLevelRunEmphasis"] = float(
        np.sum(r_mat / i_idx ** 2) / n_s)

    # 4. High Gray Level Run Emphasis
    features["glrlm_HighGrayLevelRunEmphasis"] = float(
        np.sum(r_mat * i_idx ** 2) / n_s)

    # 5. Short Run Low Gray Level Emphasis
    features["glrlm_ShortRunLowGrayLevelEmphasis"] = float(
        np.sum(r_mat / (i_idx ** 2 * j_idx ** 2)) / n_s)

    # 6. Short Run High Gray Level Emphasis
    features["glrlm_ShortRunHighGrayLevelEmphasis"] = float(
        np.sum(r_mat * i_idx ** 2 / j_idx ** 2) / n_s)

    # 7. Long Run Low Gray Level Emphasis
    features["glrlm_LongRunLowGrayLevelEmphasis"] = float(
        np.sum(r_mat * j_idx ** 2 / i_idx ** 2) / n_s)

    # 8. Long Run High Gray Level Emphasis
    features["glrlm_LongRunHighGrayLevelEmphasis"] = float(
        np.sum(r_mat * i_idx ** 2 * j_idx ** 2) / n_s)

    # 9. Gray Level Non-Uniformity
    features["glrlm_GrayLevelNonUniformity"] = float(
        np.sum(ri ** 2) / n_s)

    # 10. Gray Level Non-Uniformity Normalized
    features["glrlm_GrayLevelNonUniformityNormalized"] = float(
        np.sum(ri ** 2) / n_s ** 2)

    # 11. Run Length Non-Uniformity
    features["glrlm_RunLengthNonUniformity"] = float(
        np.sum(rj ** 2) / n_s)

    # 12. Run Length Non-Uniformity Normalized
    features["glrlm_RunLengthNonUniformityNormalized"] = float(
        np.sum(rj ** 2) / n_s ** 2)

    # 13. Run Percentage
    n_voxels = float(mask.sum())
    features["glrlm_RunPercentage"] = float(n_s / n_voxels) if n_voxels > 0 else 0.0

    # 14. Gray Level Variance
    mu_i = float(np.sum(i_idx * r_mat) / n_s)
    features["glrlm_GrayLevelVariance"] = float(
        np.sum((i_idx - mu_i) ** 2 * r_mat) / n_s)

    # 15. Run Variance
    mu_j = float(np.sum(j_idx * r_mat) / n_s)
    features["glrlm_RunVariance"] = float(
        np.sum((j_idx - mu_j) ** 2 * r_mat) / n_s)

    # 16. Run Entropy
    p = r_mat / n_s
    p_pos = p[p > 0]
    features["glrlm_RunEntropy"] = float(
        -np.sum(p_pos * np.log2(p_pos))) if len(p_pos) > 0 else 0.0

    return features


# ============================================================================
# GLSZM — Gray-Level Size Zone Matrix (16 features)
# ============================================================================

def _build_glszm(
    gl_image: np.ndarray,
    mask: np.ndarray,
    n_gl: int,
) -> np.ndarray:
    """Build GLSZM via connected-component analysis per gray level.

    Returns (n_gl, max_zone_size) matrix.
    """
    max_zone = 0
    zones_per_gl = {}

    for gl in range(1, n_gl + 1):
        gl_mask = (gl_image == gl) & mask
        if not gl_mask.any():
            continue
        labeled, n_cc = nd_label(gl_mask)
        sizes = []
        for cc in range(1, n_cc + 1):
            s = int((labeled == cc).sum())
            sizes.append(s)
            max_zone = max(max_zone, s)
        zones_per_gl[gl] = sizes

    if max_zone == 0:
        return np.zeros((n_gl, 1), dtype=np.float64)

    glszm = np.zeros((n_gl, max_zone), dtype=np.float64)
    for gl, sizes in zones_per_gl.items():
        for s in sizes:
            glszm[gl - 1, s - 1] += 1

    return glszm


def compute_glszm_features(
    image: np.ndarray,
    mask: np.ndarray,
    bin_width: float = DEFAULT_BIN_WIDTH,
) -> OrderedDict:
    """Compute 16 IBSI GLSZM features.

    Parameters
    ----------
    image : 3D array
    mask : 3D bool array
    bin_width : float

    Returns
    -------
    OrderedDict of feature_name -> float.
    """
    values = image[mask].astype(np.float64)
    if len(values) < 2:
        return OrderedDict()

    gl_image = np.zeros_like(image, dtype=int)
    gl_image[mask] = _discretize(values, bin_width)
    n_gl = int(gl_image[mask].max())
    if n_gl < 2:
        return OrderedDict()

    s_mat = _build_glszm(gl_image, mask, n_gl)

    n_z_cols = s_mat.shape[1]
    n_s = float(s_mat.sum())  # total zones
    if n_s == 0:
        return OrderedDict()

    features = OrderedDict()

    i_idx = np.arange(1, n_gl + 1, dtype=np.float64).reshape(-1, 1)
    j_idx = np.arange(1, n_z_cols + 1, dtype=np.float64).reshape(1, -1)

    si = s_mat.sum(axis=1)  # zones per gray level
    sj = s_mat.sum(axis=0)  # zones per size

    # 1. Small Area Emphasis
    features["glszm_SmallAreaEmphasis"] = float(
        np.sum(s_mat / j_idx ** 2) / n_s)

    # 2. Large Area Emphasis
    features["glszm_LargeAreaEmphasis"] = float(
        np.sum(s_mat * j_idx ** 2) / n_s)

    # 3. Low Gray Level Zone Emphasis
    features["glszm_LowGrayLevelZoneEmphasis"] = float(
        np.sum(s_mat / i_idx ** 2) / n_s)

    # 4. High Gray Level Zone Emphasis
    features["glszm_HighGrayLevelZoneEmphasis"] = float(
        np.sum(s_mat * i_idx ** 2) / n_s)

    # 5. Small Area Low Gray Level Emphasis
    features["glszm_SmallAreaLowGrayLevelEmphasis"] = float(
        np.sum(s_mat / (i_idx ** 2 * j_idx ** 2)) / n_s)

    # 6. Small Area High Gray Level Emphasis
    features["glszm_SmallAreaHighGrayLevelEmphasis"] = float(
        np.sum(s_mat * i_idx ** 2 / j_idx ** 2) / n_s)

    # 7. Large Area Low Gray Level Emphasis
    features["glszm_LargeAreaLowGrayLevelEmphasis"] = float(
        np.sum(s_mat * j_idx ** 2 / i_idx ** 2) / n_s)

    # 8. Large Area High Gray Level Emphasis
    features["glszm_LargeAreaHighGrayLevelEmphasis"] = float(
        np.sum(s_mat * i_idx ** 2 * j_idx ** 2) / n_s)

    # 9. Gray Level Non-Uniformity
    features["glszm_GrayLevelNonUniformity"] = float(
        np.sum(si ** 2) / n_s)

    # 10. Gray Level Non-Uniformity Normalized
    features["glszm_GrayLevelNonUniformityNormalized"] = float(
        np.sum(si ** 2) / n_s ** 2)

    # 11. Size Zone Non-Uniformity
    features["glszm_SizeZoneNonUniformity"] = float(
        np.sum(sj ** 2) / n_s)

    # 12. Size Zone Non-Uniformity Normalized
    features["glszm_SizeZoneNonUniformityNormalized"] = float(
        np.sum(sj ** 2) / n_s ** 2)

    # 13. Zone Percentage
    n_voxels = float(mask.sum())
    features["glszm_ZonePercentage"] = float(n_s / n_voxels) if n_voxels > 0 else 0.0

    # 14. Gray Level Variance
    mu_i = float(np.sum(i_idx * s_mat) / n_s)
    features["glszm_GrayLevelVariance"] = float(
        np.sum((i_idx - mu_i) ** 2 * s_mat) / n_s)

    # 15. Zone Size Variance
    mu_j = float(np.sum(j_idx * s_mat) / n_s)
    features["glszm_ZoneSizeVariance"] = float(
        np.sum((j_idx - mu_j) ** 2 * s_mat) / n_s)

    # 16. Zone Size Entropy
    p = s_mat / n_s
    p_pos = p[p > 0]
    features["glszm_ZoneSizeEntropy"] = float(
        -np.sum(p_pos * np.log2(p_pos))) if len(p_pos) > 0 else 0.0

    return features


# ============================================================================
# Feature class registry
# ============================================================================

FEATURE_CLASSES = {
    "firstorder": compute_firstorder_features,
    "shape": compute_shape_features,
    "glcm": compute_glcm_features,
    "glrlm": compute_glrlm_features,
    "glszm": compute_glszm_features,
}

ALL_CLASSES = list(FEATURE_CLASSES.keys())
DEFAULT_CLASSES = ["firstorder", "shape"]


# ============================================================================
# High-level extraction API
# ============================================================================

def extract_features(
    image_path: str | Path,
    mask_path: str | Path,
    label: int | None = None,
    feature_classes: list[str] | None = None,
    bin_width: float = DEFAULT_BIN_WIDTH,
    roi_name: str = "",
) -> OrderedDict:
    """Extract radiomics features from an image + mask pair.

    Parameters
    ----------
    image_path : path
        NIfTI image (CT, MR, etc.).
    mask_path : path
        NIfTI mask (binary or label map).
    label : int, optional
        If mask is a label map, use this label.
    feature_classes : list of str, optional
        Feature classes to compute.  Default: ["firstorder", "shape"].
        Options: "firstorder", "shape", "glcm", "glrlm", "glszm".
    bin_width : float
        Bin width for intensity discretization.
    roi_name : str
        Name label for the ROI.

    Returns
    -------
    OrderedDict of feature_name -> float.
    """
    if feature_classes is None:
        feature_classes = DEFAULT_CLASSES

    img_data, img_affine, spacing = _load_image(image_path)
    mask_data = _load_mask(mask_path, label)

    if img_data.shape != mask_data.shape:
        raise ValueError(
            f"Shape mismatch: image {img_data.shape} vs mask {mask_data.shape}"
        )

    if not mask_data.any():
        logger.warning("Empty mask for '%s'", roi_name)
        return OrderedDict()

    features = OrderedDict()

    for cls_name in feature_classes:
        if cls_name not in FEATURE_CLASSES:
            logger.warning("Unknown feature class: %s", cls_name)
            continue

        if cls_name == "shape":
            cls_features = compute_shape_features(mask_data, spacing)
        elif cls_name == "firstorder":
            values = img_data[mask_data].astype(np.float64)
            cls_features = compute_firstorder_features(values, bin_width)
        else:
            # Texture features (glcm, glrlm, glszm)
            cls_features = FEATURE_CLASSES[cls_name](
                img_data, mask_data, bin_width)

        if cls_features:
            features.update(cls_features)

    return features


def extract_features_batch(
    image_path: str | Path,
    label_path: str | Path,
    roi_mapping: dict[int, str] | str | Path,
    feature_classes: list[str] | None = None,
    bin_width: float = DEFAULT_BIN_WIDTH,
) -> dict[str, OrderedDict]:
    """Extract features for all ROIs in a label map.

    Parameters
    ----------
    image_path : path
        NIfTI image.
    label_path : path
        NIfTI label map.
    roi_mapping : dict or JSON path
        Label int -> ROI name.
    feature_classes : list of str, optional
    bin_width : float

    Returns
    -------
    dict mapping ROI name -> OrderedDict of features.
    """
    if feature_classes is None:
        feature_classes = DEFAULT_CLASSES

    if isinstance(roi_mapping, (str, Path)):
        roi_mapping = Path(roi_mapping)
        if not roi_mapping.exists():
            raise FileNotFoundError(f"ROI mapping not found: {roi_mapping}")
        with open(roi_mapping, encoding="utf-8") as f:
            raw = json.load(f)
        roi_mapping = {int(k): v for k, v in raw.items()}

    img_data, img_affine, spacing = _load_image(image_path)
    label_data, _, _ = _load_image(label_path)

    if img_data.shape != label_data.shape:
        raise ValueError(
            f"Shape mismatch: image {img_data.shape} "
            f"vs labels {label_data.shape}"
        )

    label_arr = np.round(label_data).astype(int)
    results = {}

    for label_int, name in sorted(roi_mapping.items()):
        mask = label_arr == label_int
        if not mask.any():
            logger.warning("Empty ROI: %s (label %d)", name, label_int)
            continue

        features = OrderedDict()

        for cls_name in feature_classes:
            if cls_name not in FEATURE_CLASSES:
                continue
            if cls_name == "shape":
                cls_feat = compute_shape_features(mask, spacing)
            elif cls_name == "firstorder":
                values = img_data[mask].astype(np.float64)
                cls_feat = compute_firstorder_features(values, bin_width)
            else:
                cls_feat = FEATURE_CLASSES[cls_name](
                    img_data, mask, bin_width)
            if cls_feat:
                features.update(cls_feat)

        if features:
            results[name] = features
            logger.info("  %s: %d features extracted", name, len(features))

    return results


def compare_features(
    features_a: OrderedDict,
    features_b: OrderedDict,
) -> dict:
    """Compare two feature sets (e.g., original vs defaced).

    Returns
    -------
    dict with per-feature absolute and relative differences.
    """
    common_keys = [k for k in features_a if k in features_b]
    if not common_keys:
        return {"n_common": 0, "features": []}

    rows = []
    for key in common_keys:
        val_a = float(features_a[key])
        val_b = float(features_b[key])
        abs_diff = abs(val_b - val_a)
        rel_diff = abs_diff / max(abs(val_a), 1e-10)
        rows.append({
            "feature": key,
            "original": val_a,
            "defaced": val_b,
            "abs_diff": abs_diff,
            "rel_diff": rel_diff,
        })

    return {
        "n_common": len(common_keys),
        "max_abs_diff": max(r["abs_diff"] for r in rows),
        "max_rel_diff": max(r["rel_diff"] for r in rows),
        "mean_abs_diff": float(np.mean([r["abs_diff"] for r in rows])),
        "mean_rel_diff": float(np.mean([r["rel_diff"] for r in rows])),
        "features": rows,
    }
