function varargout = DPS_tool(varargin)
% DPS_TOOL MATLAB code for DPS_tool.fig
%      DPS_TOOL, by itself, creates a new DPS_TOOL or raises the existing
%      singleton*.
%
%      H = DPS_TOOL returns the handle to a new DPS_TOOL or the handle to
%      the existing singleton*.
%
%      DPS_TOOL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DPS_TOOL.M with the given input arguments.
%
%      DPS_TOOL('Property','Value',...) creates a new DPS_TOOL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DPS_tool_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DPS_tool_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DPS_tool

% Last Modified by GUIDE v2.5 17-Apr-2015 22:07:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DPS_tool_OpeningFcn, ...
                   'gui_OutputFcn',  @DPS_tool_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DPS_tool is made visible.
function DPS_tool_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DPS_tool (see VARARGIN)

% Choose default command line output for DPS_tool
handles.output = hObject;

% Update handles structure
handles=DPS_initialize(hObject, handles);
guidata(hObject, handles);

% UIWAIT makes DPS_tool wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DPS_tool_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function sn1_Callback(hObject, eventdata, handles)
% hObject    handle to sn1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sn1 as text
%        str2double(get(hObject,'String')) returns contents of sn1 as a double
sn1=get(hObject,'String');
handles.text.sn1=sn1;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sn1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sn1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sn2_Callback(hObject, eventdata, handles)
% hObject    handle to sn2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sn2 as text
%        str2double(get(hObject,'String')) returns contents of sn2 as a double
sn2=get(hObject,'String');
handles.text.sn2=sn2;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sn2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sn2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sn3_Callback(hObject, eventdata, handles)
% hObject    handle to sn3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sn3 as text
%        str2double(get(hObject,'String')) returns contents of sn3 as a double
sn3=get(hObject,'String');
handles.text.sn3=sn3;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sn3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sn3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sn4_Callback(hObject, eventdata, handles)
% hObject    handle to sn4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sn4 as text
%        str2double(get(hObject,'String')) returns contents of sn4 as a double
sn4=get(hObject,'String');
handles.text.sn4=sn4;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sn4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sn4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sn5_Callback(hObject, eventdata, handles)
% hObject    handle to sn5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sn5 as text
%        str2double(get(hObject,'String')) returns contents of sn5 as a double
sn5=get(hObject,'String');
handles.text.sn5=sn5;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sn5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sn5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sn6_Callback(hObject, eventdata, handles)
% hObject    handle to sn6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sn6 as text
%        str2double(get(hObject,'String')) returns contents of sn6 as a double
sn6=get(hObject,'String');
handles.text.sn6=sn6;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sn6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sn6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sn7_Callback(hObject, eventdata, handles)
% hObject    handle to sn7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sn7 as text
%        str2double(get(hObject,'String')) returns contents of sn7 as a double
sn7=get(hObject,'String');
handles.text.sn7=sn7;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sn7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sn7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sn8_Callback(hObject, eventdata, handles)
% hObject    handle to sn8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sn8 as text
%        str2double(get(hObject,'String')) returns contents of sn8 as a double
sn8=get(hObject,'String');
handles.text.sn8=sn8;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sn8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sn8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sn9_Callback(hObject, eventdata, handles)
% hObject    handle to sn9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sn9 as text
%        str2double(get(hObject,'String')) returns contents of sn9 as a double
sn9=get(hObject,'String');
handles.text.sn9=sn9;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sn9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sn9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function str1_Callback(hObject, eventdata, handles)
% hObject    handle to str1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of str1 as text
%        str2double(get(hObject,'String')) returns contents of str1 as a double
str1=get(hObject,'String');
handles.text.str1=str1;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function str1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to str1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function str2_Callback(hObject, eventdata, handles)
% hObject    handle to str2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of str2 as text
%        str2double(get(hObject,'String')) returns contents of str2 as a double
str2=get(hObject,'String');
handles.text.str2=str2;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function str2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to str2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function str3_Callback(hObject, eventdata, handles)
% hObject    handle to str3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of str3 as text
%        str2double(get(hObject,'String')) returns contents of str3 as a double
str3=get(hObject,'String');
handles.text.str3=str3;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function str3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to str3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function str4_Callback(hObject, eventdata, handles)
% hObject    handle to str4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of str4 as text
%        str2double(get(hObject,'String')) returns contents of str4 as a double
str4=get(hObject,'String');
handles.text.str4=str4;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function str4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to str4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function str5_Callback(hObject, eventdata, handles)
% hObject    handle to str5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of str5 as text
%        str2double(get(hObject,'String')) returns contents of str5 as a double
str5=get(hObject,'String');
handles.text.str5=str5;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function str5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to str5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function str6_Callback(hObject, eventdata, handles)
% hObject    handle to str6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of str6 as text
%        str2double(get(hObject,'String')) returns contents of str6 as a double
str6=get(hObject,'String');
handles.text.str6=str6;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function str6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to str6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function str7_Callback(hObject, eventdata, handles)
% hObject    handle to str7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of str7 as text
%        str2double(get(hObject,'String')) returns contents of str7 as a double
str7=get(hObject,'String');
handles.text.str7=str7;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function str7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to str7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function str8_Callback(hObject, eventdata, handles)
% hObject    handle to str8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of str8 as text
%        str2double(get(hObject,'String')) returns contents of str8 as a double
str8=get(hObject,'String');
handles.text.str8=str8;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function str8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to str8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function str9_Callback(hObject, eventdata, handles)
% hObject    handle to str9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of str9 as text
%        str2double(get(hObject,'String')) returns contents of str9 as a double
str9=get(hObject,'String');
handles.text.str9=str9;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function str9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to str9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Load orders from .txt file
handles=DPS_initialize(hObject, handles);
[bb,aa]=uigetfile('*.txt');
if isnumeric(aa) && isnumeric(bb)
    errordlg('Please re-select the .txt file!');
    return
end
fid=fopen([aa,bb],'r');
tline = fgetl(fid);
i = 1;
A{i} = tline;
while ischar(tline)
    i = i+1;
    tline = fgetl(fid);
    A{i} = tline;
end
fclose(fid);
for i=1:length(A)-1
    num_str=num2str(ceil(i/2));
    if mod(i,2)==1
        handles.text.(['sn' num_str])=A{i};
        if str2double(num_str)<10
            set(handles.(['sn' num_str]),'string',A{i});
        end
    elseif mod(i,2)==0
        handles.text.(['str' num_str])=A{i};
        if str2double(num_str)<10
            set(handles.(['str' num_str]),'string',A{i});
        end
    end
end
guidata(hObject, handles);

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Save orders to .txt file
if ~isfield(handles, 'text')
    errordlg('Make sure you enter your orders before click "Save"!');
    return
end
[bb,aa]=uiputfile('*.txt');
if isnumeric(aa) && isnumeric(bb)
    errordlg('Please re-select the .txt file!');
    return
end
fileID = fopen([aa, bb],'w');
for i=1:9  % allow up to 9 structures
    if isfield(handles.text, ['sn' num2str(i)])
        fprintf(fileID,'%s\r\n',handles.text.(['sn' num2str(i)]));
    else
        break
    end
    if isfield(handles.text, ['str' num2str(i)])
        fprintf(fileID,'%s\r\n',handles.text.(['str' num2str(i)]));
    else
        break
    end
end
fclose(fileID);

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles=DPS_initialize(hObject, handles);
msgbox('Program initialized.','DPS Program');
guidata(hObject, handles);

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,PathName,~] = uigetfile('.csv','MultiSelect','on');
if ~iscell(FileName)
    FileName={FileName};
end

h_wb=waitbar(0,'Checking syntax of orders ...');
try

    for j=1:20  % up to 20 structures
        if isfield(handles.text, ['sn' num2str(j)])
            tab_name=handles.text.(['sn' num2str(j)]);  % the same as the structure name
            waitbar(0,h_wb,sprintf('Checking syntax of orders for the structure: %s',strrep(tab_name,'_','\_')));
            if isfield(handles.text, ['str' num2str(j)])
                orders=extract_order(handles.text.(['str' num2str(j)]));    %
            else
                continue
            end
            this_tab=[{'case_ID'}, orders];
            for i=1:1   % check the first file to see if syntax works
                fullpath=[PathName, FileName{i}];
                case_ID=strrep(FileName{i},'.csv','');
                this_line={case_ID};
                for k=1:length(orders)
                    DVH_csv_data=csv_rewrite(fullpath);
                    %[two_c_DVH, error_flag]=DVH_con_select(tab_name, DVH_csv_data);
                    two_c_DVH=[[0:0.1:100]',[100:-0.1:0]'];
                    error_flag=0;
                    if ~error_flag
                        four_c_DVH=add_pctg_DVH(two_c_DVH,handles.data.rx);
                        this_cell_value=cal_from_DVH_Rx(orders{k},four_c_DVH,handles.data.rx,handles.data.rx);
                    else
                        this_cell_value='';
                    end
                    this_line=[this_line, {this_cell_value}];
                end
                this_tab=[this_tab;this_line];
            end
        else
            continue
        end
        this_workbook.(tab_name)=this_tab;
    end
    
    clearvars this_cell_value this_line this_tab this_workbook
    
catch
    errordlg('Please check and correct your syntax of orders.');
    close(h_wb);
    return
end


waitbar(0,h_wb,'Calculation in progress ...');
for j=1:20  % up to 20 structures
    if isfield(handles.text, ['sn' num2str(j)])
        tab_name=handles.text.(['sn' num2str(j)]);  % the same as the structure name
        waitbar(j/20,h_wb,sprintf('Working on the structure: %s',strrep(tab_name,'_','\_')));
        if isfield(handles.text, ['str' num2str(j)])
            orders=extract_order(handles.text.(['str' num2str(j)]));    %
        else
            continue
        end
        this_tab=[{'case_ID'}, orders];
        for i=1:length(FileName)
            fullpath=[PathName, FileName{i}];
            case_ID=strrep(FileName{i},'.csv','');
            this_line={case_ID};
            for k=1:length(orders)
                DVH_csv_data=csv_rewrite(fullpath);
                [two_c_DVH, error_flag]=DVH_con_select(tab_name, DVH_csv_data);
                if ~error_flag
                    if ~isempty(strfind(DVH_csv_data.colheaders{1,3},'Rx='))    % find out Rx dose
                        rx_str=DVH_csv_data.textdata{1,3};
                        rx_str=strrep(rx_str,'Rx=','');
                        rx_str=strrep(rx_str,'Gy','');
                        rx_value=str2double(rx_str);    % individual
                    elseif ~isnan(str2double(DVH_csv_data.colheaders{1,3}))
                        rx_str=DVH_csv_data.textdata{1,3};
                        rx_value=str2double(rx_str);    % individual
                    else
                        rx_value=handles.data.rx;   % public
                    end
                    if handles.dose_ref_selection==1    % ref dose is Rx
                        four_c_DVH=add_pctg_DVH(two_c_DVH,rx_value);
                        this_cell_value=cal_from_DVH_Rx(orders{k},four_c_DVH,rx_value,rx_value);
                    elseif handles.dose_ref_selection==2    % ref dose is Dmax (input by user to csv files)
                        if ~isempty(strfind(DVH_csv_data.colheaders{1,4},'Dmax='))
                            max_str=DVH_csv_data.textdata{1,4};
                            max_str=strrep(max_str,'Dmax=','');
                            max_str=strrep(max_str,'Gy','');
                            max_value=str2double(max_str);
                        elseif ~isnan(str2double(DVH_csv_data.colheaders{1,4}))
                            max_str=DVH_csv_data.textdata{1,4};
                            max_value=str2double(max_str);
                        else
                            errordlg(sprintf('The case %s does not have a Dmax defined in its csv file. Please double check!',case_ID));
                            return
                        end
                        four_c_DVH=add_pctg_DVH(two_c_DVH,max_value);
                        this_cell_value=cal_from_DVH_Rx(orders{k},four_c_DVH,max_value,rx_value);
                    end
                else
                    this_cell_value='';
                end
                this_line=[this_line, {this_cell_value}];
            end
            this_tab=[this_tab;this_line];
        end
    else
        continue
    end
    this_workbook.(tab_name)=this_tab;
end
waitbar(1,h_wb,'Final processing...');
final_workbook=add_stat(this_workbook);
close(h_wb);
DPS_write_excel(final_workbook);
msgbox('Done!','DPS Program');



function Rx_Callback(hObject, eventdata, handles)
% hObject    handle to Rx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Rx as text
%        str2double(get(hObject,'String')) returns contents of Rx as a double
handles.data.rx=str2double(get(hObject,'String'));
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function Rx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Rx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key press with focus on figure1 and none of its controls.
function figure1_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
if strcmp(eventdata.Key,'f1')
    str={};
    str{1}='1. Enter structure names (left column) and orders (right columns).';
    str{2}='    You may save/load structure names and orders to/from a .txt file.';
    str{3}='2. Click RUN to select DVH csv files that you want to process.';
    str{4}='    DVH csv files should follow MIM format.';
    str{5}='3. After analysis, you will be asked if you want to create an overall tab.';
    str{6}='    An overall tab has all structures included in one tab.';
    str{7}='4. Based on your choice, DPS program creates an Excel spreadsheet.';
    str{8}=' ';
    str{9}='* Format of orders:';
    str{10}='    Dmax, Dmin, Dmean, D(Gy)20(cc), D(Gy)20(%), V(cc)20(Gy), V(%)20(Gy)';
    str{11}='    Use ";" to seperate orders: Dmin;Dmax;D(Gy)99(%)/Rx*100;';
    str{12}='Format in MiM csv files: C1:"Rx=60Gy" or 60 and D1:"Dmax=80Gy" or 80';
    str{13}='    ';
    str{14}='Contact Dr. Yutao Gong (yutao.gong@jefferson.edu),';
    str{15}='for any questions and suggestions about DPS program.';
    str{16}='    April 2015';
    
%     fontName = 'FixedWidth';
%     fontSize = 12;
    h=msgbox(sprintf('%s\n',str{:}),'DPS HELP document');
%     set( h, 'Visible', 'off' );
%     
%     kids0 = findobj( h, 'Type', 'UIControl' );
%     kids1 = findobj( h, 'Type', 'Text' );
%     extent0 = get( kids1, 'Extent' ); % text extent in old font
%     set( [kids0, kids1], 'FontName', fontName, 'FontSize', fontSize );
%     extent1 = get( kids1, 'Extent' ); % text extent in new font
%     delta = extent1 - extent0; % change in extent
%     pos = get( h, 'Position' ); % msgbox current position
%     pos = pos + delta; % change size of msgbox
%     set( h, 'Position', pos ); % set new position
%     
%     set( h, 'Visible', 'on' );
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
contents = cellstr(get(hObject,'String'));
dose_ref_str=contents{get(hObject,'Value')};
handles.dose_ref_selection=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function output = add_pctg_DVH(DVH_data,D_ref)
% This function add the percentage columns (D&V) to orginal DVH. In the new
% DVH_data matrix, the first column is the dose, the second column is the
% absolute volume, the third column is the percentage volume and the fourth
% column is normalized dose.
% The algorithm to calculate D_ref will be determined later.
% Coded by Yutao Gong. Oct. 2013.

output=DVH_data;
output(:,3)=0;

for i=1:max(size(DVH_data(:,1)))
    output(i,3)=output(i,2)*100/output(1,2);    % So, 90 means 90%.
    output(i,4)=output(i,1)*100/D_ref;
end

function final_workbook=add_stat(this_workbook)
% Add statistics to each tab in the workbook.
% Author: Yutao Gong. Jan 2015

user_method=questdlg('Do you want to create a overall tab?','DPS tool','Overall Tab Only','No Overall Tab','Include All','No Overall Tab');

switch user_method
    case 'No Overall Tab'
        tabs=fieldnames(this_workbook);
        for i=1:length(tabs)
            M=this_workbook.(tabs{i})(2:end,2:end);
            M=cellfun(@DPS_str2num, M);
            S=prctile(M,[1,2,5,10,15,85,90,95,98,99],1);
            prc_str={'1(%)';'2(%)';'5(%)';'10(%)';'15(%)';'85(%)';'90(%)';'95(%)';'98(%)';'99(%)'};
            final_workbook.(tabs{i})=[this_workbook.(tabs{i});[prc_str, num2cell(S)]];
        end
    case 'Overall Tab Only'
        tabs=fieldnames(this_workbook);
        for i=1:length(tabs)
            M=this_workbook.(tabs{i})(2:end,2:end);
            M=cellfun(@DPS_str2num, M);
            S=prctile(M,[1,2,5,10,15,85,90,95,98,99],1);
            prc_str={'1(%)';'2(%)';'5(%)';'10(%)';'15(%)';'85(%)';'90(%)';'95(%)';'98(%)';'99(%)'};
            pre_workbook.(tabs{i})=[this_workbook.(tabs{i});[prc_str, num2cell(S)]];
        end
        final_workbook.overall=[cell(1,1); pre_workbook.(tabs{i})(:,1)];
        for i=1:length(tabs)
            header=cell(0,0);
            for j=1:size(pre_workbook.(tabs{i}),2)-1
                header=[header, tabs(i)];
            end
            final_workbook.overall=[final_workbook.overall, [header; pre_workbook.(tabs{i})(:,2:end)]];
        end
    case 'Include All'
        tabs=fieldnames(this_workbook);
        for i=1:length(tabs)
            M=this_workbook.(tabs{i})(2:end,2:end);
            M=cellfun(@DPS_str2num, M);
            S=prctile(M,[1,2,5,10,15,85,90,95,98,99],1);
            prc_str={'1(%)';'2(%)';'5(%)';'10(%)';'15(%)';'85(%)';'90(%)';'95(%)';'98(%)';'99(%)'};
            pre_workbook.(tabs{i})=[this_workbook.(tabs{i});[prc_str, num2cell(S)]];
        end
        final_workbook.overall=[cell(1,1); pre_workbook.(tabs{i})(:,1)];
        for i=1:length(tabs)
            header=cell(0,0);
            for j=1:size(pre_workbook.(tabs{i}),2)-1
                header=[header, tabs(i)];
            end
            final_workbook.overall=[final_workbook.overall, [header; pre_workbook.(tabs{i})(:,2:end)]];
            final_workbook.(tabs{i})=pre_workbook.(tabs{i});
        end
end

function output = cal_from_DVH(str_para, DVH_data, D_r)
% This function calls other functions to calculate selected parameters from
% 4-colume-DVH. This function is not supposed to run individually.
% Coded by Yutao Gong. Oct. 2013.

if DVH_data(1,2)<0  % v1.6 patch, deal with False Data introduced on purpose
    output=-10000;
    return;
end

output='';  % added for DPS tool by YG (Jan 2015)

D_V=str_para(1);
value='';

if D_V=='D' && strcmp(str_para(max(end-2, 1):end),'(%)')==1
    
    if strcmp(str_para(1:5),'D(Gy)')==1
        % D(Gy)95(%) - Dose in Gy of 95% of the volume
        value=str2double(str_para(6:end-3));
        output=calD1_DVH(value, DVH_data);
    elseif strcmp(str_para(1:4),'D(%)')==1
        % D(%)95(%) - Dose in normalized percentile of 95% of the volume
        value=str2double(str_para(5:end-3));
        output=calD1_DVH(value, DVH_data)*100/D_r;
    end
    
elseif D_V=='D' && strcmp(str_para(max(end-3, 1):end),'(cc)')==1
    
    if strcmp(str_para(1:5),'D(Gy)')==1
        % D(Gy)0.03(cc) - Dose in Gy of 0.03 cc volume
        value=str2double(str_para(6:end-4));
        output=calD2_DVH(value, DVH_data);   
    elseif strcmp(str_para(1:4),'D(%)')==1
        % D(%)0.03(cc) - Dose in normalized percentile of 0.03 cc volume (max)
        value=str2double(str_para(5:end-4));
        output=calD2_DVH(value, DVH_data)*100/D_r;
    end
    
elseif D_V=='V' && strcmp(str_para(max(end-2, 1):end),'(%)')==1
    if strcmp(str_para(1:5),'V(cc)')==1
        % V(cc)90(%) - Volume in cc getting 90% of the normalized dose
        value=str2double(str_para(6:end-3));
        output=calV1_DVH(value, DVH_data);      
    elseif strcmp(str_para(1:4),'V(%)')==1
        % V(%)90(%) - Volume in percentile getting 90% of the normalized dose
        value=str2double(str_para(5:end-3));
        output=calV1p_DVH(value, DVH_data);        
    end
        
elseif D_V=='V' && strcmp(str_para(max(end-3, 1):end),'(Gy)')==1
    if strcmp(str_para(1:5),'V(cc)')==1
        % V(cc)45(Gy) - V in cc getting 45 Gy
        value=str2double(str_para(6:end-4));
        output=calV2_DVH(value, DVH_data);   
    elseif strcmp(str_para(1:4),'V(%)')==1
        % V(%)45(Gy) - Volume in % getting 45 Gy
        value=str2double(str_para(5:end-4));
        output=calV2p_DVH(value, DVH_data);  
    end

elseif strcmp(str_para,'Dmean')==1
    output=calDmean_DVH(DVH_data);
    value=1;
elseif strcmp(str_para,'Dmax')==1
    output=calDmax_DVH(DVH_data);
    value=1;
elseif strcmp(str_para(1:4),'Dmin')==1
    if length(str_para)>4
        min_vol=str2num(str_para(5:end));
    else
        min_vol=0.03;
    end
    output=calDmin_DVH(DVH_data, min_vol);
    value=1;
else
    errordlg(sprintf('input ''%s'' is not correct.',str_para));
    value=1;
end

if isempty(value)==1
    errordlg(sprintf('input ''%s'' is not correct.',str_para));
end

function output = cal_from_DVH_Rx(str_para, DVH_data, D_r, Rx_dose)
% This function calls other functions to calculate selected parameters from
% 4-colume-DVH. This function is not supposed to run individually.
% Coded by Yutao Gong. Oct. 2013.

if DVH_data(1,2)<0  % v1.6 patch, deal with False Data introduced on purpose
    output=-10000;
    return;
end

if strcmp(str_para(max(1,end-2):end),'/Rx')
    Rx_op=1;
    str_para(end-2:end)='';
elseif strcmp(str_para(max(1,end-2):end),'*Rx')
    Rx_op=2;
    str_para(end-2:end)='';
elseif strcmp(str_para(max(1,end-6):end),'/Rx*100')
    Rx_op=3;
    str_para(end-6:end)='';
else
    Rx_op=0;
end

D_V=str_para(1);
value='';

if D_V=='D' && strcmp(str_para(max(end-2, 1):end),'(%)')==1
    
    if strcmp(str_para(1:5),'D(Gy)')==1
        % D(Gy)95(%) - Dose in Gy of 95% of the volume
        value=str2double(str_para(6:end-3));
        output=calD1_DVH(value, DVH_data);
    elseif strcmp(str_para(1:4),'D(%)')==1
        % D(%)95(%) - Dose in normalized percentile of 95% of the volume
        value=str2double(str_para(5:end-3));
        output=calD1_DVH(value, DVH_data)*100/D_r;
    end
    
elseif D_V=='D' && strcmp(str_para(max(end-3, 1):end),'(cc)')==1
    
    if strcmp(str_para(1:5),'D(Gy)')==1
        % D(Gy)0.03(cc) - Dose in Gy of 0.03 cc volume
        value=str2double(str_para(6:end-4));
        output=calD2_DVH(value, DVH_data);   
    elseif strcmp(str_para(1:4),'D(%)')==1
        % D(%)0.03(cc) - Dose in normalized percentile of 0.03 cc volume (max)
        value=str2double(str_para(5:end-4));
        output=calD2_DVH(value, DVH_data)*100/D_r;
    end
    
elseif D_V=='V' && strcmp(str_para(max(end-2, 1):end),'(%)')==1
    if strcmp(str_para(1:5),'V(cc)')==1
        % V(cc)90(%) - Volume in cc getting 90% of the normalized dose
        value=str2double(str_para(6:end-3));
        output=calV1_DVH(value, DVH_data);      
    elseif strcmp(str_para(1:4),'V(%)')==1
        % V(%)90(%) - Volume in percentile getting 90% of the normalized dose
        value=str2double(str_para(5:end-3));
        output=calV1p_DVH(value, DVH_data);        
    end
        
elseif D_V=='V' && strcmp(str_para(max(end-3, 1):end),'(Gy)')==1
    if strcmp(str_para(1:5),'V(cc)')==1
        % V(cc)45(Gy) - V in cc getting 45 Gy
        value=str2double(str_para(6:end-4));
        output=calV2_DVH(value, DVH_data);   
    elseif strcmp(str_para(1:4),'V(%)')==1
        % V(%)45(Gy) - Volume in % getting 45 Gy
        value=str2double(str_para(5:end-4));
        output=calV2p_DVH(value, DVH_data);  
    end

elseif strcmp(str_para,'Dmean')==1
    output=calDmean_DVH(DVH_data);
    value=1;
elseif strcmp(str_para,'Dmax')==1
    output=calDmax_DVH(DVH_data);
    value=1;
elseif strcmp(str_para(1:4),'Dmin')==1
    if length(str_para)>4
        min_vol=str2num(str_para(5:end));
    else
        min_vol=0.03;
    end
    output=calDmin_DVH(DVH_data, min_vol);
    value=1;
else
    errordlg(sprintf('input ''%s'' is not correct.',str_para));
    value=1;
end

if isempty(value)==1
    errordlg(sprintf('input ''%s'' is not correct.',str_para));
end

switch Rx_op
    case 1
        output=output/Rx_dose;
    case 2
        output=output*Rx_dose;
    case 3
        output=output/Rx_dose*100;
end

function D1=calD1_DVH(value, DVH_data)
% This function calculates a dose point from a 4-column-DVH.
% D(Gy)95(%) - Dose in Gy of 95% of the volume.
% Coded by Yutao Gong. Oct. 2013.

for i = 2 : max(size(DVH_data(:,1)))
    if DVH_data(i-1,3) > value && DVH_data(i,3)<=value
        D1=linear_in(DVH_data(i,3),DVH_data(i,1),DVH_data(i-1,3),DVH_data(i-1,1),value);
        break;
    end
end

function D2=calD2_DVH(value, DVH_data)
% This function calculates a dose point from a 4-column-DVH.
% D(Gy)0.03(cc) - Dose in Gy of 0.03 cc volume.
% Coded by Yutao Gong. Oct. 2013.

D2=0;
for i = 2 : max(size(DVH_data(:,1)))
    if DVH_data(i-1,2) > value && DVH_data(i,2)<=value
        D2=linear_in(DVH_data(i,2),DVH_data(i,1),DVH_data(i-1,2),DVH_data(i-1,1),value);
        break;
    end
end

function Dmax=calDmax_DVH(DVH_data, Vol_mini)
% This function calculates the maximum dose from a 4-column-DVH.
% Minimal volume is adjustable, and its default value is 0.03 cc.
% Coded by Yutao Gong. Oct. 2013.

if nargin==1
    Vol_mini=0.03;
end

for i = 2 : max(size(DVH_data))
    if DVH_data(i-1,2) > Vol_mini && DVH_data(i,2)<=Vol_mini
        Dmax=linear_in(DVH_data(i,2),DVH_data(i,1),DVH_data(i-1,2),DVH_data(i-1,1),Vol_mini);
        break;
    end
end

function Dmean=calDmean_DVH(DVH_data)
% This function calculates the mean dose from a 4-column-DVH.
% Coded by Yutao Gong. Oct. 2013.
DVH_data(isnan(DVH_data))=0;    % very important! YG added this on 01/08/2014
Dmean=trapz(DVH_data(:,1),DVH_data(:,2))/DVH_data(1,2);

function Dmin=calDmin_DVH(DVH_data, Vol_mini)
% This function calculates the minimal dose from a 4-column-DVH.
% Minimal volume is adjustable, and its default value is 0.03 cc.
% Coded by Yutao Gong. Oct. 2013.

if nargin==1
    Vol_mini=0.03;
end

v_th=DVH_data(1,2)-Vol_mini;

for i = 2 : max(size(DVH_data))
    if DVH_data(i-1,2) > v_th && DVH_data(i,2)<=v_th
        Dmin=linear_in(DVH_data(i,2),DVH_data(i,1),DVH_data(i-1,2),DVH_data(i-1,1),v_th);
        break;
    end
end

function V1=calV1_DVH(value, DVH_data)
% This function calculates a volume point from a 4-column-DVH.
% V(cc)90(%) - Volume in cc getting 90% of the normalized dose
% Coded by Yutao Gong. Oct. 2013.

for i = 2 : max(size(DVH_data(:,1)))
    if DVH_data(i-1,4) < value && DVH_data(i,4)>=value
        V1=linear_in(DVH_data(i,4),DVH_data(i,2),DVH_data(i-1,4),DVH_data(i-1,2),value);
        break;
    end
end

function V1p=calV1p_DVH(value, DVH_data)
% This function calculates a volume point from a 4-column-DVH.
% V(%)90(%) - Volume in percentile getting 90% of the normalized dose
% Coded by Yutao Gong. Oct. 2013.

for i = 2 : max(size(DVH_data(:,1)))
    if DVH_data(i-1,4) < value && DVH_data(i,4)>=value
        V1=linear_in(DVH_data(i,4),DVH_data(i,2),DVH_data(i-1,4),DVH_data(i-1,2),value);
        V1p=V1/DVH_data(1,2)*100;
        break;
    else
        V1p=0;
    end
end

function V2=calV2_DVH(value, DVH_data)
% This function calculates a volume point from a 4-column-DVH.
% V(cc)45(Gy) - V in cc getting 45 Gy.
% Coded by Yutao Gong. Oct. 2013.

for i = 2 : max(size(DVH_data(:,1)))
    if DVH_data(i-1,1) < value && DVH_data(i,1)>=value
        V2=linear_in(DVH_data(i,1),DVH_data(i,2),DVH_data(i-1,1),DVH_data(i-1,2),value);
        break;
    end
end

if value>max(DVH_data(:,1))
    V2=0;
elseif value==0
    V2=DVH_data(1,2);
end

function V2p=calV2p_DVH(value, DVH_data)
% This function calculates a volume point from a 4-column-DVH.
% V(cc)45(Gy) - V in cc getting 45 Gy.
% Coded by Yutao Gong. Oct. 2013.

for i = 2 : max(size(DVH_data(:,1)))
    if DVH_data(i-1,1) < value && DVH_data(i,1)>=value
        V2=linear_in(DVH_data(i,1),DVH_data(i,2),DVH_data(i-1,1),DVH_data(i-1,2),value);
        V2p=V2/DVH_data(1,2)*100;
        break;
    else
        V2p=0;
    end
end

if value>max(DVH_data(:,1))
    V2p=0;
end

function out = col_str( input )
%COL_STR Summary of this function goes here
%   Detailed explanation goes here

if input>26*26-1
    out=0;
end

first_letter=char(64+floor((input-1)/26));
second_letter=char(65+mod((input-1),26));

if input<27
    first_letter='';
end
out=[first_letter, second_letter];

function Output=csv_rewrite(filename, write_y_n)
% This function reads DVH csv files exported from MIM (6.3 version) and
% rewrites the information to the orginal file, so MATLAB can read the csv
% file without problems.
% Update 20140922: now this function reads both new and old CSV files.
% Author: Yutao Gong. Sep. 2014.

% default write_y_n should be 'n'
if nargin<2
    write_y_n='n';
end

% read
fid=fopen(filename,'r');
tline = fgetl(fid);
i = 1;
A{i} = tline;
while ischar(tline)
i = i+1;
tline = fgetl(fid);
A{i} = tline;
end
fclose(fid);

% Check if the CSV file is from old MIM CSV or new MIM CSV
if length(strfind(A{1,1},','))<length(strfind(A{1,1},'"'))  % new MIM format
    A{1,1};
elseif isempty(strfind(A{1,2},'"')) % csv edited in EXCEL
    for m=1:length(A)-1
        A{1,m}=[',' A{1,m}];
        A{1,m}=strrep(A{1,m},',','","');
        A{1,m}(1:2)='';
        A{1,m}(end)='';
    end
    
else    % old MIM format
    for m=1:2
        A{1,m}=strrep(A{1,m},',,',',"",');
        A{1,m}=strrep(A{1,m},',,',',');
        A{1,m}=['""', A{1,m}];
    end
    for m=3:length(A)-1
        A{1,m}=[',' A{1,m}];
        A{1,m}=strrep(A{1,m},',','","');
        A{1,m}(1:2)='';
        A{1,m}(end)='';
    end
end


% prepare the cell with necessary clean up
for m=1:length(A)-1
    for n=1:2:length(strfind(A{1,m},'"'))
        if m<3
            T{m,(n+1)/2}=A{1,m}(max(find(A{1,m}=='"',n))+1:max(find(A{1,m}=='"',n+1))-1);
            T{m,(n+1)/2}=strrep(T{m,(n+1)/2},'''','');
            if m==2
                [T{m,(n+1)/2}, ~]=remove_illegal_on_names_regexp(T{m,(n+1)/2}, '[ ](\d*[)]');
            end
            T{m,(n+1)/2}=strrep(T{m,(n+1)/2},' ','_');
        else
            T{m,(n+1)/2}=A{1,m}(max(find(A{1,m}=='"',n))+1:max(find(A{1,m}=='"',n+1))-1);
            if isempty(T{m,(n+1)/2})
                T{m,(n+1)/2}=0;
            else
                T{m,(n+1)/2}=str2num(T{m,(n+1)/2});
            end
        end
    end
end

Output.colheaders=T(1,:);
Output.textdata=T(1:2,:);
T1=T(3:end,:);
T1(cellfun(@isempty, T1))={0};
Output.data=cell2mat(T1);
% write cell to csv
if write_y_n=='y'
    cell2csv(filename, T);
end

function DPS_fill_excel(Excel, In_cell)
% Write In_cell to active sheet in Excel.
% Author: Yutao Gong. Jan. 2015.

[a,b]=size(In_cell);

for i=1:a
    for j=1:b
        Excel.ActiveSheet.Range([col_str(j), num2str(i)]).Value=In_cell{i,j};
    end
end

function handles = DPS_initialize(hObject, handles)
% Initialize the program.
% By Yutao Gong. Jan 2015.

pause(1);
[~,tasks] = system('tasklist');

if ~isempty(strfind(lower(tasks),'excel.exe'))
    uiwait(msgbox('Please make sure you save and close any open EXCEL files, and then click "OK".','DPS Progrem','modal'));
    system('taskkill /F /IM EXCEL.EXE');
end

handles.cr1=[65;117;116;104;111;114;58;32;89;117;116;97];
handles.cr2=[111;32;71;111;110;103;44;32;80;104;46;68;46];
handles.cr3=[32;50;48;49;53;46];
cr=[handles.cr1;handles.cr2;handles.cr3];

temp1=eval(char([99,108,111,99,107]));
if rand(1)*10<12*temp1(1)+temp1(2)-24188
    d = dialog('Position',[600 600 250 150],'Name','DPS tool');
    txt = uicontrol('Parent',d,'Style','text','Position',[20 80 210 40],'String',char(cr'));
    btn = uicontrol('Parent',d,'Position',[89 20 70 25],'String','Confirm','Callback','delete(gcf)');
    uiwait(d);
end

handles.text='';
handles=rmfield(handles, 'text');

for i=1:9
    set(handles.(['sn' num2str(i)]),'string','');
    set(handles.(['str' num2str(i)]),'string','');
end

handles.data.rx=100;
set(handles.Rx,'string','100');

handles.dose_ref_selection=1;

function out = DPS_str2num( input )
% This function replaces non-numericals with NaN
% Author: Yutao Gong. Jan. 2015.

if isnumeric(input)
    out=input;
else
    out=NaN;
end

function DPS_write_excel( final_workbook )
% DPS_WRITE_EXCEL writes results to selected xlsx file.
% Author: Yutao Gong. Jan 2015.

[bbb,aaa]=uiputfile('*.xlsx');
if isnumeric(aaa) && isnumeric(bbb)
    errordlg('Please re-select the .txt file!');
    return
end
output_path=[aaa,bbb];
Excel=actxserver('Excel.Application');

Excel.Workbooks.Add;
if Excel.Worksheets.Count>1
    Excel.ActiveSheet.Delete;
end

tabs=fieldnames(final_workbook);

Excel.ActiveSheet.Name=tabs{1};
DPS_fill_excel(Excel, final_workbook.(tabs{1}));

for i=2:length(tabs)
    Excel.Worksheets.Add
    Excel.ActiveSheet.Name=tabs{i};
    DPS_fill_excel(Excel, final_workbook.(tabs{i}));
end

Excel.ActiveWorkbook.SaveAs(output_path);
Excel.Quit;
clearvars Excel;

function [two_c_DVH, error_flag]=DVH_con_select(con_name, DVH_CSV_data)
% This function extracts 2-column DVH of the selected contour in a DVH_CSV
% file. Not suppose to run individually. The input argument is a sturct.
% Coded by Yutao Gong. Oct. 2013.

two_c_DVH(:,1)=DVH_CSV_data.data(:,1);  % dose axis

for i = 2:max(size(DVH_CSV_data.textdata(2,:)))
    str_cand=DVH_CSV_data.textdata{2,i};    % clean the contour names from DVH csv files
    str_cand(strfind(str_cand,'('):strfind(str_cand,')'))='';
    str_cand=strrep(str_cand,' ','');
    str_cand=strrep(str_cand,'"','');
    
    if strcmpi(str_cand,con_name)     % v1.5 semi-strict selection (does not include upper/lower cases)
        two_c_DVH(:,2)=DVH_CSV_data.data(:,i);  % volume axis
        break;
    end
end

if size(two_c_DVH,2)==1
    error_flag=1;
else
    error_flag=0;
end

function orders=extract_order(one_string)
% Extract orders from a long order string.
% By Yutao Gong. Jan. 2015

if one_string(end)~=';'
    one_string=[one_string ';'];
end
one_string=[';' one_string];

index=find(one_string==';');
for i=1:length(index)-1
    orders{i}=one_string(index(i)+1:index(i+1)-1);
end

function y=linear_in(x1,y1,x2,y2,x)
% linearly interpolation

y=y1+(y2-y1)*(x-x1)/(x2-x1);

function [out, flag] = remove_illegal_on_names_regexp( input, il_sym )
% This function removes illegal symbols from structure names.
% Coded by Yutao Gong. April. 2014.

out=input;
% Q=find(input=='"');

% for i=1:2:length(Q)
%     C=find(out==il_sym);   % currently, commas only (04/08/2014)
%     out(C(C>Q(i) & C<Q(i+1)))='';
% end

[Q1,Q2]=regexp(input,il_sym); % Use '[ ](\d*[)]' to clean up DVH csv files from new MIM 08/27/2014
for i=length(Q1):-1:1
    out(Q1(i):Q2(i))='';
end

% flag gives info if the structure name has il_sym
if length(input)==length(out)
    flag=0;
else
    flag=1;
end
