"""Store configuration: ``iroc_store.yaml`` at the store root.

The config names the trials the store knows about and how to recognise their
case IDs from DICOM headers, plus layout and ingest tuning. See the module
README for the full reference.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

CONFIG_NAME = "iroc_store.yaml"
CATALOG_NAME = ".catalog.sqlite"
LOCK_NAME = ".store.lock"
CONFIG_SCHEMA = "iroc-store.config/1"

DEFAULT_MODALITY_DIRNAMES = {
    "CT": "CT", "MR": "MR", "PT": "PET", "NM": "NM", "US": "US", "CR": "CR", "DX": "DX",
    "RTSTRUCT": "RTSTRUCT", "RTDOSE": "RTDOSE", "RTPLAN": "RTPLAN", "RTIMAGE": "RTIMAGE",
    "RTRECORD": "RTRECORD", "REG": "REG", "SEG": "SEG", "SR": "SR", "KO": "KO", "PR": "PR",
}
DEFAULT_FILE_PREFIXES = {
    "CT": "CT", "MR": "MR", "PT": "PT", "NM": "NM", "RTSTRUCT": "RS", "RTDOSE": "RD",
    "RTPLAN": "RP", "RTIMAGE": "RI", "RTRECORD": "RT", "REG": "RE", "SEG": "SG", "SR": "SR",
}
DEFAULT_IGNORE_GLOBS = ["Thumbs.db", "desktop.ini", ".DS_Store", "~$*", "*.part", "DICOMDIR"]


class ConfigError(ValueError):
    """Raised when ``iroc_store.yaml`` is missing or invalid."""


@dataclass
class TrialRule:
    """How to recognise one trial from DICOM headers and folder names."""

    id: str
    name: str = ""
    protocol_ids: list[str] = field(default_factory=list)
    case_id_patterns: list[str] = field(default_factory=list)
    patient_id_patterns: list[str] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)
    case_id_normalize: str = "upper_dash"

    def __post_init__(self) -> None:
        if not self.id:
            raise ConfigError("trial rule without id")
        if not self.patient_id_patterns:
            self.patient_id_patterns = list(self.case_id_patterns)
        for pat in self.case_id_patterns + self.patient_id_patterns:
            try:
                rx = re.compile(pat)
            except re.error as exc:
                raise ConfigError(f"trial {self.id}: bad regex {pat!r}: {exc}") from exc
            if "case" not in rx.groupindex:
                raise ConfigError(f"trial {self.id}: regex {pat!r} needs a (?P<case>...) group")
        self._case_rx = [re.compile(p) for p in self.case_id_patterns]
        self._patient_rx = [re.compile(p) for p in self.patient_id_patterns]
        self._protocol_ids = {p.strip().upper() for p in self.protocol_ids}
        self._keywords = [k.lower() for k in self.keywords if k]

    def match_case_in_text(self, text: str) -> str | None:
        """Return the raw case id found in ``text`` (a folder name), or None."""
        for rx in self._case_rx:
            m = rx.search(text)
            if m:
                return m.group("case")
        return None

    def match_patient_id(self, patient_id: str) -> str | None:
        for rx in self._patient_rx:
            m = rx.search(patient_id)
            if m:
                return m.group("case")
        return None

    def matches_protocol(self, protocol_id: str) -> bool:
        return bool(protocol_id) and protocol_id.strip().upper() in self._protocol_ids

    def keyword_in(self, text: str) -> bool:
        low = text.lower()
        return any(k in low for k in self._keywords)


@dataclass
class StoreConfig:
    root: Path
    trials: list[TrialRule] = field(default_factory=list)
    inbox: Path = Path("_inbox")
    holding: Path = Path("_holding")
    logs: Path = Path("_logs")
    reports: Path = Path("_reports")
    overview_dir: Path = Path("_overview")
    overview_auto: bool = True
    modality_dirnames: dict[str, str] = field(
        default_factory=lambda: dict(DEFAULT_MODALITY_DIRNAMES))
    file_prefixes: dict[str, str] = field(default_factory=lambda: dict(DEFAULT_FILE_PREFIXES))
    desc_max_len: int = 40
    max_path: int = 240
    settle_seconds: int = 120
    keep_archives: bool = False
    verify_copy: str = "full"
    ignore_globs: list[str] = field(default_factory=lambda: list(DEFAULT_IGNORE_GLOBS))
    strict_header: bool = True
    on_ingest: list[str] = field(default_factory=lambda: ["dicom_qc"])
    keep_failed_runs: bool = True
    lock_stale_minutes: int = 120
    busy_timeout_seconds: int = 30
    interval_seconds: int = 300

    def __post_init__(self) -> None:
        self.root = Path(self.root)
        for attr in ("inbox", "holding", "logs", "reports", "overview_dir"):
            p = Path(getattr(self, attr))
            if not p.is_absolute():
                p = self.root / p
            setattr(self, attr, p)
        if self.verify_copy not in ("full", "size"):
            raise ConfigError("ingest.verify_copy must be 'full' or 'size'")
        ids = [t.id for t in self.trials]
        if len({i.upper() for i in ids}) != len(ids):
            raise ConfigError("duplicate trial ids (case-insensitive)")

    # -- convenience -----------------------------------------------------
    @property
    def catalog_path(self) -> Path:
        return self.root / CATALOG_NAME

    @property
    def lock_path(self) -> Path:
        return self.root / LOCK_NAME

    def trial(self, trial_id: str) -> TrialRule:
        for t in self.trials:
            if t.id.upper() == trial_id.upper():
                return t
        raise ConfigError(f"unknown trial {trial_id!r}; known: {[t.id for t in self.trials]}")

    def modality_dirname(self, modality: str) -> str:
        return self.modality_dirnames.get(modality.upper(), modality.upper() or "OTHER")

    def file_prefix(self, modality: str) -> str:
        return self.file_prefixes.get(modality.upper(), (modality.upper() or "IM")[:2])


# ---------------------------------------------------------------------------
# loading / writing
# ---------------------------------------------------------------------------

def _get(d: dict, *keys, default=None):
    cur = d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


def config_from_dict(root: Path, data: dict) -> StoreConfig:
    if not isinstance(data, dict):
        raise ConfigError("config must be a mapping")
    schema = data.get("schema", CONFIG_SCHEMA)
    if schema != CONFIG_SCHEMA:
        raise ConfigError(f"unsupported config schema {schema!r}")
    trials = []
    for t in data.get("trials") or []:
        if not isinstance(t, dict):
            raise ConfigError("each trial must be a mapping")
        trials.append(TrialRule(
            id=str(t.get("id", "")),
            name=str(t.get("name", "") or ""),
            protocol_ids=[str(x) for x in (t.get("protocol_ids") or [])],
            case_id_patterns=[str(x) for x in (t.get("case_id_patterns") or [])],
            patient_id_patterns=[str(x) for x in (t.get("patient_id_patterns") or [])],
            keywords=[str(x) for x in (t.get("keywords") or [])],
            case_id_normalize=str(t.get("case_id_normalize", "upper_dash")),
        ))
    kw = dict(root=root, trials=trials)
    paths = data.get("paths") or {}
    for k in ("inbox", "holding", "logs", "reports"):
        if k in paths:
            kw[k] = Path(paths[k])
    layout = data.get("layout") or {}
    if "modality_dirnames" in layout:
        kw["modality_dirnames"] = {str(k).upper(): str(v)
                                   for k, v in layout["modality_dirnames"].items()}
    if "file_prefixes" in layout:
        kw["file_prefixes"] = {str(k).upper(): str(v) for k, v in layout["file_prefixes"].items()}
    for k in ("desc_max_len", "max_path"):
        if k in layout:
            kw[k] = int(layout[k])
    ingest = data.get("ingest") or {}
    for k in ("settle_seconds",):
        if k in ingest:
            kw[k] = int(ingest[k])
    for k in ("keep_archives", "strict_header", "keep_failed_runs"):
        if k in ingest:
            kw[k] = bool(ingest[k])
    if "verify_copy" in ingest:
        kw["verify_copy"] = str(ingest["verify_copy"])
    if "ignore_globs" in ingest:
        kw["ignore_globs"] = [str(x) for x in ingest["ignore_globs"]]
    if "on_ingest" in ingest:
        kw["on_ingest"] = [str(x) for x in (ingest["on_ingest"] or [])]
    catalog = data.get("catalog") or {}
    for k in ("lock_stale_minutes", "busy_timeout_seconds"):
        if k in catalog:
            kw[k] = int(catalog[k])
    sched = data.get("schedule") or {}
    if "interval_seconds" in sched:
        kw["interval_seconds"] = int(sched["interval_seconds"])
    ov = data.get("overview") or {}
    if "dir" in ov:
        kw["overview_dir"] = Path(ov["dir"])
    if "auto" in ov:
        kw["overview_auto"] = bool(ov["auto"])
    return StoreConfig(**kw)


def load_config(root: Path | str) -> StoreConfig:
    root = Path(root)
    path = root / CONFIG_NAME
    if not path.is_file():
        raise ConfigError(f"no {CONFIG_NAME} in {root}")
    with open(path, encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    return config_from_dict(root, data)


def find_root(start: Path | str | None = None) -> Path:
    """Resolve the store root: explicit, ``$IROC_STORE_ROOT``, or walk up from cwd."""
    if start is not None:
        p = Path(start)
        if (p / CONFIG_NAME).is_file():
            return p
        raise ConfigError(f"{p} has no {CONFIG_NAME}")
    env = os.environ.get("IROC_STORE_ROOT")
    if env:
        return find_root(env)
    cur = Path.cwd()
    for candidate in [cur, *cur.parents]:
        if (candidate / CONFIG_NAME).is_file():
            return candidate
    raise ConfigError(f"no {CONFIG_NAME} found in {cur} or its parents; "
                      "use --root or set IROC_STORE_ROOT")


def default_config_text(trials: list[str] | None = None) -> str:
    trials = trials or ["EXAMPLE-TRIAL"]
    blocks = []
    for tid in trials:
        tag = re.sub(r"[^A-Za-z0-9]", "", tid.split("-")[-1]) or "CASE"
        blocks.append(
            f"  - id: {tid}\n"
            f"    name: {tid}\n"
            f"    protocol_ids: [\"{tid}\"]              # ClinicalTrialProtocolID (0012,0020)\n"
            f"    case_id_patterns:\n"
            f"      - '(?i)\\b(?P<case>{tag}[-_ ]?\\d{{3,4}})\\b'   # folder names\n"
            f"    patient_id_patterns: []            # empty -> reuse case_id_patterns\n"
            f"    keywords: [\"{tag}\"]\n"
            f"    case_id_normalize: upper_dash\n"
        )
    return (
        f"schema: {CONFIG_SCHEMA}\n"
        "paths:\n  inbox: _inbox\n  holding: _holding\n  logs: _logs\n  reports: _reports\n"
        "trials:\n" + "".join(blocks) +
        "layout:\n"
        "  modality_dirnames: {PT: PET, MR: MR, CT: CT, RTSTRUCT: RTSTRUCT, RTDOSE: RTDOSE, "
        "RTPLAN: RTPLAN, REG: REG, SEG: SEG, SR: SR}\n"
        "  file_prefixes: {CT: CT, MR: MR, PT: PT, RTSTRUCT: RS, RTDOSE: RD, RTPLAN: RP, "
        "REG: RE, SEG: SG}\n"
        "  desc_max_len: 40\n  max_path: 240\n"
        "ingest:\n"
        "  settle_seconds: 120\n  keep_archives: false\n  verify_copy: full\n"
        "  ignore_globs: [\"Thumbs.db\", \"desktop.ini\", \".DS_Store\", \"~$*\", \"*.part\", "
        "\"DICOMDIR\"]\n"
        "  strict_header: true          # DICOM header is authoritative; mismatches -> _holding\n"
        "  on_ingest: [dicom_qc]\n  keep_failed_runs: true\n"
        "catalog: {lock_stale_minutes: 120, busy_timeout_seconds: 30}\n"
        "schedule: {interval_seconds: 300}\n"
        "overview: {auto: true, dir: _overview}\n"
    )


def write_default_config(root: Path | str, trials: list[str] | None = None,
                         overwrite: bool = False) -> Path:
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    path = root / CONFIG_NAME
    if path.exists() and not overwrite:
        raise ConfigError(f"{path} already exists")
    path.write_text(default_config_text(trials), encoding="utf-8")
    return path
