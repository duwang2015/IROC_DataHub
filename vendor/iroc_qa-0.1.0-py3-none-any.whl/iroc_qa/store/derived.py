"""Derived data: ``store.derive(...)`` gives a module a run directory, then records
outputs, provenance and a ``run.json`` manifest when the block completes."""

from __future__ import annotations

import hashlib
import json
import logging
import secrets
import socket
import traceback
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from .. import __version__ as _tool_version
from .catalog import utcnow
from .fsutil import atomic_write_text, iter_files, remove_tree, sha256_file
from .layout import RUN_MANIFEST, module_dirname, run_dirname
from .lock import _username
from .sniff import platform_kind, sniff
from .store import CaseRef, Store

logger = logging.getLogger(__name__)
RUN_SCHEMA = "iroc-store.run/1"
RUN_LOG = "run.log"


@dataclass(frozen=True)
class SeriesRef:
    id: str
    series_uid: str
    modality: str
    dir: Path
    rel_dir: str
    batch: str
    n_files: int
    sha256_agg: str

    @property
    def files(self) -> list[Path]:
        return sorted(p for p in self.dir.iterdir() if p.is_file())


@dataclass(frozen=True)
class FileRef:
    id: int
    rel_path: str
    path: Path
    sha256: str
    kind: str


def _canonical_hash(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"),
                                     default=str).encode("utf-8")).hexdigest()


def series_refs(store: Store, case: CaseRef, modality: str | None = None,
                batch: str | None = None, current_only: bool = True) -> list[SeriesRef]:
    cat = store.catalog
    c = cat.get_case(case.pk)
    bid = None
    if batch:
        bid = f"{case.pk}/{batch}"
    elif current_only and c and c["current_batch_id"]:
        bid = c["current_batch_id"]
    out = []
    for s in cat.series_for_case(case.pk, batch_id=bid, modality=modality):
        shas = sorted(f["sha256"] for f in cat.files_for_series(s["id"]))
        out.append(SeriesRef(
            id=s["id"], series_uid=s["series_uid"], modality=s["modality"],
            dir=store.abs(s["rel_dir"]), rel_dir=s["rel_dir"],
            batch=s["batch_id"].rsplit("/", 1)[-1], n_files=s["n_instances"],
            sha256_agg=hashlib.sha256("".join(shas).encode()).hexdigest()))
    return out


class DerivedRun:
    def __init__(self, store: Store, case: CaseRef, module: str, version: str, params: dict,
                 inputs: dict[str, list], force: bool = False):
        self.store = store
        self.case = case
        self.module = module
        self.version = version
        self.params = dict(params or {})
        self.inputs = {k: list(v) for k, v in (inputs or {}).items()}
        self.force = force
        self.params_hash = _canonical_hash(self.params)
        self.inputs_hash = _canonical_hash(sorted(
            f"{role}:{getattr(x, 'sha256_agg', None) or getattr(x, 'sha256', '')}"
            for role, xs in self.inputs.items() for x in xs))
        self.cached = False
        self.existing: dict | None = None
        self.dir: Path = Path()
        self.final_dir: Path = Path()
        self.run_name = ""
        self.run_id = ""
        self.started_at = ""
        self._outputs: list[dict] = []
        self.log = logging.getLogger(f"{__name__}.{module}")
        self._handler: logging.Handler | None = None

    # -- context manager --------------------------------------------------------------
    def __enter__(self) -> DerivedRun:
        cat = self.store.catalog
        hit = cat.find_cached_run(self.case.pk, self.module, self.version, self.params_hash,
                                  self.inputs_hash)
        mdir = self.case.derived_dir / module_dirname(self.module, self.version)
        if hit and not self.force and self.store.abs(hit["rel_dir"]).is_dir():
            self.cached = True
            self.existing = hit
            self.run_name = hit["run_name"]
            self.run_id = hit["id"]
            self.dir = self.final_dir = self.store.abs(hit["rel_dir"])
            logger.info("%s@%s on %s: cached run %s", self.module, self.version, self.case.pk,
                        self.run_name)
            return self
        now = datetime.now(timezone.utc)
        self.started_at = utcnow()
        self.run_name = run_dirname(now, _canonical_hash([self.params_hash, self.inputs_hash,
                                                          self.started_at, secrets.token_hex(4)]))
        self.run_id = f"{self.case.pk}/{self.module}@{self.version}/{self.run_name}"
        self.final_dir = mdir / self.run_name
        self.dir = mdir / f".tmp-{self.run_name}"
        if self.dir.exists():
            remove_tree(self.dir)
        self.dir.mkdir(parents=True)
        self._handler = logging.FileHandler(self.dir / RUN_LOG, encoding="utf-8")
        self._handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        logging.getLogger().addHandler(self._handler)
        cat.insert_run(self.run_id, self.case.pk, self.module, self.version, self.run_name,
                       self.store.rel(self.dir), self.params, self.params_hash,
                       self.inputs_hash, self._inputs_manifest(), "running", self.started_at,
                       socket.gethostname(), _username(), _tool_version)
        return self

    def add_output(self, role: str, path: Path, kind: str | None = None,
                   parents: list | None = None) -> None:
        p = Path(path)
        rel = p.relative_to(self.dir).as_posix() if p.is_absolute() else p.as_posix()
        self._outputs.append({"role": role, "path": rel, "kind": kind,
                              "parents": [x if isinstance(x, str) else _role_of(self, x)
                                          for x in (parents or [])]})

    def __exit__(self, exc_type, exc, tb) -> bool:
        if self.cached:
            return False
        if self._handler is not None:
            logging.getLogger().removeHandler(self._handler)
            self._handler.close()
        if exc_type is None:
            try:
                self._finish_ok()
            except Exception:
                self._finish_failed("finalisation failed:\n" + traceback.format_exc())
                raise
            return False
        self._finish_failed("".join(traceback.format_exception(exc_type, exc, tb)))
        return False

    # -- internals ----------------------------------------------------------------------
    def _inputs_manifest(self) -> list[dict]:
        out = []
        for role, xs in self.inputs.items():
            for x in xs:
                if isinstance(x, SeriesRef):
                    out.append({"role": role, "series_id": x.id, "series_uid": x.series_uid,
                                "modality": x.modality, "batch": x.batch, "n_files": x.n_files,
                                "sha256_agg": x.sha256_agg})
                elif isinstance(x, FileRef):
                    out.append({"role": role, "file_id": x.id, "rel_path": x.rel_path,
                                "sha256": x.sha256})
                else:
                    out.append({"role": role, "value": str(x)})
        return out

    def _collect_outputs(self) -> list[dict]:
        declared = {o["path"]: o for o in self._outputs}
        outs = []
        for f in iter_files(self.dir):
            rel = f.relative_to(self.dir).as_posix()
            if rel in (RUN_MANIFEST, RUN_LOG):
                continue
            d = declared.get(rel, {"role": "other", "path": rel, "kind": None, "parents": []})
            kind = d.get("kind") or platform_kind(sniff(f))
            outs.append({"role": d["role"], "path": rel, "kind": kind, "size": f.stat().st_size,
                         "sha256": sha256_file(f), "parents": d.get("parents") or []})
        return outs

    def _manifest(self, status: str, outputs: list[dict], error: str | None = None) -> dict:
        m = {"schema": RUN_SCHEMA, "run_id": self.run_name, "module": self.module,
             "version": self.version, "trial": self.case.trial, "case_id": self.case.case_id,
             "params": self.params, "params_hash": self.params_hash,
             "inputs_hash": self.inputs_hash, "inputs": self._inputs_manifest(),
             "outputs": outputs, "status": status, "started_at": self.started_at,
             "finished_at": utcnow(), "host": socket.gethostname(), "user": _username(),
             "iroc_qa_version": _tool_version, "log": RUN_LOG}
        if error:
            m["error"] = error
        return m

    def _finish_ok(self) -> None:
        outputs = self._collect_outputs()
        man = self._manifest("completed", outputs)
        atomic_write_text(self.dir / RUN_MANIFEST, json.dumps(man, indent=1, ensure_ascii=False))
        self.final_dir.parent.mkdir(parents=True, exist_ok=True)
        self.dir.rename(self.final_dir)
        self.dir = self.final_dir
        rel_dir = self.store.rel(self.final_dir)
        cat = self.store.catalog
        series_by_role: dict[str, list[str]] = {}
        files_by_role: dict[str, list[int]] = {}
        for role, xs in self.inputs.items():
            for x in xs:
                if isinstance(x, SeriesRef):
                    series_by_role.setdefault(role, []).append(x.id)
                elif isinstance(x, FileRef):
                    files_by_role.setdefault(role, []).append(x.id)
        with cat.transaction():
            cat.finish_run(self.run_id, "completed", man["finished_at"], rel_dir, man)
            ids = cat.insert_files({
                "case_pk": self.case.pk, "origin": "derived", "derived_run_id": self.run_id,
                "kind": o["kind"], "rel_path": f"{rel_dir}/{o['path']}", "size": o["size"],
                "sha256": o["sha256"], "metadata": {"role": o["role"]},
            } for o in outputs)
            prov = []
            for fid, o in zip(ids, outputs):
                for role in o["parents"]:
                    for sid in series_by_role.get(role, []):
                        prov.append((self.run_id, role, None, sid, fid))
                    for pid in files_by_role.get(role, []):
                        prov.append((self.run_id, role, pid, None, fid))
            if prov:
                cat.insert_provenance(prov)
        self.store.log.append(self.case.trial, "derive",
                              f"{self.module}@{self.version} run {self.run_name}: "
                              f"{len(outputs)} output(s)", case_id=self.case.case_id,
                              details={"run_id": self.run_id})
        logger.info("%s@%s on %s: completed run %s", self.module, self.version, self.case.pk,
                    self.run_name)

    def _finish_failed(self, error: str) -> None:
        man = self._manifest("failed", [], error)
        try:
            atomic_write_text(self.dir / RUN_MANIFEST,
                              json.dumps(man, indent=1, ensure_ascii=False))
        except OSError:
            pass
        failed_dir = self.final_dir.with_name(self.final_dir.name + ".failed")
        if self.store.cfg.keep_failed_runs:
            try:
                if failed_dir.exists():
                    remove_tree(failed_dir)
                self.dir.rename(failed_dir)
                self.dir = failed_dir
            except OSError:
                pass
        else:
            remove_tree(self.dir)
        try:
            self.store.catalog.finish_run(self.run_id, "failed", man["finished_at"],
                                          self.store.rel(self.dir) if self.dir.exists() else "",
                                          man)
        except Exception as exc:  # pragma: no cover
            logger.warning("could not record failed run: %s", exc)
        logger.error("%s@%s on %s: run %s failed", self.module, self.version, self.case.pk,
                     self.run_name)


def _role_of(run: DerivedRun, ref) -> str:
    for role, xs in run.inputs.items():
        if ref in xs:
            return role
    return "other"


def derive(store: Store, case: CaseRef, module: str, version: str, params: dict | None,
           inputs: dict[str, list] | None, *, force: bool = False) -> DerivedRun:
    return DerivedRun(store, case, module, version, params or {}, inputs or {}, force=force)
