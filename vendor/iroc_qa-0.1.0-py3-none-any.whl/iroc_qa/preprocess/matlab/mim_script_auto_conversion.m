function result = mim_script_auto_conversion(input,output)

% Version 8

% input: Excel file, the first six columns should be the same as the DVA form, and the seventh column should be the unique ID.
% output: Excel file, and save it as CSV file for MiM script manually.
% Note: Start from row1 with the content of the DVA without any title info.
% result = mim_script_auto_conversion('C:\Users\Haoyu\Desktop\LU002\LU002 sum.xlsx','2')

[~,~,raw] = xlsread(input);

result={'Constraint Name','Constraint Type','Contours','Regex Used','Contour Types','Dose','Dose Units','Volume','Volume Units','Comparison Type','Statistic Type','Negative Threshold','Positive Threshold'};

for i=1:size(raw,1)
    
    result{i+1,1}=raw{i,7};
    result{i+1,3}=raw{i,1};
    result{i+1,4}='0';
    
    count1=1;
    if isnumeric(raw{i,4})
        raw{i,4}=num2str(raw{i,4});
    end
    for index1=1:size(raw{i,4},2)
        if isnumber(raw{i,4}(index1))==1
            raw_4_temp(count1)=raw{i,4}(index1);
            count1=1+count1;
        elseif exist('raw_4_temp','var')==1
            raw_4_temp(count1)=' ';
            count1=1+count1;
        end
    end
    if exist('raw_4_temp','var')==1
    raw_4_temp=strsplit(raw_4_temp);
    end
    clear count3 index3
    
    count2=1;
    if isnumeric(raw{i,5})
        raw{i,5}=num2str(raw{i,5});
    end
    for index2=1:size(raw{i,5},2)
        if isnumber(raw{i,5}(index2))==1
            raw_5_temp(count2)=raw{i,5}(index2);
            count2=1+count2;
        elseif exist('raw_5_temp','var')==1
            raw_5_temp(count2)=' ';
            count2=1+count2;
        end
    end
    if exist('raw_5_temp','var')==1
    raw_5_temp=strsplit(raw_5_temp);
    end
    clear count2 index2
    
    %     count3=1;
    %     for index3=1:size(raw{i,6},2)
    %         if isnumber(raw{i,6}(index3))==1
    %             raw_6_temp(count3)=raw{i,6}(index3);
    %             count3=1+count3;
    %         elseif exist('raw_6_temp')==1
    %             raw_6_temp(count3)=' ';
    %             count3=1+count3;
    %         end
    %     end
    %     raw_6_temp=strsplit(raw_6_temp);
    %     clear count3 index3
    
    
    %     relationship1=find(raw{i,4}=='t', 1);
    %     relationship2=find(raw{i,4}=='a', 1);
    %     relationship3=find(raw{i,4}=='o', 1);
    %     relationship4=find(raw{i,4}=='<', 1);
    %     relationship5=find(raw{i,4}=='>', 1);
    %     if (isempty(relationship1)==0 && raw{i,4}(relationship1+1)=='o')||(isempty(relationship2)==0 && raw{i,4}(relationship2+1)=='n' && raw{i,4}(relationship2+2)=='d')
    %
    %     elseif (isempty(relationship3)==0 && raw{i,4}(relationship3+1)=='r')
    %
    %     elseif (isempty(relationship4)==0)
    %
    %     elseif (isempty(relationship5)==0)
    %
    %     else
    %
    %     end
    %     clear relationship1 relationship2 relationship3 relationship4 relationship5;
    
    
    relationship4=find(raw{i,4}=='<', 1);
    relationship5=find(raw{i,4}=='>', 1);
    if (isempty(relationship4)==0)
        relationmarker=1;
        score1_value=raw_4_temp{1};
    elseif (isempty(relationship5)==0)
        relationmarker=2;
        score1_value=raw_4_temp{1};
    else
        score1_value=raw_4_temp{1};
    end
    clear relationship4 relationship5;
    
    
    relationship1=find(raw{i,5}=='t', 1);
    relationship2=find(raw{i,5}=='a', 1);
    relationship4=find(raw{i,5}=='<', 1);
    relationship5=find(raw{i,5}=='>', 1);
    relationship6=find(raw{i,5}=='-', 1);
    if (isempty(relationship1)==0 && raw{i,5}(relationship1+1)=='o')||(isempty(relationship2)==0 && raw{i,5}(relationship2+1)=='n' && raw{i,5}(relationship2+2)=='d')||(isempty(relationship6)==0)
        if exist('relationmarker','var')==0
        relationmarker=2;
        end
        positive_threshold=str2num(raw_5_temp{2})-str2num(raw_4_temp{1});
        negative_threshold=str2num(raw_4_temp{1})-str2num(raw_5_temp{1});
    elseif (isempty(relationship4)==0)
        if exist('relationmarker','var')==0
        relationmarker=1;
        end
        positive_threshold=str2num(raw_5_temp{1})-str2num(raw_4_temp{1});
        negative_threshold=0;
    elseif (isempty(relationship5)==0)
        if exist('relationmarker','var')==0
        relationmarker=2;
        end
        negative_threshold=str2num(raw_4_temp{1})-str2num(raw_5_temp{1});
        positive_threshold=0;
    elseif raw{i,5}=='NaN'
        positive_threshold=0;
        negative_threshold=0;
    elseif ((isnan(raw{i,5})==1)||(isempty(find(raw{i,5}==' ', 1))==0))
        positive_threshold=0;
        negative_threshold=0;
    end
    clear relationship1 relationship2 relationship4 relationship5;
    
    
    if relationmarker==2
        result{i+1,10}='COMPARISON_TYPE_GREATER_THAN';
    elseif relationmarker==1
        result{i+1,10}='COMPARISON_TYPE_LESS_THAN';
    end
    
    
    if raw{i,3}(1)=='D'
        
        result{i+1,2}='CONSTRAINT_TYPE_D';
        result{i+1,6}=score1_value;
        result{i+1,12}=negative_threshold;
        result{i+1,13}=positive_threshold;
        
        index=find(raw{i,3}=='[');
        
        if lower(raw{i,3}(index-2:index-1))=='cc'
            result{i+1,9}='VOLUME_UNIT_ML';
            result{i+1,8}=raw{i,3}(2:index-3);
            if raw{i,3}(index+1)=='%'
                result{i+1,7}='DOSE_UNIT_PERCENT_RX';
            elseif lower(raw{i,3}(index+1:index+2))=='gy'
                result{i+1,7}='DOSE_UNIT_GY';
            end
        elseif raw{i,3}(index-1)=='%'
            result{i+1,9}='VOLUME_UNIT_PERCENT_CONTOUR_VOL';
            result{i+1,8}=raw{i,3}(2:index-2);
            if raw{i,3}(index+1)=='%'
                result{i+1,7}='DOSE_UNIT_PERCENT_RX';
            elseif lower(raw{i,3}(index+1:index+2))=='gy'
                result{i+1,7}='DOSE_UNIT_GY';
            end
        end
        
        clear index
        
    elseif raw{i,3}(1)=='V'
        
        result{i+1,2}='CONSTRAINT_TYPE_V';
        result{i+1,8}=score1_value;
        result{i+1,12}=negative_threshold;
        result{i+1,13}=positive_threshold;
        
        index=find(raw{i,3}=='[');
        
        if lower(raw{i,3}(index-2:index-1))=='gy'
            result{i+1,7}='DOSE_UNIT_GY';
            result{i+1,6}=raw{i,3}(2:index-3);
            if raw{i,3}(index+1)=='%'
                result{i+1,9}='VOLUME_UNIT_PERCENT_CONTOUR_VOL';
            elseif lower(raw{i,3}(index+1:index+2))=='cc'
                result{i+1,9}='VOLUME_UNIT_ML';
            end
        elseif raw{i,3}(index-1)=='%'
            result{i+1,7}='DOSE_UNIT_PERCENT_RX';
            result{i+1,6}=raw{i,3}(2:index-2);
            if raw{i,3}(index+1)=='%'
                result{i+1,9}='VOLUME_UNIT_PERCENT_CONTOUR_VOL';
            elseif lower(raw{i,3}(index+1:index+2))=='cc'
                result{i+1,9}='VOLUME_UNIT_ML';
            end
            
        end
        
        clear index
        
    elseif lower(raw{i,3}(1:4))=='mean'
        
        result{i+1,2}='CONSTRAINT_TYPE_STATISTIC';
        result{i+1,6}=score1_value;
        result{i+1,7}='DOSE_UNIT_GY';
        result{i+1,11}='MINMEANMAX_MEAN';
        
    elseif lower(raw{i,3}(1:3))=='max'
        
        result{i+1,2}='CONSTRAINT_TYPE_STATISTIC';
        result{i+1,6}=score1_value;
        result{i+1,7}='DOSE_UNIT_GY';
        result{i+1,11}='MINMEANMAX_MAX';
        
    elseif lower(raw{i,3}(1:3))=='min'
        
        result{i+1,2}='CONSTRAINT_TYPE_STATISTIC';
        result{i+1,6}=score1_value;
        result{i+1,7}='DOSE_UNIT_GY';
        result{i+1,11}='MINMEANMAX_MIN';
        
    end
    
    clear raw_4_temp
    clear raw_5_temp
    clear raw_6_temp
    clear score1_value negative_threshold positive_threshold relationmarker
    
end
T = cell2table(result);
writetable(T,output);

% xlswrite(output,result);


function logic=isnumber(a)
if (a=='0')||(a=='1')||(a=='2')||(a=='3')||(a=='4')||(a=='5')||(a=='6')||(a=='7')||(a=='8')||(a=='9')||(a=='.')
    logic=1;
else
    logic=0;
end