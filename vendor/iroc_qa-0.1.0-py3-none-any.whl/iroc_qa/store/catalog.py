"""SQLite catalog: a rebuildable index over the on-disk store.

The directory tree plus ``batch.json`` / ``run.json`` manifests are the source of truth;
this database only makes them queryable. It is tuned for SMB shares: no WAL, short
transactions, and all writers serialised through :class:`iroc_qa.store.lock.StoreLock`.
"""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Iterable
from contextlib import contextmanager
from datetime import date, datetime, timezone
from pathlib import Path

from .layout import batch_dirname

SCHEMA_VERSION = 2

DDL = """
CREATE TABLE IF NOT EXISTS trial (
  id TEXT PRIMARY KEY, name TEXT, protocol_ids TEXT, created_at TEXT NOT NULL,
  site TEXT NOT NULL DEFAULT 'OTHER', kind TEXT NOT NULL DEFAULT 'trial');
CREATE TABLE IF NOT EXISTS cases (
  id TEXT PRIMARY KEY, trial_id TEXT NOT NULL REFERENCES trial(id), case_id TEXT NOT NULL,
  current_batch_id TEXT, pinned INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  UNIQUE (trial_id, case_id COLLATE NOCASE));
CREATE TABLE IF NOT EXISTS batch (
  id TEXT PRIMARY KEY, case_pk TEXT NOT NULL REFERENCES cases(id), name TEXT NOT NULL,
  seq INTEGER NOT NULL, kind TEXT NOT NULL DEFAULT 'initial', ingest_id TEXT NOT NULL,
  source TEXT, ingested_at TEXT NOT NULL, n_files INTEGER NOT NULL DEFAULT 0,
  total_bytes INTEGER NOT NULL DEFAULT 0, manifest_json TEXT,
  UNIQUE (case_pk, name COLLATE NOCASE), UNIQUE (case_pk, seq));
CREATE TABLE IF NOT EXISTS series (
  id TEXT PRIMARY KEY, batch_id TEXT NOT NULL REFERENCES batch(id) ON DELETE CASCADE,
  case_pk TEXT NOT NULL REFERENCES cases(id), series_uid TEXT NOT NULL, study_uid TEXT,
  frame_of_reference_uid TEXT, modality TEXT NOT NULL, series_number INTEGER,
  series_description TEXT, study_date TEXT, n_instances INTEGER NOT NULL,
  rel_dir TEXT NOT NULL, ref_series_uid TEXT, ref_sop_uid TEXT, key_tags_json TEXT,
  UNIQUE (batch_id, series_uid, frame_of_reference_uid));
CREATE TABLE IF NOT EXISTS derived_run (
  id TEXT PRIMARY KEY, case_pk TEXT NOT NULL REFERENCES cases(id), module TEXT NOT NULL,
  version TEXT NOT NULL, run_name TEXT NOT NULL, rel_dir TEXT NOT NULL, params_json TEXT,
  params_hash TEXT NOT NULL, inputs_hash TEXT NOT NULL, inputs_json TEXT,
  status TEXT NOT NULL CHECK (status IN ('running','completed','failed')),
  started_at TEXT NOT NULL, finished_at TEXT, host TEXT, username TEXT, tool_version TEXT,
  manifest_json TEXT);
CREATE TABLE IF NOT EXISTS file (
  id INTEGER PRIMARY KEY, case_pk TEXT NOT NULL REFERENCES cases(id),
  origin TEXT NOT NULL CHECK (origin IN ('original','derived')),
  batch_id TEXT REFERENCES batch(id) ON DELETE CASCADE,
  derived_run_id TEXT REFERENCES derived_run(id) ON DELETE CASCADE,
  series_id TEXT REFERENCES series(id) ON DELETE CASCADE,
  kind TEXT NOT NULL, rel_path TEXT NOT NULL, size INTEGER NOT NULL, sha256 TEXT NOT NULL,
  mtime TEXT, media_type TEXT, source_relpath TEXT, sop_instance_uid TEXT, sop_class_uid TEXT,
  instance_number INTEGER, metadata_json TEXT,
  UNIQUE (rel_path COLLATE NOCASE),
  CHECK ((origin='original' AND batch_id IS NOT NULL) OR
         (origin='derived' AND derived_run_id IS NOT NULL)));
CREATE TABLE IF NOT EXISTS provenance (
  run_id TEXT NOT NULL REFERENCES derived_run(id) ON DELETE CASCADE, role TEXT NOT NULL,
  parent_file_id INTEGER REFERENCES file(id), parent_series_id TEXT REFERENCES series(id),
  child_file_id INTEGER NOT NULL REFERENCES file(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS holding_item (
  ingest_id TEXT NOT NULL, group_no INTEGER NOT NULL, rel_dir TEXT NOT NULL,
  reason TEXT NOT NULL, report_json TEXT, created_at TEXT NOT NULL, resolved_at TEXT,
  resolution TEXT, PRIMARY KEY (ingest_id, group_no));
CREATE TABLE IF NOT EXISTS trial_log (
  id INTEGER PRIMARY KEY, trial_id TEXT NOT NULL, case_id TEXT, at TEXT NOT NULL,
  username TEXT, host TEXT, action TEXT NOT NULL, message TEXT NOT NULL, details_json TEXT);
CREATE TABLE IF NOT EXISTS ingest_log (
  ingest_id TEXT PRIMARY KEY, started_at TEXT NOT NULL, finished_at TEXT, host TEXT,
  username TEXT, source TEXT, n_files INTEGER, n_batches INTEGER, n_holding INTEGER,
  n_duplicates INTEGER, summary_json TEXT);
CREATE INDEX IF NOT EXISTS idx_cases_trial ON cases(trial_id);
CREATE INDEX IF NOT EXISTS idx_batch_case ON batch(case_pk, seq);
CREATE INDEX IF NOT EXISTS idx_series_case_mod ON series(case_pk, modality);
CREATE INDEX IF NOT EXISTS idx_series_uid ON series(series_uid);
CREATE INDEX IF NOT EXISTS idx_series_for ON series(frame_of_reference_uid);
CREATE INDEX IF NOT EXISTS idx_file_sha ON file(sha256);
CREATE INDEX IF NOT EXISTS idx_file_sop ON file(sop_instance_uid);
CREATE INDEX IF NOT EXISTS idx_file_case_origin_kind ON file(case_pk, origin, kind);
CREATE INDEX IF NOT EXISTS idx_file_run ON file(derived_run_id);
CREATE INDEX IF NOT EXISTS idx_run_case_module ON derived_run(case_pk, module, version, status);
CREATE INDEX IF NOT EXISTS idx_run_cache ON derived_run(module, version, params_hash,
  inputs_hash, status);
CREATE INDEX IF NOT EXISTS idx_trial_log ON trial_log(trial_id, at);
"""


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def case_pk(trial_id: str, case_id: str) -> str:
    return f"{trial_id}/{case_id}"


def _rows(cur) -> list[dict]:
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


class Catalog:
    def __init__(self, path: Path | str, busy_timeout_seconds: int = 30, read_only: bool = False):
        self.path = Path(path)
        self.read_only = read_only
        self.busy_timeout = busy_timeout_seconds
        self._conn: sqlite3.Connection | None = None

    # -- connection ---------------------------------------------------------
    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = self.connect()
        return self._conn

    def connect(self) -> sqlite3.Connection:
        if self.read_only:
            uri = f"file:{self.path.as_posix()}?mode=ro"
            conn = sqlite3.connect(uri, uri=True, timeout=self.busy_timeout,
                                   isolation_level=None)
        else:
            conn = sqlite3.connect(str(self.path), timeout=self.busy_timeout,
                                   isolation_level=None)
        conn.row_factory = None
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute(f"PRAGMA busy_timeout={int(self.busy_timeout * 1000)}")
        if not self.read_only:
            conn.execute("PRAGMA journal_mode=DELETE")
            conn.execute("PRAGMA synchronous=FULL")
        return conn

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def init_schema(self) -> None:
        self.conn.executescript(DDL)
        cols = {r[1] for r in self.conn.execute("PRAGMA table_info(trial)")}
        if "site" not in cols:      # catalogs created before sites existed
            self.conn.execute("ALTER TABLE trial ADD COLUMN site TEXT NOT NULL DEFAULT 'OTHER'")
        if "kind" not in cols:
            self.conn.execute("ALTER TABLE trial ADD COLUMN kind TEXT NOT NULL DEFAULT 'trial'")
        self.conn.execute(f"PRAGMA user_version={SCHEMA_VERSION}")

    @contextmanager
    def transaction(self):
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            yield self.conn
        except BaseException:
            self.conn.execute("ROLLBACK")
            raise
        else:
            self.conn.execute("COMMIT")

    def __enter__(self) -> Catalog:
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # -- writes --------------------------------------------------------------
    def upsert_trial(self, trial_id: str, name: str = "", protocol_ids: Iterable[str] = (),
                     site: str = "OTHER", kind: str = "trial") -> None:
        self.conn.execute(
            "INSERT INTO trial(id, name, protocol_ids, created_at, site, kind) "
            "VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name, "
            "protocol_ids=excluded.protocol_ids, site=excluded.site, kind=excluded.kind",
            (trial_id, name, json.dumps(list(protocol_ids)), utcnow(), site or "OTHER",
             kind or "trial"))

    def upsert_case(self, trial_id: str, case_id: str) -> str:
        pk = case_pk(trial_id, case_id)
        now = utcnow()
        self.conn.execute(
            "INSERT INTO cases(id, trial_id, case_id, created_at, updated_at) VALUES (?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at",
            (pk, trial_id, case_id, now, now))
        return pk

    def insert_batch(self, pk: str, name: str, seq: int, kind: str, ingest_id: str,
                     source: str, ingested_at: str, n_files: int, total_bytes: int,
                     manifest: dict | None) -> str:
        bid = f"{pk}/{name}"
        self.conn.execute(
            "INSERT INTO batch(id, case_pk, name, seq, kind, ingest_id, source, ingested_at, "
            "n_files, total_bytes, manifest_json) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (bid, pk, name, seq, kind, ingest_id, source, ingested_at, n_files, total_bytes,
             json.dumps(manifest) if manifest is not None else None))
        return bid

    def insert_series(self, batch_id: str, pk: str, rel_dir: str, series_uid: str,
                      study_uid: str, for_uid: str, modality: str, series_number: int | None,
                      description: str, study_date: str, n_instances: int,
                      ref_series_uid: str = "", ref_sop_uid: str = "",
                      key_tags: dict | None = None) -> str:
        sid = f"{batch_id}/{rel_dir.rsplit('/', 1)[-1]}"
        self.conn.execute(
            "INSERT INTO series(id, batch_id, case_pk, series_uid, study_uid, "
            "frame_of_reference_uid, modality, series_number, series_description, study_date, "
            "n_instances, rel_dir, ref_series_uid, ref_sop_uid, key_tags_json) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (sid, batch_id, pk, series_uid, study_uid, for_uid, modality, series_number,
             description, study_date, n_instances, rel_dir, ref_series_uid, ref_sop_uid,
             json.dumps(key_tags or {})))
        return sid

    def insert_files(self, rows: Iterable[dict]) -> list[int]:
        ids = []
        for r in rows:
            cur = self.conn.execute(
                "INSERT INTO file(case_pk, origin, batch_id, derived_run_id, series_id, kind, "
                "rel_path, size, sha256, mtime, media_type, source_relpath, sop_instance_uid, "
                "sop_class_uid, instance_number, metadata_json) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (r["case_pk"], r["origin"], r.get("batch_id"), r.get("derived_run_id"),
                 r.get("series_id"), r["kind"], r["rel_path"], r["size"], r["sha256"],
                 r.get("mtime"), r.get("media_type"), r.get("source_relpath"),
                 r.get("sop_instance_uid"), r.get("sop_class_uid"), r.get("instance_number"),
                 json.dumps(r["metadata"]) if r.get("metadata") is not None else None))
            ids.append(cur.lastrowid)
        return ids

    def set_current_batch(self, pk: str, batch_id: str | None, pin: bool | None = None) -> None:
        if pin is None:
            self.conn.execute("UPDATE cases SET current_batch_id=?, updated_at=? WHERE id=?",
                              (batch_id, utcnow(), pk))
        else:
            self.conn.execute(
                "UPDATE cases SET current_batch_id=?, pinned=?, updated_at=? WHERE id=?",
                (batch_id, 1 if pin else 0, utcnow(), pk))

    def advance_current_if_unpinned(self, pk: str, batch_id: str) -> None:
        self.conn.execute("UPDATE cases SET current_batch_id=?, updated_at=? "
                          "WHERE id=? AND pinned=0", (batch_id, utcnow(), pk))

    def set_batch_kind(self, batch_id: str, kind: str) -> None:
        self.conn.execute("UPDATE batch SET kind=? WHERE id=?", (kind, batch_id))

    def insert_run(self, run_id: str, pk: str, module: str, version: str, run_name: str,
                   rel_dir: str, params: dict, params_hash: str, inputs_hash: str,
                   inputs: list, status: str, started_at: str, host: str, username: str,
                   tool_version: str) -> None:
        self.conn.execute(
            "INSERT INTO derived_run(id, case_pk, module, version, run_name, rel_dir, "
            "params_json, params_hash, inputs_hash, inputs_json, status, started_at, host, "
            "username, tool_version) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET status=excluded.status, rel_dir=excluded.rel_dir",
            (run_id, pk, module, version, run_name, rel_dir, json.dumps(params), params_hash,
             inputs_hash, json.dumps(inputs), status, started_at, host, username, tool_version))

    def finish_run(self, run_id: str, status: str, finished_at: str, rel_dir: str,
                   manifest: dict | None) -> None:
        self.conn.execute(
            "UPDATE derived_run SET status=?, finished_at=?, rel_dir=?, manifest_json=? WHERE id=?",
            (status, finished_at, rel_dir, json.dumps(manifest) if manifest else None, run_id))

    def delete_run(self, run_id: str) -> None:
        self.conn.execute("DELETE FROM derived_run WHERE id=?", (run_id,))

    def insert_provenance(self, rows: Iterable[tuple]) -> None:
        self.conn.executemany(
            "INSERT INTO provenance(run_id, role, parent_file_id, parent_series_id, child_file_id)"
            " VALUES (?,?,?,?,?)", list(rows))

    def insert_holding(self, ingest_id: str, group_no: int, rel_dir: str, reason: str,
                       report: dict | None) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO holding_item(ingest_id, group_no, rel_dir, reason, "
            "report_json, created_at) VALUES (?,?,?,?,?,?)",
            (ingest_id, group_no, rel_dir, reason, json.dumps(report) if report else None,
             utcnow()))

    def resolve_holding(self, ingest_id: str, group_no: int, resolution: str) -> None:
        self.conn.execute(
            "UPDATE holding_item SET resolved_at=?, resolution=? WHERE ingest_id=? AND group_no=?",
            (utcnow(), resolution, ingest_id, group_no))

    def insert_trial_log(self, trial_id: str, case_id: str | None, at: str, username: str,
                         host: str, action: str, message: str, details: dict | None) -> None:
        self.conn.execute(
            "INSERT INTO trial_log(trial_id, case_id, at, username, host, action, message, "
            "details_json) VALUES (?,?,?,?,?,?,?,?)",
            (trial_id, case_id, at, username, host, action, message,
             json.dumps(details) if details else None))

    def insert_ingest_log(self, ingest_id: str, started_at: str, finished_at: str | None,
                          host: str, username: str, source: str, n_files: int, n_batches: int,
                          n_holding: int, n_duplicates: int, summary: dict | None) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO ingest_log VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (ingest_id, started_at, finished_at, host, username, source, n_files, n_batches,
             n_holding, n_duplicates, json.dumps(summary) if summary else None))

    # -- reads ----------------------------------------------------------------
    def next_batch_seq(self, pk: str) -> int:
        row = self.conn.execute("SELECT COALESCE(MAX(seq),0)+1 FROM batch WHERE case_pk=?",
                                (pk,)).fetchone()
        return int(row[0])

    def next_batch_name(self, pk: str, today: date, existing_dirs: Iterable[str] = ()) -> str:
        taken = {r[0].upper() for r in self.conn.execute(
            "SELECT name FROM batch WHERE case_pk=?", (pk,))}
        taken |= {d.upper() for d in existing_dirs}
        n = 1
        while batch_dirname(today, n).upper() in taken:
            n += 1
        return batch_dirname(today, n)

    def find_sop(self, sop_uid: str) -> list[dict]:
        return _rows(self.conn.execute(
            "SELECT case_pk, batch_id, rel_path, sha256 FROM file WHERE sop_instance_uid=?",
            (sop_uid,)))

    def find_sha(self, sha256: str, pk: str | None = None) -> list[dict]:
        if pk:
            return _rows(self.conn.execute(
                "SELECT case_pk, batch_id, rel_path FROM file WHERE sha256=? AND case_pk=?",
                (sha256, pk)))
        return _rows(self.conn.execute(
            "SELECT case_pk, batch_id, rel_path FROM file WHERE sha256=?", (sha256,)))

    def get_case(self, pk: str) -> dict | None:
        rows = _rows(self.conn.execute("SELECT * FROM cases WHERE id=?", (pk,)))
        return rows[0] if rows else None

    def list_trials(self) -> list[dict]:
        return _rows(self.conn.execute("SELECT * FROM trial ORDER BY id"))

    def list_cases(self, trial_id: str | None = None) -> list[dict]:
        if trial_id:
            return _rows(self.conn.execute(
                "SELECT * FROM cases WHERE trial_id=? ORDER BY case_id", (trial_id,)))
        return _rows(self.conn.execute("SELECT * FROM cases ORDER BY trial_id, case_id"))

    def list_batches(self, pk: str) -> list[dict]:
        return _rows(self.conn.execute(
            "SELECT * FROM batch WHERE case_pk=? ORDER BY seq", (pk,)))

    def get_batch(self, batch_id: str) -> dict | None:
        rows = _rows(self.conn.execute("SELECT * FROM batch WHERE id=?", (batch_id,)))
        return rows[0] if rows else None

    def series_for_case(self, pk: str, batch_id: str | None = None,
                        modality: str | None = None) -> list[dict]:
        sql = "SELECT * FROM series WHERE case_pk=?"
        args: list = [pk]
        if batch_id:
            sql += " AND batch_id=?"
            args.append(batch_id)
        if modality:
            sql += " AND modality=?"
            args.append(modality.upper())
        sql += " ORDER BY batch_id, modality, series_number"
        return _rows(self.conn.execute(sql, args))

    def files_for_series(self, series_id: str) -> list[dict]:
        return _rows(self.conn.execute(
            "SELECT * FROM file WHERE series_id=? ORDER BY instance_number, rel_path",
            (series_id,)))

    def files_for_batch(self, batch_id: str) -> list[dict]:
        return _rows(self.conn.execute(
            "SELECT * FROM file WHERE batch_id=? ORDER BY rel_path", (batch_id,)))

    def cases_with_modalities(self, trial_id: str, modalities: Iterable[str],
                              current_only: bool = False,
                              missing: Iterable[str] = ()) -> list[str]:
        sql = "SELECT c.case_id FROM cases c WHERE c.trial_id=?"
        args: list = [trial_id]
        scope = " AND s.batch_id = c.current_batch_id" if current_only else ""
        for m in modalities:
            sql += (" AND EXISTS (SELECT 1 FROM series s WHERE s.case_pk=c.id AND s.modality=?"
                    + scope + ")")
            args.append(m.upper())
        for m in missing:
            sql += (" AND NOT EXISTS (SELECT 1 FROM series s WHERE s.case_pk=c.id AND "
                    "s.modality=?" + scope + ")")
            args.append(m.upper())
        sql += " ORDER BY c.case_id"
        return [r[0] for r in self.conn.execute(sql, args)]

    def runs_for_case(self, pk: str, module: str | None = None,
                      status: str | None = None) -> list[dict]:
        sql = "SELECT * FROM derived_run WHERE case_pk=?"
        args: list = [pk]
        if module:
            sql += " AND module=?"
            args.append(module)
        if status:
            sql += " AND status=?"
            args.append(status)
        sql += " ORDER BY started_at"
        return _rows(self.conn.execute(sql, args))

    def derived_files(self, pk: str, module: str | None = None, kind: str | None = None,
                      latest_only: bool = True) -> list[dict]:
        sql = ("SELECT f.*, r.module, r.version, r.run_name, r.started_at FROM file f "
               "JOIN derived_run r ON r.id=f.derived_run_id "
               "WHERE f.case_pk=? AND r.status='completed'")
        args: list = [pk]
        if module:
            sql += " AND r.module=?"
            args.append(module)
        if kind:
            sql += " AND f.kind LIKE ?"
            args.append(kind if "%" in kind else kind)
        if latest_only:
            sql += (" AND r.rowid = (SELECT r2.rowid FROM derived_run r2 "
                    "WHERE r2.case_pk=r.case_pk AND r2.module=r.module AND r2.version=r.version "
                    "AND r2.status='completed' ORDER BY r2.started_at DESC, r2.rowid DESC "
                    "LIMIT 1)")
        sql += " ORDER BY r.module, f.rel_path"
        return _rows(self.conn.execute(sql, args))

    def find_cached_run(self, pk: str, module: str, version: str, params_hash: str,
                        inputs_hash: str) -> dict | None:
        rows = _rows(self.conn.execute(
            "SELECT * FROM derived_run WHERE case_pk=? AND module=? AND version=? AND "
            "params_hash=? AND inputs_hash=? AND status='completed' ORDER BY started_at DESC "
            "LIMIT 1", (pk, module, version, params_hash, inputs_hash)))
        return rows[0] if rows else None

    def list_holding(self, unresolved_only: bool = True) -> list[dict]:
        sql = "SELECT * FROM holding_item"
        if unresolved_only:
            sql += " WHERE resolved_at IS NULL"
        return _rows(self.conn.execute(sql + " ORDER BY created_at, ingest_id, group_no"))

    def get_holding(self, ingest_id: str) -> list[dict]:
        return _rows(self.conn.execute(
            "SELECT * FROM holding_item WHERE ingest_id=? ORDER BY group_no", (ingest_id,)))

    def trial_log(self, trial_id: str, case_id: str | None = None, since: str | None = None,
                  action: str | None = None, limit: int | None = None) -> list[dict]:
        sql = "SELECT * FROM trial_log WHERE trial_id=?"
        args: list = [trial_id]
        if case_id:
            sql += " AND case_id=?"
            args.append(case_id)
        if since:
            sql += " AND at>=?"
            args.append(since)
        if action:
            sql += " AND action=?"
            args.append(action)
        sql += " ORDER BY at DESC, id DESC"
        if limit:
            sql += f" LIMIT {int(limit)}"
        return _rows(self.conn.execute(sql, args))

    def last_ingest(self) -> dict | None:
        rows = _rows(self.conn.execute(
            "SELECT * FROM ingest_log ORDER BY started_at DESC LIMIT 1"))
        return rows[0] if rows else None

    def stats(self) -> dict:
        c = self.conn
        out = {"trials": []}
        for t in self.list_trials():
            tid = t["id"]
            row = c.execute(
                "SELECT COUNT(DISTINCT c.id), COUNT(DISTINCT b.id), COALESCE(SUM(b.n_files),0), "
                "COALESCE(SUM(b.total_bytes),0) FROM cases c LEFT JOIN batch b ON b.case_pk=c.id "
                "WHERE c.trial_id=?", (tid,)).fetchone()
            mods = {m: n for m, n in c.execute(
                "SELECT s.modality, COUNT(DISTINCT s.case_pk) FROM series s JOIN cases c "
                "ON c.id=s.case_pk WHERE c.trial_id=? GROUP BY s.modality", (tid,))}
            derived = {m: n for m, n in c.execute(
                "SELECT r.module, COUNT(DISTINCT r.case_pk) FROM derived_run r JOIN cases c "
                "ON c.id=r.case_pk WHERE c.trial_id=? AND r.status='completed' GROUP BY r.module",
                (tid,))}
            last = c.execute(
                "SELECT MAX(b.ingested_at) FROM batch b JOIN cases c ON c.id=b.case_pk "
                "WHERE c.trial_id=?", (tid,)).fetchone()[0]
            out["trials"].append({
                "id": tid, "name": t["name"], "site": t.get("site", "OTHER"),
                "kind": t.get("kind", "trial"), "cases": row[0], "batches": row[1],
                "files": row[2], "bytes": row[3], "cases_by_modality": mods,
                "cases_by_module": derived, "last_ingest": last,
            })
        out["holding_open"] = c.execute(
            "SELECT COUNT(*) FROM holding_item WHERE resolved_at IS NULL").fetchone()[0]
        out["last_ingest"] = self.last_ingest()
        return out
