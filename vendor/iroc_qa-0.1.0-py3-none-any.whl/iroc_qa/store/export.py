"""Copy a conventional directory tree out of the store for analysts."""

from __future__ import annotations

import logging
from pathlib import Path

from .fsutil import copy_verified
from .store import Store

logger = logging.getLogger(__name__)


def export(store: Store, trial: str, cases: list[str] | None, dest: Path, *,
           what: str = "original", module: str | None = None, current_only: bool = True,
           note: str | None = None, verify_full: bool = True) -> int:
    """Export ``dest/<case>/<series dir>/...`` (original) or ``dest/<case>/<files>`` (derived).

    Returns the number of files copied and writes one ``export`` line to the trial log.
    """
    cat = store.catalog
    tid = store.cfg.trial(trial).id
    dest = Path(dest)
    case_ids = [store.case(tid, c).case_id for c in cases] if cases else \
        [c["case_id"] for c in cat.list_cases(tid)]
    n = 0
    exported = []
    for cid in case_ids:
        case = store.case(tid, cid)
        c = cat.get_case(case.pk)
        if c is None:
            logger.warning("unknown case %s", case.pk)
            continue
        if what == "derived":
            rows = cat.derived_files(case.pk, module=module, latest_only=True)
            for r in rows:
                src = store.abs(r["rel_path"])
                copy_verified(src, dest / cid / src.name, verify_full)
                n += 1
        else:
            bid = c["current_batch_id"] if current_only else None
            for s in cat.series_for_case(case.pk, batch_id=bid):
                sdir = store.abs(s["rel_dir"])
                prefix = "" if current_only else s["batch_id"].rsplit("/", 1)[-1] + "/"
                for f in cat.files_for_series(s["id"]):
                    src = store.abs(f["rel_path"])
                    copy_verified(src, dest / cid / f"{prefix}{sdir.name}" / src.name, verify_full)
                    n += 1
            for f in cat.conn.execute(
                    "SELECT rel_path, batch_id FROM file WHERE case_pk=? AND origin='original' "
                    "AND series_id IS NULL" + (" AND batch_id=?" if bid else ""),
                    [case.pk, bid] if bid else [case.pk]):
                src = store.abs(f[0])
                sub = src.parent.name
                prefix = "" if current_only else f[1].rsplit("/", 1)[-1] + "/"
                copy_verified(src, dest / cid / f"{prefix}{sub}" / src.name, verify_full)
                n += 1
        exported.append(cid)
    scope = f"derived {module or 'all modules'}" if what == "derived" else \
        ("original, current batch" if current_only else "original, all batches")
    msg = f"{len(exported)} case(s), {n} files ({scope}) -> {dest}"
    if note:
        msg += f" ; note: {note}"
    store.log.append(tid, "export", msg, case_id=exported[0] if len(exported) == 1 else None,
                     details={"cases": exported, "dest": str(dest), "what": what,
                              "module": module, "note": note})
    store.refresh_overview()
    return n
