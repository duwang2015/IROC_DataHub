"""DICOM quality control and validation utilities.

Provides tag completeness checks, slice consistency validation,
spatial alignment verification, and enhanced QC reporting for
radiotherapy DICOM data.
"""

from __future__ import annotations

import logging
import os
from collections import defaultdict

import numpy as np
import pydicom
import SimpleITK as sitk  # noqa: N813

try:
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Required DICOM tags per modality
# ---------------------------------------------------------------------------

REQUIRED_TAGS: dict[str, list[tuple[str, str]]] = {
    "CT": [
        ("Modality", "Modality"),
        ("RescaleSlope", "RescaleSlope"),
        ("RescaleIntercept", "RescaleIntercept"),
        ("PixelSpacing", "PixelSpacing"),
        ("ImagePositionPatient", "ImagePositionPatient"),
        ("ImageOrientationPatient", "ImageOrientationPatient"),
        ("SliceThickness", "SliceThickness"),
        ("Rows", "Rows"),
        ("Columns", "Columns"),
        ("BitsAllocated", "BitsAllocated"),
    ],
    "MR": [
        ("Modality", "Modality"),
        ("PixelSpacing", "PixelSpacing"),
        ("ImagePositionPatient", "ImagePositionPatient"),
        ("ImageOrientationPatient", "ImageOrientationPatient"),
        ("SliceThickness", "SliceThickness"),
        ("Rows", "Rows"),
        ("Columns", "Columns"),
        ("BitsAllocated", "BitsAllocated"),
    ],
    "PT": [
        ("Modality", "Modality"),
        ("PatientWeight", "PatientWeight"),
        ("RadiopharmaceuticalInformationSequence",
         "RadiopharmaceuticalInformationSequence"),
        ("PixelSpacing", "PixelSpacing"),
        ("ImagePositionPatient", "ImagePositionPatient"),
        ("SliceThickness", "SliceThickness"),
        ("Rows", "Rows"),
        ("Columns", "Columns"),
    ],
    "RTDOSE": [
        ("Modality", "Modality"),
        ("DoseGridScaling", "DoseGridScaling"),
        ("DoseUnits", "DoseUnits"),
        ("DoseType", "DoseType"),
        ("PixelSpacing", "PixelSpacing"),
        ("ImagePositionPatient", "ImagePositionPatient"),
        ("Rows", "Rows"),
        ("Columns", "Columns"),
        ("NumberOfFrames", "NumberOfFrames"),
        ("BitsAllocated", "BitsAllocated"),
    ],
    "RTSTRUCT": [
        ("Modality", "Modality"),
        ("StructureSetROISequence", "StructureSetROISequence"),
        ("ROIContourSequence", "ROIContourSequence"),
    ],
}

# Optional but recommended PET SUV tags (nested in RadiopharmaceuticalInfo)
PET_SUV_TAGS = [
    "RadionuclideTotalDose",
    "RadionuclideHalfLife",
    "RadiopharmaceuticalStartTime",
]


# ---------------------------------------------------------------------------
# Tag validation
# ---------------------------------------------------------------------------

def validate_dicom_tags(
    series_files: list[tuple[str, pydicom.Dataset]],
    modality: str,
) -> dict:
    """Verify required DICOM tags exist for the given modality.

    Parameters
    ----------
    series_files : list of (filepath, dataset)
    modality : str
        One of CT, MR, PT, RTDOSE, RTSTRUCT.

    Returns
    -------
    dict with keys:
        status   : "PASS" or "WARN"
        missing  : list of missing tag names
        present  : list of present tag names
        warnings : list of warning strings
    """
    if not series_files:
        return {"status": "FAIL", "missing": [], "present": [],
                "warnings": ["Empty series"]}

    ds = series_files[0][1]
    required = REQUIRED_TAGS.get(modality.upper(), [])

    present = []
    missing = []
    warnings = []

    for attr_name, display_name in required:
        if hasattr(ds, attr_name) and getattr(ds, attr_name) is not None:
            present.append(display_name)
        else:
            missing.append(display_name)

    # PET-specific: check SUV sub-tags
    if modality.upper() == "PT":
        radio_seq = getattr(ds, "RadiopharmaceuticalInformationSequence", None)
        if radio_seq and len(radio_seq) > 0:
            radio = radio_seq[0]
            for tag in PET_SUV_TAGS:
                if hasattr(radio, tag) and getattr(radio, tag) is not None:
                    present.append(tag)
                else:
                    missing.append(tag)
                    warnings.append(f"PET SUV tag missing: {tag}")
        acq_time = getattr(ds, "AcquisitionTime", None) or getattr(
            ds, "SeriesTime", None)
        if acq_time:
            present.append("AcquisitionTime")
        else:
            missing.append("AcquisitionTime")
            warnings.append("PET AcquisitionTime/SeriesTime missing")

    status = "PASS" if not missing else "WARN"
    return {
        "status": status,
        "missing": missing,
        "present": present,
        "warnings": warnings,
    }


# ---------------------------------------------------------------------------
# Slice consistency
# ---------------------------------------------------------------------------

def validate_series_consistency(
    series_files: list[tuple[str, pydicom.Dataset]],
) -> dict:
    """Check slice spacing uniformity, orientation consistency, and duplicates.

    Returns
    -------
    dict with keys:
        n_slices        : int
        spacing_uniform : bool
        spacing_values  : list of float (unique spacing values found)
        mean_spacing_mm : float
        orientation     : list[float] (6-element IOP)
        orientation_consistent : bool
        duplicate_instances : list of int (duplicate InstanceNumber values)
        warnings        : list of str
    """
    if len(series_files) < 2:
        return {
            "n_slices": len(series_files),
            "spacing_uniform": True,
            "spacing_values": [],
            "mean_spacing_mm": 0.0,
            "orientation": [],
            "orientation_consistent": True,
            "duplicate_instances": [],
            "warnings": ["Single slice or empty series"],
        }

    # Extract z-positions and orientations
    z_positions = []
    orientations = []
    instance_numbers = []
    warnings = []

    for fp, ds in series_files:
        ipp = getattr(ds, "ImagePositionPatient", None)
        if ipp is not None:
            z_positions.append(float(ipp[2]))

        iop = getattr(ds, "ImageOrientationPatient", None)
        if iop is not None:
            orientations.append([float(x) for x in iop])

        inst = getattr(ds, "InstanceNumber", None)
        if inst is not None:
            instance_numbers.append(int(inst))

    # Check orientation consistency
    orientation_consistent = True
    ref_orient = orientations[0] if orientations else []
    for o in orientations[1:]:
        if any(abs(a - b) > 1e-4 for a, b in zip(ref_orient, o)):
            orientation_consistent = False
            break
    if not orientation_consistent:
        warnings.append("Inconsistent ImageOrientationPatient across slices")

    # Check slice spacing
    z_sorted = sorted(z_positions)
    spacings = []
    for i in range(1, len(z_sorted)):
        spacings.append(round(z_sorted[i] - z_sorted[i - 1], 4))

    unique_spacings = sorted(set(spacings)) if spacings else []
    mean_spacing = float(np.mean(spacings)) if spacings else 0.0

    # Uniform if all spacings within 0.5mm of mean
    spacing_uniform = True
    if spacings:
        spacing_uniform = all(
            abs(s - mean_spacing) < 0.5 for s in spacings
        )
    if not spacing_uniform:
        warnings.append(
            f"Non-uniform slice spacing: {len(unique_spacings)} unique values"
        )

    # Check duplicate InstanceNumbers
    seen = defaultdict(int)
    for inst in instance_numbers:
        seen[inst] += 1
    duplicates = [k for k, v in seen.items() if v > 1]
    if duplicates:
        warnings.append(
            f"Duplicate InstanceNumbers: {duplicates[:5]}"
            + ("..." if len(duplicates) > 5 else "")
        )

    return {
        "n_slices": len(series_files),
        "spacing_uniform": spacing_uniform,
        "spacing_values": unique_spacings,
        "mean_spacing_mm": mean_spacing,
        "orientation": ref_orient,
        "orientation_consistent": orientation_consistent,
        "duplicate_instances": duplicates,
        "warnings": warnings,
    }


def check_slice_gaps(
    series_files: list[tuple[str, pydicom.Dataset]],
    tolerance_mm: float = 0.5,
) -> list[dict]:
    """Detect non-uniform slice spacing / gaps.

    Returns list of dicts with keys: index, z1, z2, spacing_mm, expected_mm.
    Empty list means no gaps detected.
    """
    z_positions = []
    for fp, ds in series_files:
        ipp = getattr(ds, "ImagePositionPatient", None)
        if ipp is not None:
            z_positions.append((float(ipp[2]), fp))

    if len(z_positions) < 3:
        return []

    z_positions.sort(key=lambda x: x[0])

    # Compute median spacing as expected
    spacings = [
        z_positions[i + 1][0] - z_positions[i][0]
        for i in range(len(z_positions) - 1)
    ]
    expected = float(np.median(spacings))

    gaps = []
    for i, sp in enumerate(spacings):
        if abs(sp - expected) > tolerance_mm:
            gaps.append({
                "index": i,
                "z1": z_positions[i][0],
                "z2": z_positions[i + 1][0],
                "spacing_mm": round(sp, 3),
                "expected_mm": round(expected, 3),
            })

    return gaps


# ---------------------------------------------------------------------------
# Spatial alignment
# ---------------------------------------------------------------------------

def check_spatial_alignment(
    image_a: sitk.Image,
    image_b: sitk.Image,
    label_a: str = "A",
    label_b: str = "B",
) -> dict:
    """Compare spatial properties between two SimpleITK images.

    Returns
    -------
    dict with keys:
        origin_match    : bool
        spacing_match   : bool
        direction_match : bool
        size_match      : bool
        origin_diff_mm  : list[float]
        spacing_diff_mm : list[float]
        warnings        : list[str]
    """
    origin_a = np.array(image_a.GetOrigin())
    origin_b = np.array(image_b.GetOrigin())
    spacing_a = np.array(image_a.GetSpacing())
    spacing_b = np.array(image_b.GetSpacing())
    dir_a = np.array(image_a.GetDirection())
    dir_b = np.array(image_b.GetDirection())
    size_a = image_a.GetSize()
    size_b = image_b.GetSize()

    origin_diff = (origin_a - origin_b).tolist()
    spacing_diff = (spacing_a - spacing_b).tolist()
    origin_match = all(abs(d) < 0.01 for d in origin_diff)
    spacing_match = all(abs(d) < 0.001 for d in spacing_diff)
    direction_match = all(abs(a - b) < 1e-6 for a, b in zip(dir_a, dir_b))
    size_match = size_a == size_b

    warnings = []
    if not origin_match:
        warnings.append(
            f"Origin mismatch: {label_a}={origin_a.tolist()} "
            f"vs {label_b}={origin_b.tolist()}"
        )
    if not spacing_match:
        warnings.append(
            f"Spacing mismatch: {label_a}={spacing_a.tolist()} "
            f"vs {label_b}={spacing_b.tolist()}"
        )
    if not direction_match:
        warnings.append(f"Direction cosines differ between {label_a} and {label_b}")
    if not size_match:
        warnings.append(
            f"Size mismatch: {label_a}={size_a} vs {label_b}={size_b}"
        )

    return {
        "origin_match": origin_match,
        "spacing_match": spacing_match,
        "direction_match": direction_match,
        "size_match": size_match,
        "origin_diff_mm": [round(d, 3) for d in origin_diff],
        "spacing_diff_mm": [round(d, 4) for d in spacing_diff],
        "warnings": warnings,
    }


# ---------------------------------------------------------------------------
# QC report generation
# ---------------------------------------------------------------------------

def _get_series_info(series_files, modality):
    """Extract summary info from a DICOM series for QC reporting."""
    if not series_files:
        return {}

    ds = series_files[0][1]
    info = {
        "modality": modality,
        "n_files": len(series_files),
        "patient_id": getattr(ds, "PatientID", "UNKNOWN"),
        "study_date": getattr(ds, "StudyDate", ""),
        "series_desc": getattr(ds, "SeriesDescription", ""),
    }

    # Pixel spacing
    ps = getattr(ds, "PixelSpacing", None)
    if ps is not None:
        info["pixel_spacing"] = f"{float(ps[0]):.3f} x {float(ps[1]):.3f}"
    else:
        info["pixel_spacing"] = "N/A"

    # Slice thickness
    st = getattr(ds, "SliceThickness", None)
    info["slice_thickness"] = f"{float(st):.3f}" if st else "N/A"

    # Image dimensions
    rows = getattr(ds, "Rows", "?")
    cols = getattr(ds, "Columns", "?")
    info["dimensions"] = f"{rows} x {cols}"

    # Bits
    info["bits_allocated"] = str(getattr(ds, "BitsAllocated", "?"))

    return info


def generate_qc_report(
    case_id: str,
    series_groups: dict,
    output_path: str,
    modality_map: dict | None = None,
) -> dict:
    """Generate an enhanced QC report for one case.

    Parameters
    ----------
    case_id : str
        Patient/case identifier.
    series_groups : dict
        SeriesInstanceUID → list of (filepath, dataset).
    output_path : str
        Excel file path for the report.
    modality_map : dict, optional
        Pre-computed UID → modality string.  If None, detected automatically.

    Returns
    -------
    QC summary dict with per-modality results.
    """
    # Import detect_modality from dcm2nii
    try:
        from dcm2nii import detect_modality
    except ImportError:
        def detect_modality(files):
            ds = files[0][1]
            return getattr(ds, "Modality", "").upper().strip()

    results = {
        "case_id": case_id,
        "modalities": {},
        "overall_status": "PASS",
        "warnings": [],
    }

    for uid, files in series_groups.items():
        if modality_map and uid in modality_map:
            mod = modality_map[uid]
        else:
            mod = detect_modality(files)

        if mod in ("RTPLAN", "REG", "SR", "KO", "PR"):
            continue

        mod_result = {
            "series_uid": uid[:20] + "...",
            "info": _get_series_info(files, mod),
        }

        # Tag validation
        tag_check = validate_dicom_tags(files, mod)
        mod_result["tag_check"] = tag_check
        if tag_check["status"] != "PASS":
            results["overall_status"] = "WARN"
            results["warnings"].extend(tag_check["warnings"])

        # Slice consistency (for multi-slice modalities)
        if mod in ("CT", "MR", "PT") and len(files) > 1:
            consistency = validate_series_consistency(files)
            mod_result["consistency"] = consistency
            if consistency["warnings"]:
                results["warnings"].extend(consistency["warnings"])

            gaps = check_slice_gaps(files)
            mod_result["gaps"] = gaps
            if gaps:
                results["overall_status"] = "WARN"
                results["warnings"].append(
                    f"{mod}: {len(gaps)} slice gap(s) detected"
                )

        results["modalities"][mod] = mod_result

    # Write Excel report if openpyxl available
    if HAS_OPENPYXL and output_path:
        _write_qc_excel(results, output_path)

    return results


def _write_qc_excel(results: dict, output_path: str):
    """Write QC results to a styled Excel workbook."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "QC Summary"

    # Styles
    header_font = Font(bold=True)
    header_fill = PatternFill(
        start_color="D9E1F2", end_color="D9E1F2", fill_type="solid"
    )
    pass_fill = PatternFill(
        start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"
    )
    warn_fill = PatternFill(
        start_color="FFEB9C", end_color="FFEB9C", fill_type="solid"
    )

    # Header row
    headers = [
        "Case ID", "Modality", "Series Description", "Files",
        "Dimensions", "Pixel Spacing (mm)", "Slice Thickness (mm)",
        "Bits", "Tag Check", "Slice Consistency", "Gaps", "Warnings",
    ]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill

    # Data rows
    for mod, mod_result in results["modalities"].items():
        info = mod_result.get("info", {})
        tag_status = mod_result.get("tag_check", {}).get("status", "N/A")
        missing = mod_result.get("tag_check", {}).get("missing", [])

        cons = mod_result.get("consistency", {})
        spacing_ok = cons.get("spacing_uniform", True)
        n_gaps = len(mod_result.get("gaps", []))

        warn_list = mod_result.get("tag_check", {}).get("warnings", [])
        warn_list += cons.get("warnings", [])

        row = [
            results["case_id"],
            mod,
            info.get("series_desc", ""),
            info.get("n_files", 0),
            info.get("dimensions", ""),
            info.get("pixel_spacing", ""),
            info.get("slice_thickness", ""),
            info.get("bits_allocated", ""),
            tag_status + (f" (missing: {', '.join(missing)})" if missing else ""),
            "OK" if spacing_ok else "NON-UNIFORM",
            str(n_gaps) if n_gaps else "0",
            "; ".join(warn_list) if warn_list else "",
        ]
        ws.append(row)

        # Color status cells
        row_idx = ws.max_row
        tag_cell = ws.cell(row=row_idx, column=9)
        tag_cell.fill = pass_fill if tag_status == "PASS" else warn_fill

    # Column widths
    widths = [18, 10, 25, 8, 14, 18, 18, 8, 30, 16, 8, 50]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[chr(64 + i)].width = w

    # Wrap text
    for row_cells in ws.iter_rows(min_row=2, max_row=ws.max_row):
        for cell in row_cells:
            cell.alignment = Alignment(wrap_text=True, vertical="top")

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    wb.save(output_path)
    logger.info("QC report saved: %s", output_path)


def summarize_conversion(
    reports: list[dict],
    output_path: str,
) -> dict:
    """Aggregate QC results across multiple cases.

    Parameters
    ----------
    reports : list of dict
        Output from generate_qc_report for each case.
    output_path : str
        Excel file path for the summary.

    Returns
    -------
    dict with overall statistics.
    """
    summary = {
        "total_cases": len(reports),
        "pass": 0,
        "warn": 0,
        "modality_counts": defaultdict(int),
    }

    for rpt in reports:
        if rpt.get("overall_status") == "PASS":
            summary["pass"] += 1
        else:
            summary["warn"] += 1
        for mod in rpt.get("modalities", {}):
            summary["modality_counts"][mod] += 1

    summary["modality_counts"] = dict(summary["modality_counts"])

    if HAS_OPENPYXL and output_path:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Conversion Summary"

        header_font = Font(bold=True)
        header_fill = PatternFill(
            start_color="D9E1F2", end_color="D9E1F2", fill_type="solid"
        )

        headers = ["Case ID", "Status", "Modalities", "Warnings"]
        ws.append(headers)
        for cell in ws[1]:
            cell.font = header_font
            cell.fill = header_fill

        for rpt in sorted(reports, key=lambda r: r.get("case_id", "")):
            mods = ", ".join(sorted(rpt.get("modalities", {}).keys()))
            warns = "; ".join(rpt.get("warnings", []))
            ws.append([
                rpt.get("case_id", ""),
                rpt.get("overall_status", ""),
                mods,
                warns,
            ])

        ws.column_dimensions["A"].width = 20
        ws.column_dimensions["B"].width = 10
        ws.column_dimensions["C"].width = 30
        ws.column_dimensions["D"].width = 60

        for row_cells in ws.iter_rows(min_row=2, max_row=ws.max_row):
            for cell in row_cells:
                cell.alignment = Alignment(wrap_text=True, vertical="top")

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        wb.save(output_path)
        logger.info("Conversion summary saved: %s", output_path)

    return summary
