"""Rebuild the SQLite catalog from the directory tree and its JSON manifests."""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

from .catalog import Catalog, case_pk
from .fsutil import iter_files, sha256_file
from .holding import REPORT_JSON
from .layout import (
    BATCH_MANIFEST,
    CASE_PIN,
    DERIVED_DIR,
    ORIGINAL_DIR,
    RUN_MANIFEST,
    parse_batch_dirname,
)
from .store import Store
from .triallog import TrialLog

logger = logging.getLogger(__name__)


@dataclass
class ReindexReport:
    trials: int = 0
    cases: int = 0
    batches: int = 0
    series: int = 0
    files: int = 0
    runs: int = 0
    log_lines: int = 0
    holding: int = 0
    cards: int = 0
    problems: list[str] = field(default_factory=list)
    leftovers: list[str] = field(default_factory=list)
    dry_run: bool = False

    def summary(self) -> str:
        tag = "[dry-run] " if self.dry_run else ""
        lines = [f"{tag}reindexed {self.trials} trials, {self.cases} cases, "
                 f"{self.batches} batches, "
                 f"{self.series} series, {self.files} files, {self.runs} derived runs, "
                 f"{self.log_lines} log lines, {self.holding} holding groups, "
                 f"{self.cards} case cards"]
        lines += [f"  leftover: {p}" for p in self.leftovers]
        lines += [f"  problem: {p}" for p in self.problems]
        return "\n".join(lines)


def _load(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        logger.warning("unreadable manifest %s: %s", path, exc)
        return None


def _trial_dirs(store: Store) -> list[Path]:
    """Collection directories, ``<root>/<site>/<collection>``, for configured collections."""
    out = []
    for rule in store.cfg.trials:
        d = store.collection_dir(rule.id)
        if d.is_dir():
            out.append(d)
    return out


def _index_batch(cat: Catalog, store: Store, trial_id: str, case_id: str, bdir: Path,
                 man: dict, rep: ReindexReport, full_hash: bool) -> str:
    pk = case_pk(trial_id, case_id)
    batch_rel = store.rel(bdir)
    bid = cat.insert_batch(pk, bdir.name, int(man.get("seq", 0)) or _seq_from_existing(cat, pk),
                           man.get("kind", "initial"), man.get("ingest_id", ""),
                           man.get("source", ""), man.get("ingested_at", ""),
                           len(man.get("files", [])),
                           sum(int(f.get("size", 0)) for f in man.get("files", [])), man)
    sids = {}
    for s in man.get("series", []):
        sids[s["dir"]] = cat.insert_series(
            bid, pk, f"{batch_rel}/{s['dir']}", s.get("series_uid", ""), s.get("study_uid", ""),
            s.get("for_uid", ""), s.get("modality", "OT"), s.get("series_number"),
            s.get("description", ""), s.get("study_date", ""), int(s.get("n_instances", 0)),
            s.get("ref_series_uid", ""), s.get("ref_sop_uid", ""), s.get("key_tags"))
        rep.series += 1
    rows = []
    listed = set()
    for f in man.get("files", []):
        rel = f"{batch_rel}/{f['path']}"
        listed.add(f["path"].lower())
        disk = store.abs(rel)
        if not disk.exists():
            rep.problems.append(f"missing on disk: {rel}")
            continue
        size = disk.stat().st_size
        if size != int(f.get("size", size)):
            rep.problems.append(f"size differs from manifest: {rel}")
        sha = f.get("sha256") or ""
        if full_hash or not sha:
            actual = sha256_file(disk)
            if sha and actual != sha:
                rep.problems.append(f"sha256 differs from manifest: {rel}")
            sha = actual
        series_dir = f.get("series_dir") or (f["path"].split("/", 1)[0] if "/" in f["path"]
                                             and f["path"].split("/", 1)[0] in sids else None)
        rows.append({"case_pk": pk, "origin": "original", "batch_id": bid,
                     "series_id": sids.get(series_dir), "kind": f.get("kind", "unknown"),
                     "rel_path": rel, "size": size, "sha256": sha,
                     "source_relpath": f.get("source_relpath"),
                     "sop_instance_uid": f.get("sop_instance_uid"),
                     "sop_class_uid": f.get("sop_class_uid"),
                     "instance_number": f.get("instance_number")})
    cat.insert_files(rows)
    rep.files += len(rows)
    for disk in iter_files(bdir):
        relp = disk.relative_to(bdir).as_posix()
        if relp != BATCH_MANIFEST and relp.lower() not in listed:
            rep.problems.append(f"orphan file not in manifest: {batch_rel}/{relp}")
    return bid


def _seq_from_existing(cat: Catalog, pk: str) -> int:
    return cat.next_batch_seq(pk)


def _index_run(cat: Catalog, store: Store, trial_id: str, case_id: str, rdir: Path, man: dict,
               rep: ReindexReport, full_hash: bool) -> None:
    pk = case_pk(trial_id, case_id)
    module, version = man.get("module", rdir.parent.name.split("@")[0]), \
        man.get("version", rdir.parent.name.split("@")[-1])
    run_id = f"{pk}/{module}@{version}/{rdir.name}"
    rel_dir = store.rel(rdir)
    cat.insert_run(run_id, pk, module, version, rdir.name, rel_dir, man.get("params", {}),
                   man.get("params_hash", ""), man.get("inputs_hash", ""),
                   man.get("inputs", []), man.get("status", "completed"),
                   man.get("started_at", ""), man.get("host", ""), man.get("user", ""),
                   man.get("iroc_qa_version", ""))
    cat.finish_run(run_id, man.get("status", "completed"), man.get("finished_at"), rel_dir, man)
    rows, roles = [], []
    for o in man.get("outputs", []):
        rel = f"{rel_dir}/{o['path']}"
        disk = store.abs(rel)
        if not disk.exists():
            rep.problems.append(f"missing on disk: {rel}")
            continue
        sha = o.get("sha256") or ""
        if full_hash or not sha:
            sha = sha256_file(disk)
        rows.append({"case_pk": pk, "origin": "derived", "derived_run_id": run_id,
                     "kind": o.get("kind", "unknown"), "rel_path": rel,
                     "size": disk.stat().st_size, "sha256": sha,
                     "metadata": {"role": o.get("role")}})
        roles.append(o.get("parents") or [])
    ids = cat.insert_files(rows)
    rep.files += len(rows)
    rep.runs += 1
    series_by_role = {}
    for inp in man.get("inputs", []):
        if inp.get("series_id"):
            series_by_role.setdefault(inp.get("role"), []).append(inp["series_id"])
    prov = []
    for fid, parents in zip(ids, roles):
        for role in parents:
            for sid in series_by_role.get(role, []):
                if cat.conn.execute("SELECT 1 FROM series WHERE id=?", (sid,)).fetchone():
                    prov.append((run_id, role, None, sid, fid))
    if prov:
        cat.insert_provenance(prov)


def reindex(store: Store, full_hash: bool = False, dry_run: bool = False) -> ReindexReport:
    rep = ReindexReport(dry_run=dry_run)
    rebuild_path = store.cfg.catalog_path.with_name(store.cfg.catalog_path.name + ".rebuild")
    if rebuild_path.exists():
        rebuild_path.unlink()
    lock = store.lock(cmd="reindex")
    lock.acquire(wait_seconds=60)
    cat = Catalog(rebuild_path, store.cfg.busy_timeout_seconds)
    try:
        cat.init_schema()
        tlog = TrialLog(store.root, cat, path_for=store.collection_dir)
        with cat.transaction():
            for t in store.cfg.trials:
                cat.upsert_trial(t.id, t.name, t.protocol_ids, t.site, t.kind)
                rep.trials += 1
                rep.log_lines += tlog.reindex(t.id)
            for tdir in _trial_dirs(store):
                trial_id = store.cfg.trial(tdir.name).id
                for cdir in sorted(p for p in tdir.iterdir() if p.is_dir()
                                   and not p.name.startswith((".", "_"))):
                    case_id = cdir.name
                    pk = cat.upsert_case(trial_id, case_id)
                    rep.cases += 1
                    odir = cdir / ORIGINAL_DIR
                    batches = []
                    if odir.is_dir():
                        for b in sorted(odir.iterdir()):
                            if b.name.startswith(".incoming-"):
                                if (b / BATCH_MANIFEST).exists():
                                    man = _load(b / BATCH_MANIFEST)
                                    target = odir / man["batch"] if man else None
                                    if man and target and not target.exists() and not dry_run:
                                        b.rename(target)
                                        logger.warning("finished interrupted batch %s", target)
                                        b = target
                                    else:
                                        rep.leftovers.append(str(b))
                                        continue
                                else:
                                    rep.leftovers.append(str(b))
                                    continue
                            if not b.is_dir() or not parse_batch_dirname(b.name):
                                continue
                            man = _load(b / BATCH_MANIFEST)
                            if man is None:
                                rep.problems.append(f"batch without {BATCH_MANIFEST}: {b}")
                                continue
                            batches.append((int(man.get("seq", 0)), b, man))
                    batches.sort(key=lambda x: (x[0], x[1].name))
                    bids = {}
                    for _, b, man in batches:
                        bids[b.name] = _index_batch(cat, store, trial_id, case_id, b, man, rep,
                                                    full_hash)
                        rep.batches += 1
                    pin = _load(cdir / CASE_PIN) if (cdir / CASE_PIN).exists() else None
                    current = None
                    pinned = False
                    pinned_name = None
                    if pin:
                        if pin.get("pinned"):
                            pinned_name = pin.get("current_batch")
                        elif pin.get("pinned_batch"):         # legacy iroc-store.case/1
                            pinned_name = pin.get("pinned_batch")
                    if pinned_name in bids:
                        current, pinned = bids[pinned_name], True
                    elif batches:
                        current = bids[batches[-1][1].name]
                    cat.set_current_batch(pk, current, pin=pinned)
                    ddir = cdir / DERIVED_DIR
                    if ddir.is_dir():
                        for mdir in sorted(p for p in ddir.iterdir() if p.is_dir()):
                            for rdir in sorted(p for p in mdir.iterdir() if p.is_dir()):
                                if rdir.name.startswith(".tmp-"):
                                    rep.leftovers.append(str(rdir))
                                    continue
                                man = _load(rdir / RUN_MANIFEST)
                                if man is None:
                                    rep.problems.append(f"run without {RUN_MANIFEST}: {rdir}")
                                    continue
                                _index_run(cat, store, trial_id, case_id, rdir, man, rep,
                                           full_hash)
            hold = store.cfg.holding
            if hold.is_dir():
                for hdir in sorted(p for p in hold.iterdir() if p.is_dir()
                                   and not p.name.startswith((".", "_"))):
                    man = _load(hdir / REPORT_JSON)
                    if not man:
                        continue
                    for g in man.get("groups", []):
                        if (hdir / g["dir"]).is_dir():
                            cat.insert_holding(hdir.name, g["group_no"], g["dir"], g["reason"],
                                               g.get("decision"))
                            rep.holding += 1
        cat.close()
        if dry_run:
            rebuild_path.unlink(missing_ok=True)
        else:
            store.catalog.close()
            os.replace(rebuild_path, store.cfg.catalog_path)
            store.catalog = Catalog(store.cfg.catalog_path, store.cfg.busy_timeout_seconds)
            store.log.catalog = store.catalog
    finally:
        try:
            cat.close()
        except Exception:
            pass
        lock.release()
    if not dry_run:
        from .cards import rebuild_all_cards

        rep.cards = rebuild_all_cards(store)
        store.refresh_overview()
    return rep
