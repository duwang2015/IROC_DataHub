#!/usr/bin/env python
"""
nii2dcm.py - Convert NIfTI (.nii.gz) back to DICOM using original headers.

After defacing or auto-segmentation, the processed NIfTI files have new pixel
data but need to be written back as DICOM with all original metadata intact
(patient ID, study/series info, acquisition parameters, private tags, etc.).

Supported modalities:
  - CT, MR, PET  (multi-slice image series)
  - RTDose        (single multi-frame file)
  - RTSTRUCT      (contour file via rt_utils)

Usage examples:
  python nii2dcm.py -n ./nifti_dir -d ./dicom_dir -o ./output
  python nii2dcm.py --single-nifti ./GBM-001_CT.nii.gz --single-modality CT \
                     -d ./dicom/GBM-001 -o ./output
  python nii2dcm.py --single-nifti ./seg.nii.gz --single-modality RTSTRUCT \
                     -d ./dicom/GBM-001 -o ./output --roi-mapping map.json
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path

import nibabel as nib
import numpy as np
import pydicom
import SimpleITK as sitk  # noqa: N813
from pydicom.uid import ExplicitVRLittleEndian, generate_uid

try:
    from rt_utils import RTStructBuilder
    HAS_RT_UTILS = True
except ImportError:
    HAS_RT_UTILS = False

# Import shared helpers from dcm2nii (same directory)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dcm2nii import (
    detect_modality,
    group_by_series,
    scan_dicom_files,
)

logger = logging.getLogger(__name__)

SUPPORTED_MODALITIES = {"CT", "MR", "PT", "RTDOSE", "RTSTRUCT"}


# ---------------------------------------------------------------------------
# NIfTI loading
# ---------------------------------------------------------------------------

def load_nifti(nifti_path):
    """Load a NIfTI file with nibabel.

    Returns (data, affine, header) where data is in nibabel (x, y, z) ordering.
    """
    nifti_path = Path(nifti_path)
    if not nifti_path.exists():
        raise FileNotFoundError(f"NIfTI file not found: {nifti_path}")
    nii = nib.load(str(nifti_path))
    data = nii.get_fdata()
    return data, nii.affine, nii.header


# ---------------------------------------------------------------------------
# DICOM series matching
# ---------------------------------------------------------------------------

def match_series_to_modality(dicom_dir, target_modality, n_slices=None):
    """Find the original DICOM series matching *target_modality*.

    For multi-slice modalities (CT, MR, PT): returns (uid, file_list)
    sorted by GDCM order or InstanceNumber.

    For single-file modalities (RTDOSE, RTSTRUCT): returns (uid, file_list)
    with one entry.

    If *n_slices* is given, prefers the series whose file count matches.
    Otherwise uses the largest series.
    """
    dicom_dir = str(dicom_dir)
    file_list = scan_dicom_files(dicom_dir)
    if not file_list:
        raise FileNotFoundError(f"No DICOM files found in {dicom_dir}")

    series_map = group_by_series(file_list)

    # Filter series by target modality
    matching = []
    for uid, files in series_map.items():
        mod = detect_modality(files)
        if mod == target_modality:
            matching.append((uid, files))

    if not matching:
        raise ValueError(
            f"No {target_modality} series found in {dicom_dir}. "
            f"Available modalities: "
            f"{sorted({detect_modality(f) for f in series_map.values()})}"
        )

    # Pick best series: prefer matching slice count, else largest
    if n_slices is not None:
        exact = [m for m in matching if len(m[1]) == n_slices]
        if exact:
            matching = exact
    matching.sort(key=lambda x: len(x[1]), reverse=True)
    uid, files = matching[0]

    if target_modality in ("RTDOSE", "RTSTRUCT"):
        return uid, files  # typically 1 file; return uid for caller

    # Use GDCM-sorted order (same as forward dcm2nii conversion)
    series_dir = os.path.dirname(files[0][0])
    reader = sitk.ImageSeriesReader()
    try:
        gdcm_names = reader.GetGDCMSeriesFileNames(series_dir, uid)
        if gdcm_names and len(gdcm_names) == len(files):
            # Build ordered list: GDCM path -> (filepath, dataset)
            path_to_entry = {os.path.normpath(fp): (fp, ds) for fp, ds in files}
            sorted_files = []
            for gp in gdcm_names:
                key = os.path.normpath(gp)
                if key in path_to_entry:
                    sorted_files.append(path_to_entry[key])
            if len(sorted_files) == len(files):
                logger.debug("  Using GDCM sort order for %s (%d files)",
                             target_modality, len(sorted_files))
                return uid, sorted_files
    except Exception:
        pass

    # Fallback: sort by InstanceNumber or IPP z
    sorted_files = sorted(
        files,
        key=lambda x: int(getattr(x[1], "InstanceNumber", 0) or 0),
    )
    return uid, sorted_files


def match_slices_to_dicom(nifti_shape, dicom_series):
    """Map NIfTI z-slices to DICOM files using sequential 1:1 mapping.

    The DICOM series must be pre-sorted in the same order as the forward
    conversion (GDCM order or InstanceNumber order).

    Parameters
    ----------
    nifti_shape : tuple (x, y, z)
    dicom_series : list of (filepath, dataset), in GDCM-sorted order.

    Returns
    -------
    list of (nifti_z_index, filepath, dataset), one per NIfTI z-slice.
    """
    n_nifti = nifti_shape[2]
    n_dicom = len(dicom_series)

    if n_nifti != n_dicom:
        raise ValueError(
            f"Slice count mismatch: NIfTI has {n_nifti} slices, "
            f"DICOM series has {n_dicom} files"
        )

    # Sequential 1:1 mapping — DICOM file i corresponds to NIfTI slice i
    result = []
    for i in range(n_nifti):
        fp, ds = dicom_series[i]
        result.append((i, fp, ds))

    return result


# ---------------------------------------------------------------------------
# UID and description helpers
# ---------------------------------------------------------------------------

def update_dicom_uids(ds, new_series_uid):
    """Generate new SOPInstanceUID; set shared SeriesInstanceUID.

    Preserves StudyInstanceUID, PatientID, and all other identifiers.
    """
    new_sop_uid = generate_uid()
    ds.SeriesInstanceUID = new_series_uid
    ds.SOPInstanceUID = new_sop_uid
    # Update file_meta if present
    if hasattr(ds, "file_meta") and ds.file_meta is not None:
        ds.file_meta.MediaStorageSOPInstanceUID = new_sop_uid


def update_series_description(ds, suffix="[defaced]"):
    """Append *suffix* to SeriesDescription. Truncate to 64 chars (VR LO).

    Also bumps SeriesNumber by +1000 to avoid collisions.
    """
    orig = getattr(ds, "SeriesDescription", "")
    new_desc = f"{orig} {suffix}".strip()
    ds.SeriesDescription = new_desc[:64]

    orig_num = int(getattr(ds, "SeriesNumber", 0) or 0)
    ds.SeriesNumber = orig_num + 1000


# ---------------------------------------------------------------------------
# Pixel encoding
# ---------------------------------------------------------------------------

def _encode_pixel_data(array_2d, ds):
    """Encode a 2D float array into DICOM PixelData bytes.

    Inspects BitsAllocated and PixelRepresentation from *ds* to select
    the correct numpy dtype and value range.
    """
    bits = int(getattr(ds, "BitsAllocated", 16))
    signed = int(getattr(ds, "PixelRepresentation", 1))  # 1=signed, 0=unsigned

    if bits == 8:
        if signed:
            dtype = np.int8
            arr = np.clip(array_2d, -128, 127).astype(dtype)
        else:
            dtype = np.uint8
            arr = np.clip(array_2d, 0, 255).astype(dtype)
    elif bits == 16:
        if signed:
            dtype = np.int16
            arr = np.clip(array_2d, -32768, 32767).astype(dtype)
        else:
            dtype = np.uint16
            arr = np.clip(array_2d, 0, 65535).astype(dtype)
    elif bits == 32:
        if signed:
            dtype = np.int32
            arr = np.clip(array_2d, -(2**31), 2**31 - 1).astype(dtype)
        else:
            dtype = np.uint32
            arr = np.clip(array_2d, 0, 2**32 - 1).astype(dtype)
    else:
        logger.warning("Unsupported BitsAllocated=%d, defaulting to int16", bits)
        arr = np.clip(array_2d, -32768, 32767).astype(np.int16)

    return arr.tobytes()


def _prepare_uncompressed(ds):
    """Ensure dataset is ready for uncompressed pixel writing.

    If original uses compressed transfer syntax, decompress first,
    then switch to ExplicitVRLittleEndian.
    """
    ts = getattr(ds.file_meta, "TransferSyntaxUID", None) if hasattr(
        ds, "file_meta"
    ) else None

    if ts and ts != ExplicitVRLittleEndian:
        try:
            ds.decompress()
        except Exception:
            pass  # may already be uncompressed despite unusual TS

    # Set uncompressed transfer syntax
    if not hasattr(ds, "file_meta") or ds.file_meta is None:
        ds.file_meta = pydicom.dataset.FileMetaDataset()
    ds.file_meta.TransferSyntaxUID = ExplicitVRLittleEndian


# ---------------------------------------------------------------------------
# Multi-slice writer (CT / MR / PET)
# ---------------------------------------------------------------------------

def _write_image_series(nifti_path, dicom_dir, output_dir, case_id,
                        target_modality, description_suffix="[defaced]"):
    """Core engine: write a multi-slice DICOM series from NIfTI.

    Returns dict with: modality, n_slices, output_path, status.
    """
    logger.info("  Converting %s: %s", target_modality, nifti_path)

    # Load NIfTI
    data, affine, header = load_nifti(nifti_path)

    # Find original DICOM series (pass slice count to disambiguate)
    _uid, dicom_series = match_series_to_modality(
        dicom_dir, target_modality, n_slices=data.shape[2]
    )

    # Match slices
    slice_map = match_slices_to_dicom(data.shape, dicom_series)

    # Create output directory
    mod_name = {"CT": "CT", "MR": "MR", "PT": "PT"}[target_modality]
    out_dir = Path(output_dir) / case_id / mod_name
    out_dir.mkdir(parents=True, exist_ok=True)

    # Generate shared series UID
    new_series_uid = generate_uid()

    n_written = 0
    for nz_idx, dcm_path, _ in slice_map:
        # Read original DICOM (full, with pixel data)
        ds = pydicom.dcmread(dcm_path)

        # Extract NIfTI slice: nibabel (x,y,z) -> DICOM (rows, cols) = [:,:,z].T
        nifti_slice = data[:, :, nz_idx].T  # (rows, cols)

        # Reverse RescaleSlope/Intercept
        slope = float(getattr(ds, "RescaleSlope", 1.0))
        intercept = float(getattr(ds, "RescaleIntercept", 0.0))
        if slope == 0:
            slope = 1.0
        stored = np.round((nifti_slice - intercept) / slope)

        # Prepare for uncompressed writing
        _prepare_uncompressed(ds)

        # Encode and replace PixelData
        ds.PixelData = _encode_pixel_data(stored, ds)

        # Validate shape matches
        expected_rows = int(getattr(ds, "Rows", 0))
        expected_cols = int(getattr(ds, "Columns", 0))
        actual_rows, actual_cols = nifti_slice.shape
        if expected_rows != actual_rows or expected_cols != actual_cols:
            logger.warning(
                "  Shape mismatch slice %d: DICOM (%d,%d) vs NIfTI (%d,%d)",
                nz_idx, expected_rows, expected_cols, actual_rows, actual_cols,
            )

        # Update UIDs and description
        update_dicom_uids(ds, new_series_uid)
        update_series_description(ds, description_suffix)

        # Save
        out_path = out_dir / f"slice_{nz_idx + 1:04d}.dcm"
        ds.save_as(str(out_path))
        n_written += 1

    logger.info("  Wrote %d DICOM files to %s", n_written, out_dir)
    return {
        "modality": target_modality,
        "n_slices": n_written,
        "output_path": str(out_dir),
        "status": "OK",
    }


def write_ct_series(nifti_path, dicom_dir, output_dir, case_id,
                    suffix="[defaced]"):
    """Convert CT NIfTI back to DICOM series."""
    return _write_image_series(
        nifti_path, dicom_dir, output_dir, case_id, "CT", suffix
    )


def write_mr_series(nifti_path, dicom_dir, output_dir, case_id,
                    suffix="[defaced]"):
    """Convert MR NIfTI back to DICOM series."""
    return _write_image_series(
        nifti_path, dicom_dir, output_dir, case_id, "MR", suffix
    )


def write_pet_series(nifti_path, dicom_dir, output_dir, case_id,
                     suffix="[defaced]"):
    """Convert PET NIfTI back to DICOM series."""
    return _write_image_series(
        nifti_path, dicom_dir, output_dir, case_id, "PT", suffix
    )


# ---------------------------------------------------------------------------
# RTDose writer
# ---------------------------------------------------------------------------

def write_rtdose(nifti_path, dicom_dir, output_dir, case_id,
                 suffix="[defaced]"):
    """Convert RTDose NIfTI (cGy) back to single DICOM file.

    Reverses the dcm2nii.py conversion: cGy -> Gy -> uint32 with
    DoseGridScaling.
    """
    logger.info("  Converting RTDose: %s", nifti_path)

    # Load NIfTI dose array
    data, affine, header = load_nifti(nifti_path)

    # Find original RTDose DICOM
    _uid, dicom_files = match_series_to_modality(dicom_dir, "RTDOSE")
    ds = pydicom.dcmread(dicom_files[0][0])

    # Convert cGy -> Gy
    dose_gy = data / 100.0

    # Reorder: nibabel (x, y, z) -> DICOM multi-frame (frames, rows, cols)
    # For RTDose: frames = z-slices, rows = y, cols = x
    dose_dcm = np.transpose(dose_gy, (2, 1, 0))  # (z, y, x) = (frames, rows, cols)

    # Check shape match with original DICOM
    orig_rows = int(getattr(ds, "Rows", 0))
    orig_cols = int(getattr(ds, "Columns", 0))
    orig_frames = int(getattr(ds, "NumberOfFrames", 1))
    new_frames, new_rows, new_cols = dose_dcm.shape

    if (new_frames != orig_frames or new_rows != orig_rows
            or new_cols != orig_cols):
        logger.warning(
            "  RTDose grid mismatch: original (%d,%d,%d) vs NIfTI (%d,%d,%d). "
            "NIfTI may have been resampled to CT grid. Updating spatial tags.",
            orig_frames, orig_rows, orig_cols,
            new_frames, new_rows, new_cols,
        )
        _update_rtdose_spatial_tags(ds, affine, data.shape, dose_dcm.shape)

    # Clip negative values (artifacts from BSpline resampling)
    n_neg = int((dose_dcm < 0).sum())
    if n_neg > 0:
        logger.info("  Clipping %d negative dose voxels to 0", n_neg)
        dose_dcm = np.clip(dose_dcm, 0, None)

    # Compute DoseGridScaling for uint32 packing
    max_gy = float(dose_dcm.max())
    if max_gy > 0:
        dose_grid_scaling = max_gy / (2**32 - 2)
    else:
        dose_grid_scaling = 1.0

    stored = np.round(dose_dcm / dose_grid_scaling).astype(np.uint32)

    # Update DICOM dataset
    ds.PixelData = stored.tobytes()
    ds.DoseGridScaling = dose_grid_scaling
    ds.BitsAllocated = 32
    ds.BitsStored = 32
    ds.HighBit = 31
    ds.PixelRepresentation = 0
    ds.Rows = new_rows
    ds.Columns = new_cols
    ds.NumberOfFrames = str(new_frames)
    ds.SamplesPerPixel = 1

    # Prepare transfer syntax
    _prepare_uncompressed(ds)

    # Update UIDs and description
    new_series_uid = generate_uid()
    update_dicom_uids(ds, new_series_uid)
    update_series_description(ds, suffix)

    # Save
    out_dir = Path(output_dir) / case_id / "RTDose"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "dose.dcm"
    ds.save_as(str(out_path))

    logger.info("  Saved RTDose: %s (DoseGridScaling=%.2e)", out_path,
                dose_grid_scaling)
    return {
        "modality": "RTDOSE",
        "n_slices": 1,
        "output_path": str(out_path),
        "status": "OK",
        "dose_grid_scaling": dose_grid_scaling,
    }


def _update_rtdose_spatial_tags(ds, nifti_affine, nifti_shape, dcm_shape):
    """Update DICOM spatial tags when NIfTI grid differs from original.

    Called when RTDose was resampled to CT grid by dcm2nii.py.
    """
    n_frames, n_rows, n_cols = dcm_shape

    # Pixel spacing from NIfTI affine
    sx = float(np.sqrt(np.sum(nifti_affine[:3, 0] ** 2)))
    sy = float(np.sqrt(np.sum(nifti_affine[:3, 1] ** 2)))
    sz = float(np.sqrt(np.sum(nifti_affine[:3, 2] ** 2)))

    ds.Rows = n_rows
    ds.Columns = n_cols
    ds.NumberOfFrames = str(n_frames)
    ds.PixelSpacing = [f"{sy:.6f}", f"{sx:.6f}"]
    ds.SliceThickness = f"{sz:.6f}"

    # ImagePositionPatient from NIfTI origin
    origin = nifti_affine[:3, 3]
    ds.ImagePositionPatient = [f"{origin[0]:.6f}", f"{origin[1]:.6f}",
                               f"{origin[2]:.6f}"]

    # GridFrameOffsetVector
    offsets = [float(i * sz) for i in range(n_frames)]
    ds.GridFrameOffsetVector = offsets


# ---------------------------------------------------------------------------
# RTSTRUCT writer
# ---------------------------------------------------------------------------

def write_rtstruct(nifti_label_path, dicom_ct_dir, output_dir, case_id,
                   roi_mapping_path=None, original_rtstruct_dir=None,
                   suffix="[auto-seg]"):
    """Convert NIfTI label map back to RTSTRUCT DICOM.

    Requires the rt_utils library and a CT DICOM series as reference grid.
    """
    if not HAS_RT_UTILS:
        logger.error(
            "rt_utils not installed — cannot convert RTSTRUCT. "
            "Install with: pip install rt_utils"
        )
        return {"modality": "RTSTRUCT", "status": "SKIP", "reason": "no rt_utils"}

    logger.info("  Converting RTSTRUCT: %s", nifti_label_path)

    # Load label map
    data, affine, header = load_nifti(nifti_label_path)
    labels = np.round(data).astype(np.int32)

    # Load ROI mapping
    roi_mapping = {}
    if roi_mapping_path and Path(roi_mapping_path).exists():
        with open(roi_mapping_path, encoding="utf-8") as f:
            raw = json.load(f)
        roi_mapping = {int(k): v for k, v in raw.items()}
    else:
        # Generate default names from labels
        unique_labels = sorted(set(labels.flat) - {0})
        roi_mapping = {lb: f"ROI_{lb}" for lb in unique_labels}
        if not roi_mapping_path:
            logger.info("  No ROI mapping provided, using default names")
        else:
            logger.warning("  ROI mapping not found: %s", roi_mapping_path)

    if not roi_mapping:
        logger.warning("  No ROIs found in label map")
        return {"modality": "RTSTRUCT", "status": "SKIP", "reason": "empty labels"}

    # Find CT DICOM directory for rt_utils
    ct_dir = str(dicom_ct_dir)

    # Create RTSTRUCT
    try:
        if original_rtstruct_dir:
            # Find original RTSTRUCT file to preserve UIDs
            _uid, rtstruct_files = match_series_to_modality(
                original_rtstruct_dir, "RTSTRUCT"
            )
            rts = RTStructBuilder.create_from(
                dicom_series_path=ct_dir,
                rt_struct_path=rtstruct_files[0][0],
            )
        else:
            rts = RTStructBuilder.create_new(dicom_series_path=ct_dir)
    except Exception as exc:
        logger.error("  Failed to create RTStructBuilder: %s", exc)
        return {"modality": "RTSTRUCT", "status": "FAIL", "reason": str(exc)}

    # Add each ROI
    n_added = 0
    for label_int, roi_name in sorted(roi_mapping.items()):
        mask_3d = (labels == label_int)
        if not mask_3d.any():
            logger.warning("  Label %d (%s) has no voxels — skipping",
                           label_int, roi_name)
            continue
        # Transpose: nibabel (x, y, z) -> rt_utils (rows, cols, slices)
        mask_rtutils = mask_3d.transpose(1, 2, 0)
        try:
            rts.add_roi(mask=mask_rtutils, name=roi_name)
            n_added += 1
        except Exception as exc:
            logger.warning("  Failed to add ROI '%s': %s", roi_name, exc)

    # Save
    out_dir = Path(output_dir) / case_id / "RTSTRUCT"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "rtstruct.dcm"
    rts.save(str(out_path))

    logger.info("  Saved RTSTRUCT with %d ROIs: %s", n_added, out_path)
    return {
        "modality": "RTSTRUCT",
        "n_rois": n_added,
        "output_path": str(out_path),
        "status": "OK",
    }


# ---------------------------------------------------------------------------
# NIfTI filename -> modality detection
# ---------------------------------------------------------------------------

def detect_nifti_modality(filename):
    """Detect imaging modality from NIfTI filename.

    Returns one of: 'CT', 'MR', 'PT', 'RTDOSE', 'RTSTRUCT', or None.
    """
    name = filename.upper()

    # Order matters — check specific patterns before generic ones
    if "RTSTRUCT" in name:
        return "RTSTRUCT"
    if "RTDOSE" in name or "DOSEMAP" in name or "_DOSE" in name:
        return "RTDOSE"
    if "PETCT" in name or "_PET" in name or "SUVBW" in name:
        return "PT"
    if "_MRI" in name or "_T1" in name or "_T2" in name or "_FLAIR" in name:
        return "MR"
    if "_CT" in name or "DEFACED" in name:
        return "CT"

    return None


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_conversion(nifti_path, output_dcm_path, modality):
    """Validate round-trip conversion by reading back written DICOM.

    Returns dict with: passed, max_diff, mean_diff, detail.
    """
    data_nifti, affine, _ = load_nifti(nifti_path)

    if modality in ("CT", "MR", "PT"):
        return _validate_image_series(data_nifti, output_dcm_path, modality)
    elif modality == "RTDOSE":
        return _validate_rtdose(data_nifti, output_dcm_path)
    elif modality == "RTSTRUCT":
        return {"passed": True, "detail": "RTSTRUCT validation requires rt_utils"}
    else:
        return {"passed": False, "detail": f"Unknown modality: {modality}"}


def _validate_image_series(data_nifti, dcm_dir, modality):
    """Read back multi-slice DICOM and compare to NIfTI."""
    dcm_dir = str(dcm_dir)
    try:
        reader = sitk.ImageSeriesReader()
        series_ids = reader.GetGDCMSeriesIDs(dcm_dir)
        if not series_ids:
            return {"passed": False, "detail": "No DICOM series found in output"}

        file_names = reader.GetGDCMSeriesFileNames(dcm_dir, series_ids[0])
        reader.SetFileNames(file_names)
        image = reader.Execute()
        arr_sitk = sitk.GetArrayFromImage(image)  # (z, y, x)

        # Convert to nibabel ordering (x, y, z) for comparison
        arr_nib = np.transpose(arr_sitk, (2, 1, 0)).astype(np.float64)
        data_ref = data_nifti.astype(np.float64)

        if arr_nib.shape != data_ref.shape:
            return {
                "passed": False,
                "detail": f"Shape mismatch: DICOM {arr_nib.shape} vs "
                          f"NIfTI {data_ref.shape}",
            }

        diff = np.abs(arr_nib - data_ref)
        max_diff = float(diff.max())
        mean_diff = float(diff.mean())

        # Tolerance depends on modality
        tol = {"CT": 1.5, "MR": 1.5, "PT": 1.5}.get(modality, 2.0)
        passed = max_diff <= tol

        return {
            "passed": passed,
            "max_diff": max_diff,
            "mean_diff": mean_diff,
            "n_slices": arr_nib.shape[2],
            "detail": f"max_diff={max_diff:.4f}, mean_diff={mean_diff:.4f}",
        }
    except Exception as exc:
        return {"passed": False, "detail": f"Validation error: {exc}"}


def _validate_rtdose(data_nifti, dcm_path):
    """Read back RTDose DICOM and compare to NIfTI (in cGy).

    Compares non-negative voxels only, since DICOM uint32 cannot store
    negative dose values (BSpline resampling artifacts are clipped to 0).
    """
    try:
        if os.path.isdir(dcm_path):
            dcm_files = list(Path(dcm_path).glob("*.dcm"))
            if not dcm_files:
                return {"passed": False, "detail": "No .dcm files in RTDose dir"}
            dcm_path = str(dcm_files[0])

        ds = pydicom.dcmread(dcm_path)
        scaling = float(getattr(ds, "DoseGridScaling", 1.0))
        arr = ds.pixel_array.astype(np.float64) * scaling  # Gy
        arr_cgy = arr * 100.0  # cGy

        # Reorder: DICOM (frames, rows, cols) -> nibabel (x, y, z)
        arr_nib = np.transpose(arr_cgy, (2, 1, 0))
        data_ref = data_nifti.astype(np.float64)

        if arr_nib.shape != data_ref.shape:
            return {
                "passed": False,
                "detail": f"Shape mismatch: DICOM {arr_nib.shape} vs "
                          f"NIfTI {data_ref.shape}",
            }

        # Compare only non-negative voxels (negative values clipped to 0)
        pos_mask = data_ref >= 0
        diff = np.abs(arr_nib[pos_mask] - data_ref[pos_mask])
        max_diff = float(diff.max())
        mean_diff = float(diff.mean())
        n_clipped = int((~pos_mask).sum())
        passed = max_diff <= 0.01  # 0.01 cGy tolerance

        detail = f"max_diff={max_diff:.6f} cGy, mean_diff={mean_diff:.6f} cGy"
        if n_clipped > 0:
            detail += f", {n_clipped} neg voxels clipped"

        return {
            "passed": passed,
            "max_diff_cgy": max_diff,
            "mean_diff_cgy": mean_diff,
            "n_clipped": n_clipped,
            "detail": detail,
        }
    except Exception as exc:
        return {"passed": False, "detail": f"Validation error: {exc}"}


# ---------------------------------------------------------------------------
# Header validation
# ---------------------------------------------------------------------------

def validate_headers(dicom_dir_original, dicom_dir_output, modality):
    """Verify that key DICOM headers are preserved in the output.

    Checks: PatientID, StudyInstanceUID match original.
    Checks: SeriesInstanceUID differs (new series).
    Checks: SeriesDescription contains suffix.
    """
    try:
        # Read one original and one output DICOM
        orig_files = scan_dicom_files(str(dicom_dir_original))
        if not orig_files:
            return {"passed": False, "detail": "No original DICOM files"}

        # Filter to target modality
        orig_series = group_by_series(orig_files)
        orig_ds = None
        for uid, files in orig_series.items():
            if detect_modality(files) == modality:
                orig_ds = files[0][1]
                break
        if orig_ds is None:
            return {"passed": False,
                    "detail": f"No {modality} in original DICOM"}

        # Read output
        out_dir = str(dicom_dir_output)
        out_dcm_files = list(Path(out_dir).glob("**/*.dcm"))
        if not out_dcm_files:
            return {"passed": False, "detail": "No output DICOM files"}

        out_ds = pydicom.dcmread(str(out_dcm_files[0]),
                                 stop_before_pixels=True)

        checks = []
        # PatientID
        orig_pid = getattr(orig_ds, "PatientID", "")
        out_pid = getattr(out_ds, "PatientID", "")
        checks.append(("PatientID", orig_pid == out_pid, orig_pid, out_pid))

        # StudyInstanceUID
        orig_study = getattr(orig_ds, "StudyInstanceUID", "")
        out_study = getattr(out_ds, "StudyInstanceUID", "")
        checks.append(("StudyInstanceUID", orig_study == out_study,
                        orig_study[:20], out_study[:20]))

        # SeriesInstanceUID should differ
        orig_ser = getattr(orig_ds, "SeriesInstanceUID", "")
        out_ser = getattr(out_ds, "SeriesInstanceUID", "")
        checks.append(("SeriesInstanceUID(new)", orig_ser != out_ser,
                        orig_ser[:20], out_ser[:20]))

        all_passed = all(c[1] for c in checks)
        detail_parts = [
            f"{name}: {'OK' if ok else 'FAIL'}" for name, ok, _, _ in checks
        ]
        return {
            "passed": all_passed,
            "detail": ", ".join(detail_parts),
            "patient_id": out_pid,
        }
    except Exception as exc:
        return {"passed": False, "detail": f"Header validation error: {exc}"}


# ---------------------------------------------------------------------------
# Per-case orchestrator
# ---------------------------------------------------------------------------

def convert_case(case_id, nifti_dir, dicom_dir, output_dir,
                 modalities=None, suffix="[defaced]", validate=True,
                 roi_mapping_path=None):
    """Convert all NIfTI files for one case back to DICOM.

    Auto-detects NIfTI files by naming convention and converts each.
    Returns a report dict.
    """
    nifti_dir = Path(nifti_dir)
    if not nifti_dir.exists():
        raise FileNotFoundError(f"NIfTI directory not found: {nifti_dir}")

    logger.info("Processing case: %s", case_id)

    # Discover NIfTI files
    nifti_files = sorted(nifti_dir.glob("*.nii.gz")) + sorted(
        nifti_dir.glob("*.nii")
    )
    if not nifti_files:
        logger.warning("  No NIfTI files found in %s", nifti_dir)
        return {"case_id": case_id, "results": [], "status": "SKIP"}

    results = []
    for nf in nifti_files:
        mod = detect_nifti_modality(nf.name)
        if mod is None:
            logger.debug("  Skipping unrecognized file: %s", nf.name)
            continue
        if modalities and mod not in modalities:
            continue

        try:
            if mod in ("CT", "MR", "PT"):
                res = _write_image_series(
                    str(nf), dicom_dir, output_dir, case_id, mod, suffix
                )
            elif mod == "RTDOSE":
                res = write_rtdose(
                    str(nf), dicom_dir, output_dir, case_id, suffix
                )
            elif mod == "RTSTRUCT":
                # Need CT DICOM dir for RTSTRUCT
                res = write_rtstruct(
                    str(nf), dicom_dir, output_dir, case_id,
                    roi_mapping_path=roi_mapping_path, suffix=suffix,
                )
            else:
                continue

            # Validate if requested
            if validate and res.get("status") == "OK":
                out_path = res.get("output_path", "")
                val = validate_conversion(str(nf), out_path, mod)
                res["validation"] = val

            results.append(res)
        except Exception as exc:
            logger.error("  Failed to convert %s (%s): %s", nf.name, mod, exc)
            results.append({
                "modality": mod,
                "status": "FAIL",
                "error": str(exc),
                "file": nf.name,
            })

    logger.info("  Case %s complete: %d conversions\n", case_id, len(results))
    return {"case_id": case_id, "results": results}


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Convert NIfTI files back to DICOM with original headers"
    )
    parser.add_argument("-n", "--nifti-dir", default=None,
                        help="Directory with NIfTI files to convert")
    parser.add_argument("-d", "--dicom-dir", required=True,
                        help="Directory with original DICOM files (for headers)")
    parser.add_argument("-o", "--output-dir", required=True,
                        help="Output directory for DICOM files")
    parser.add_argument("--case-id", default=None,
                        help="Case ID (auto-detected from dir name if omitted)")
    parser.add_argument("--modalities", nargs="+", default=None,
                        choices=["CT", "MR", "PT", "RTDOSE", "RTSTRUCT"],
                        help="Convert only these modalities")
    parser.add_argument("--suffix", default="[defaced]",
                        help="Suffix for SeriesDescription (default: [defaced])")
    parser.add_argument("--no-validate", action="store_true",
                        help="Skip round-trip validation")
    parser.add_argument("--single-nifti", default=None,
                        help="Convert a single NIfTI file")
    parser.add_argument("--single-modality", default=None,
                        choices=["CT", "MR", "PT", "RTDOSE", "RTSTRUCT"],
                        help="Modality of --single-nifti file")
    parser.add_argument("--roi-mapping", default=None,
                        help="Path to roi_mapping.json (for RTSTRUCT)")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Enable verbose/debug logging")
    args = parser.parse_args()

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    dicom_dir = os.path.abspath(args.dicom_dir)
    output_dir = os.path.abspath(args.output_dir)

    if not os.path.isdir(dicom_dir):
        logger.error("DICOM directory does not exist: %s", dicom_dir)
        sys.exit(1)

    os.makedirs(output_dir, exist_ok=True)

    # Single-file mode
    if args.single_nifti:
        nifti_path = os.path.abspath(args.single_nifti)
        if not os.path.isfile(nifti_path):
            logger.error("NIfTI file not found: %s", nifti_path)
            sys.exit(1)

        modality = args.single_modality
        if modality is None:
            modality = detect_nifti_modality(os.path.basename(nifti_path))
            if modality is None:
                logger.error("Cannot auto-detect modality. Use --single-modality.")
                sys.exit(1)

        case_id = args.case_id or os.path.basename(
            os.path.normpath(dicom_dir)
        )

        logger.info("Single-file mode: %s -> %s", nifti_path, modality)
        logger.info("Case: %s, DICOM ref: %s", case_id, dicom_dir)

        try:
            if modality in ("CT", "MR", "PT"):
                res = _write_image_series(
                    nifti_path, dicom_dir, output_dir, case_id,
                    modality, args.suffix,
                )
            elif modality == "RTDOSE":
                res = write_rtdose(
                    nifti_path, dicom_dir, output_dir, case_id, args.suffix,
                )
            elif modality == "RTSTRUCT":
                res = write_rtstruct(
                    nifti_path, dicom_dir, output_dir, case_id,
                    roi_mapping_path=args.roi_mapping, suffix=args.suffix,
                )
            else:
                logger.error("Unsupported modality: %s", modality)
                sys.exit(1)

            if not args.no_validate and res.get("status") == "OK":
                val = validate_conversion(nifti_path,
                                          res.get("output_path", ""),
                                          modality)
                logger.info("Validation: %s", val)

            logger.info("Result: %s", res)
        except Exception as exc:
            logger.error("Conversion failed: %s", exc, exc_info=True)
            sys.exit(1)

        logger.info("Done.")
        return

    # Auto-detect mode
    nifti_dir = args.nifti_dir
    if nifti_dir is None:
        logger.error("Either --nifti-dir or --single-nifti is required")
        sys.exit(1)

    nifti_dir = os.path.abspath(nifti_dir)
    if not os.path.isdir(nifti_dir):
        logger.error("NIfTI directory not found: %s", nifti_dir)
        sys.exit(1)

    case_id = args.case_id or os.path.basename(os.path.normpath(nifti_dir))

    logger.info("Input NIfTI: %s", nifti_dir)
    logger.info("DICOM ref:   %s", dicom_dir)
    logger.info("Output:      %s", output_dir)

    report = convert_case(
        case_id, nifti_dir, dicom_dir, output_dir,
        modalities=args.modalities, suffix=args.suffix,
        validate=not args.no_validate, roi_mapping_path=args.roi_mapping,
    )

    logger.info("Conversion complete. Results: %s", report)
    logger.info("Done.")


if __name__ == "__main__":
    main()
