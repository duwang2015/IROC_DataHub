"""Process RTOG VV (Verification & Validation) spreadsheets.

Reads Excel VV forms, extracts QA scores from columns C–I, counts
unacceptable scores (value == 3), and computes per-trial statistics.

Ported from code_reports2bprocessedV5.m (Yutao Gong 2015, Huaizhi Geng 2018).
"""

from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

# VV spreadsheet column mapping (0-indexed: C=2, D=3, ..., I=8)
VV_COLUMNS = {
    "Digital_Data_Received": 2,      # Column C
    "Digital_Data_Integrity_QA": 3,  # Column D
    "PI_Reviewed": 4,                # Column E
    "TV_Score": 5,                   # Column F
    "OAR_Score": 6,                  # Column G
    "TV_DVA_Score": 7,               # Column H
    "OAR_DVA_Score": 8,              # Column I
}

INVALID_MARKER = 999


def _read_vv_sheet(file_path: Path) -> np.ndarray:
    """Read a VV Excel file and extract score columns as a numeric array.

    Rows with empty/NaN first column (column A) are skipped.
    Non-numeric and NaN values are replaced with 999 (invalid marker).
    """
    df = pd.read_excel(file_path, header=0)

    # Pad to at least 10 columns to avoid index errors
    while df.shape[1] < 10:
        df[f"_pad{df.shape[1]}"] = np.nan

    rows = []
    empty_streak = 0

    for idx in range(len(df)):
        if empty_streak > 20:
            break

        first_col = df.iloc[idx, 0]
        if pd.isna(first_col):
            empty_streak += 1
            continue
        empty_streak = 0

        row_values = []
        for col_idx in VV_COLUMNS.values():
            val = df.iloc[idx, col_idx] if col_idx < df.shape[1] else np.nan
            if pd.isna(val) or not isinstance(val, (int, float)):
                val = INVALID_MARKER
            row_values.append(val)
        rows.append(row_values)

    if not rows:
        return np.empty((0, len(VV_COLUMNS)))
    return np.array(rows, dtype=float)


def process_vv_sheets(
    input_dir: str | Path,
    output_path: str | Path,
) -> pd.DataFrame:
    """Process all VV Excel files in *input_dir* and write summary.

    For each file (trial), computes:
    - Count of cases with score == 2 in Digital Data columns
    - Total reviewed cases (PI_Reviewed == 2)
    - Unacceptable count and rate for TV, OAR, TV_DVA, OAR_DVA scores

    Parameters
    ----------
    input_dir : Path
        Directory containing VV spreadsheet Excel files.
    output_path : Path
        Output Excel file for summary.

    Returns
    -------
    DataFrame
        Summary with one row per trial.
    """
    input_dir = Path(input_dir)
    output_path = Path(output_path)

    results = []

    for xls in sorted(input_dir.glob("*.xls*")):
        trial_name = xls.stem.split()[0] if " " in xls.stem else xls.stem

        try:
            data = _read_vv_sheet(xls)
        except Exception as exc:
            logger.warning("Failed to read %s: %s", xls.name, exc)
            continue

        if data.size == 0:
            logger.warning("No data rows in %s", xls.name)
            continue

        # Column indices within the extracted array
        dd_received = int(np.sum(data[:, 0] == 2))   # C == 2
        dd_qa = int(np.sum(data[:, 1] == 2))          # D == 2
        total_reviewed = int(np.sum(data[:, 2] == 2))  # E == 2

        tv_unacc = int(np.sum(data[:, 3] == 3))       # F == 3
        oar_unacc = int(np.sum(data[:, 4] == 3))      # G == 3
        tv_dva_unacc = int(np.sum(data[:, 5] == 3))   # H == 3
        oar_dva_unacc = int(np.sum(data[:, 6] == 3))  # I == 3

        total = total_reviewed if total_reviewed > 0 else 1

        results.append({
            "Trial": trial_name,
            "DD_Received": dd_received,
            "DD_QA": dd_qa,
            "PI_Reviewed": total_reviewed,
            "TV_Unacceptable": tv_unacc,
            "TV_Unacc_Rate": tv_unacc / total,
            "OAR_Unacceptable": oar_unacc,
            "OAR_Unacc_Rate": oar_unacc / total,
            "TV_DVA_Unacceptable": tv_dva_unacc,
            "TV_DVA_Unacc_Rate": tv_dva_unacc / total,
            "OAR_DVA_Unacceptable": oar_dva_unacc,
            "OAR_DVA_Unacc_Rate": oar_dva_unacc / total,
        })

    summary = pd.DataFrame(results)
    summary.to_excel(output_path, index=False)
    logger.info("Processed %d trials → %s", len(summary), output_path)
    return summary
