"""Dose plan scoring — goal/variation/not-met classification.

Evaluates DVH metrics against protocol constraints and classifies each
as Goal (acceptable), Variation (borderline), or Not Met (unacceptable).

Scoring logic ported from DPS_tool.m (MATLAB, Yutao Gong 2015).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ScoreLevel(Enum):
    """Plan scoring classification."""

    GOAL = "Goal"
    VARIATION = "Variation"
    NOT_MET = "Not Met"
    NA = "N/A"


@dataclass
class Constraint:
    """A single dose-volume constraint.

    Parameters
    ----------
    name : str
        Human-readable label (e.g. ``"PTV D95%[Gy]"``).
    goal : float
        Target value for "Goal" classification.
    variation : float or None
        Threshold for "Variation" (between goal and not-met).
        If None, only goal/not-met are used.
    comparison : str
        ``">"`` (value should exceed goal) or ``"<"`` (value should be below goal).
    """

    name: str
    goal: float
    variation: float | None = None
    comparison: str = "<"


def score_metric(value: float, constraint: Constraint) -> ScoreLevel:
    """Classify a metric value against a constraint.

    Returns
    -------
    ScoreLevel
        GOAL if value meets the goal, VARIATION if between goal and
        variation threshold, NOT_MET otherwise.
    """
    if constraint.comparison == "<":
        if value <= constraint.goal:
            return ScoreLevel.GOAL
        if constraint.variation is not None and value <= constraint.variation:
            return ScoreLevel.VARIATION
        return ScoreLevel.NOT_MET
    else:  # ">"
        if value >= constraint.goal:
            return ScoreLevel.GOAL
        if constraint.variation is not None and value >= constraint.variation:
            return ScoreLevel.VARIATION
        return ScoreLevel.NOT_MET


def score_plan(
    metrics: dict[str, float],
    constraints: list[Constraint],
) -> dict[str, ScoreLevel]:
    """Score all metrics against their constraints.

    Parameters
    ----------
    metrics : dict
        Metric name → computed value (e.g. ``{"PTV D95%[Gy]": 59.2}``).
    constraints : list of Constraint
        Protocol constraints to evaluate against.

    Returns
    -------
    dict
        Constraint name → ScoreLevel.
    """
    results = {}
    for c in constraints:
        if c.name in metrics:
            results[c.name] = score_metric(metrics[c.name], c)
        else:
            results[c.name] = ScoreLevel.NA
    return results
