"""Convert RapidPlan HTML reports to Excel.

Reads HTML tables produced by Eclipse RapidPlan and writes each to an
Excel file using ``pandas.read_html``.

Ported from KBP/BN001/Revised/Code/Py/htmlToexcel.py.
"""

from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)


def html_to_excel(
    input_dir: str | Path,
    output_dir: str | Path,
) -> list[Path]:
    """Convert all ``.html`` files in *input_dir* to Excel in *output_dir*.

    Parameters
    ----------
    input_dir : Path
        Directory containing HTML files.
    output_dir : Path
        Directory for output ``.xlsx`` files.

    Returns
    -------
    list of Path
        Paths to the created Excel files.
    """
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    created: list[Path] = []
    for html_file in sorted(input_dir.glob("*.html")):
        try:
            tables = pd.read_html(html_file)
            if not tables:
                logger.warning("No tables found in %s", html_file.name)
                continue
            out_path = output_dir / f"{html_file.name}.xlsx"
            tables[0].to_excel(out_path, header=None, index=None)
            created.append(out_path)
        except Exception as exc:
            logger.warning("Failed to convert %s: %s", html_file.name, exc)

    logger.info("Converted %d HTML files → %s", len(created), output_dir)
    return created
