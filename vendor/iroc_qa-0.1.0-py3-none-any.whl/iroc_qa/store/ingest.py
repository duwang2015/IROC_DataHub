"""Inbox ingest: scan a drop, classify by DICOM header, file into batches or holding."""

from __future__ import annotations

import json
import logging
import secrets
import socket
import tempfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .. import __version__ as _tool_version
from .catalog import case_pk, utcnow
from .classify import (
    NO_DICOM_CONTEXT,
    READ_ERROR,
    UID_CONFLICT,
    Decision,
    classify_group,
    inherit_for_other,
)
from .fsutil import CopyError, copy_verified, is_settled, remove_tree, sha256_file
from .holding import HeldItem, cleanup_if_empty, discard_group, group_dirname, write_holding
from .layout import (
    ARCHIVES_DIR,
    BATCH_MANIFEST,
    fit_series_dirname,
    instance_filename,
    parse_batch_dirname,
    uid8,
    unique_filename,
    unique_name,
)
from .lock import LockHeldError, _username
from .scanner import OtherFile, ScanResult, SeriesGroup, scan_tree
from .sniff import platform_kind, subdir_for_kind
from .store import Store
from .summary import report_to_dict, write_summary

logger = logging.getLogger(__name__)
BATCH_SCHEMA = "iroc-store.batch/1"


def new_ingest_id(now: datetime | None = None) -> str:
    now = now or datetime.now()
    return f"{now:%Y%m%d-%H%M%S}-{secrets.token_hex(2)}"


@dataclass
class PendingBatch:
    trial_id: str
    case_id: str
    groups: list[tuple[SeriesGroup, Decision]] = field(default_factory=list)
    others: list[tuple[OtherFile, Decision]] = field(default_factory=list)
    skipped: list[dict] = field(default_factory=list)

    @property
    def pk(self) -> str:
        return case_pk(self.trial_id, self.case_id)

    @property
    def n_files(self) -> int:
        return sum(len(g.headers) for g, _ in self.groups) + len(self.others)


@dataclass
class DropReport:
    drop: Path
    ingest_id: str
    dry_run: bool = False
    skipped_unsettled: bool = False
    batches: list[dict] = field(default_factory=list)
    held: list[dict] = field(default_factory=list)
    duplicates: int = 0
    failures: list[str] = field(default_factory=list)
    removed_source: bool = False
    n_files_scanned: int = 0

    def summary(self) -> str:
        if self.skipped_unsettled:
            return f"{self.drop.name}: skipped (still changing)"
        tag = "[dry-run] " if self.dry_run else ""
        parts = [f"{tag}{self.drop.name}: {self.n_files_scanned} files scanned, "
                 f"{len(self.batches)} batch(es), {len(self.held)} holding group(s), "
                 f"{self.duplicates} duplicate(s) skipped"]
        for b in self.batches:
            parts.append(f"  + {b['trial']}/{b['case']}/{b['batch']}  ({b['n_files']} files: "
                         + ", ".join(f"{m}x{n}" for m, n in sorted(b['modalities'].items())) + ")")
        for h in self.held:
            parts.append(f"  ! holding {h['ingest_id']} group {h['group_no']}: {h['reason']} — "
                         f"{h['summary']}")
        for f in self.failures:
            parts.append(f"  x {f}")
        return "\n".join(parts)


@dataclass
class IngestReport:
    drops: list[DropReport] = field(default_factory=list)
    lock_busy: bool = False
    summary_path: Path | None = None
    mode: str = "ingest"

    @property
    def n_batches(self) -> int:
        return sum(len(d.batches) for d in self.drops)

    @property
    def n_held(self) -> int:
        return sum(len(d.held) for d in self.drops)

    @property
    def n_failures(self) -> int:
        return sum(len(d.failures) for d in self.drops)

    def summary(self) -> str:
        if self.lock_busy:
            return "store is locked by another ingest; nothing done"
        if not self.drops:
            return "inbox empty; nothing to do"
        out = "\n".join(d.summary() for d in self.drops)
        if self.summary_path:
            out += f"\nsummary: {self.summary_path}"
        return out


class Ingester:
    def __init__(self, store: Store, *, dry_run: bool = False,
                 forced: tuple[str, str] | None = None, keep_source: bool = False,
                 accept_uid_conflicts: bool = False, resolve_cmd: str = "iroc-store resolve",
                 copy_only: bool = False):
        """``copy_only`` is import mode: sources are read and copied, never moved or deleted."""
        self.store = store
        self.cfg = store.cfg
        self.cat = store.catalog
        self.dry_run = dry_run
        self.forced = forced
        self.copy_only = copy_only
        self.keep_source = keep_source or copy_only
        self.accept_uid_conflicts = accept_uid_conflicts
        self.resolve_cmd = resolve_cmd
        self.host = socket.gethostname()
        self.user = _username()

    # -- entry points -------------------------------------------------------------
    def run(self, sources: list[Path] | None = None, if_idle: bool = False,
            settle: bool = True, write_report: bool = True) -> IngestReport:
        started = datetime.now()
        report = IngestReport(mode="import" if self.copy_only else "ingest")
        drops = [Path(s) for s in sources] if sources else sorted(
            p for p in self.cfg.inbox.iterdir() if not p.name.startswith(".")
            and p.name != "STOP") if self.cfg.inbox.exists() else []
        if not drops:
            return report
        lock = None
        if not self.dry_run:
            lock = self.store.lock(cmd="ingest")
            try:
                lock.acquire(wait_seconds=0 if if_idle else 60)
            except LockHeldError as exc:
                logger.warning("%s", exc)
                report.lock_busy = True
                return report
        try:
            for drop in drops:
                if settle and not is_settled(drop, self.cfg.settle_seconds, self.cfg.ignore_globs):
                    logger.info("skipping %s: files still changing", drop)
                    report.drops.append(DropReport(drop, "", skipped_unsettled=True))
                    continue
                report.drops.append(self.ingest_drop(drop))
        finally:
            if lock is not None:
                lock.release()
        if write_report and report.drops:
            try:
                data = report_to_dict(report, started, datetime.now(), report.mode, self.user,
                                      self.host, self.store.root)
                report.summary_path = write_summary(self.cfg.reports, data, self.resolve_cmd)
            except OSError as exc:
                logger.warning("summary not written: %s", exc)
        if not self.dry_run and any(d.batches or d.held for d in report.drops):
            self.store.refresh_overview()
        return report

    def import_folder(self, folder: Path, if_idle: bool = False) -> IngestReport:
        """Walk ``folder`` (anywhere on disk), file what it finds, leave it untouched."""
        folder = Path(folder)
        if not folder.exists():
            raise FileNotFoundError(folder)
        self.copy_only = True
        self.keep_source = True
        return self.run([folder], if_idle=if_idle, settle=False)

    def ingest_drop(self, drop: Path, ingest_id: str | None = None,
                    drop_name: str | None = None) -> DropReport:
        drop = Path(drop)
        ingest_id = ingest_id or new_ingest_id()
        rep = DropReport(drop=drop, ingest_id=ingest_id, dry_run=self.dry_run)
        started = utcnow()
        handler = self._log_handler(ingest_id)
        try:
            logger.info("ingest %s: %s", ingest_id, drop)
            if self.dry_run:
                extract_dir = Path(tempfile.mkdtemp(prefix="iroc-dryrun-"))
            else:
                extract_dir = self.cfg.holding / f".extract-{ingest_id}"
            try:
                scan = scan_tree(drop, self.cfg, extract_dir, _drop_name=drop_name)
                rep.n_files_scanned = (sum(g.n_instances + len(g.dropped_duplicates)
                                           for g in scan.groups) + len(scan.others)
                                       + len(scan.unreadable))
                pending, held = self._plan(scan, rep)
                for pb in pending.values():
                    self._dedupe(pb, held, rep)
                for pb in pending.values():
                    if pb.n_files == 0:
                        rep.duplicates += len(pb.skipped)
                        logger.info("%s/%s: all %d files already in store; no batch",
                                    pb.trial_id, pb.case_id, len(pb.skipped))
                        continue
                    if self.dry_run:
                        rep.batches.append(self._describe(pb, "<dry-run>"))
                        rep.duplicates += len(pb.skipped)
                        continue
                    try:
                        rep.batches.append(self._write_batch(pb, ingest_id, drop, scan))
                        rep.duplicates += len(pb.skipped)
                    except CopyError as exc:
                        logger.error("batch for %s/%s aborted: %s", pb.trial_id, pb.case_id, exc)
                        rep.failures.append(f"{pb.trial_id}/{pb.case_id}: {exc}")
                if held:
                    for i, it in enumerate(held, start=1):
                        it.group_no = i
                    if self.dry_run:
                        rep.held.extend(self._describe_held(ingest_id, it) for it in held)
                    else:
                        write_holding(self.cfg.holding, ingest_id, str(drop), held,
                                      self.resolve_cmd, copy=self.copy_only)
                        for it in held:
                            self.cat.insert_holding(ingest_id, it.group_no,
                                                    group_dirname(it.group_no), it.reason,
                                                    it.decision.as_dict())
                            rep.held.append(self._describe_held(ingest_id, it))
                            self._log_held(ingest_id, it)
            finally:
                remove_tree(extract_dir)
            if not self.dry_run and not rep.failures and not self.keep_source:
                remove_tree(drop) if drop.is_dir() else drop.unlink(missing_ok=True)
                rep.removed_source = True
            if not self.dry_run:
                self.cat.insert_ingest_log(
                    ingest_id, started, utcnow(), self.host, self.user, str(drop),
                    rep.n_files_scanned, len(rep.batches), len(rep.held), rep.duplicates,
                    {"batches": rep.batches, "held": rep.held, "failures": rep.failures})
            logger.info("%s", rep.summary())
        finally:
            logging.getLogger().removeHandler(handler)
            handler.close()
        return rep

    # -- planning --------------------------------------------------------------------
    def _plan(self, scan: ScanResult, rep: DropReport
              ) -> tuple[dict[tuple[str, str], PendingBatch], list[HeldItem]]:
        pending: dict[tuple[str, str], PendingBatch] = {}
        held: list[HeldItem] = []
        decisions: list[tuple[SeriesGroup, Decision]] = []
        for g in scan.groups:
            dec = classify_group(g, self.cfg, self.forced)
            decisions.append((g, dec))
            if dec.ok:
                pb = pending.setdefault(dec.target, PendingBatch(*dec.target))
                pb.groups.append((g, dec))
            else:
                held.append(HeldItem(0, dec.reason, dec, group=g))
        held_others: dict[str, HeldItem] = {}
        for o in scan.others:
            dec = inherit_for_other(o, decisions, self.cfg, self.forced)
            if dec.ok:
                pending.setdefault(dec.target, PendingBatch(*dec.target)).others.append((o, dec))
            else:
                key = dec.reason + "|" + "; ".join(dec.notes[:1])
                item = held_others.get(key)
                if item is None:
                    item = HeldItem(0, dec.reason or NO_DICOM_CONTEXT, dec)
                    held_others[key] = item
                    held.append(item)
                item.others.append(o)
        if scan.unreadable:
            dec = Decision(None, READ_ERROR, notes=["file has a DICOM preamble but cannot be "
                                                     "parsed"])
            held.append(HeldItem(0, READ_ERROR, dec, others=list(scan.unreadable)))
        return pending, held

    def _dedupe(self, pb: PendingBatch, held: list[HeldItem], rep: DropReport) -> None:
        pk = pb.pk
        keep_groups: list[tuple[SeriesGroup, Decision]] = []
        for g, dec in pb.groups:
            keep: list = []
            conflict: str | None = None
            for h in g.headers:
                hits = self.cat.find_sop(h.sop_instance_uid) if h.sop_instance_uid else []
                if not hits:
                    keep.append(h)
                    continue
                same_case = [x for x in hits if x["case_pk"] == pk]
                if not same_case:
                    conflict = (f"SOPInstanceUID {h.sop_instance_uid} already stored under "
                                f"{hits[0]['case_pk']} ({hits[0]['rel_path']})")
                    break
                if not h.sha256:
                    h.sha256 = sha256_file(h.path)
                if any(x["sha256"] == h.sha256 for x in same_case):
                    pb.skipped.append({"source_relpath": h.source_relpath,
                                       "sop_instance_uid": h.sop_instance_uid,
                                       "existing": same_case[0]["rel_path"]})
                    continue
                if self.accept_uid_conflicts:
                    keep.append(h)
                    continue
                conflict = (f"SOPInstanceUID {h.sop_instance_uid} already stored for this case "
                            f"with different content ({same_case[0]['rel_path']})")
                break
            if conflict:
                dec2 = Decision(dec.target, UID_CONFLICT, dec.header_source, dec.folder_check,
                                dec.evidence, dec.notes + [conflict])
                held.append(HeldItem(0, UID_CONFLICT, dec2, group=g))
                continue
            if keep:
                g.headers = keep
                keep_groups.append((g, dec))
            elif g.dropped_duplicates or not g.headers:
                pass
        pb.groups = keep_groups
        keep_others = []
        for o, dec in pb.others:
            sha = sha256_file(o.path)
            if self.cat.find_sha(sha, pk):
                pb.skipped.append({"source_relpath": o.source_relpath, "sha256": sha,
                                   "existing": self.cat.find_sha(sha, pk)[0]["rel_path"]})
                continue
            keep_others.append((o, dec))
        pb.others = keep_others

    # -- writing a batch -----------------------------------------------------------------
    def _write_batch(self, pb: PendingBatch, ingest_id: str, drop: Path, scan: ScanResult) -> dict:
        cfg = self.cfg
        case = self.store.case(pb.trial_id, pb.case_id)
        rule = cfg.trial(pb.trial_id)
        original = case.original_dir
        original.mkdir(parents=True, exist_ok=True)
        existing = [p.name for p in original.iterdir() if p.is_dir()
                    and parse_batch_dirname(p.name)]
        batch_name = self.cat.next_batch_name(case.pk, datetime.now().date(), existing)
        final = original / batch_name
        staging = original / f".incoming-{ingest_id}"
        if staging.exists():
            remove_tree(staging)
        staging.mkdir(parents=True)
        verify_full = cfg.verify_copy == "full"
        taken_dirs: set[str] = set()
        series_entries, file_entries, modalities = [], [], {}
        try:
            for g, dec in pb.groups:
                moddir = cfg.modality_dirname(g.modality)
                name = fit_series_dirname(final, moddir, g.series_number, g.description,
                                          g.series_uid, cfg.desc_max_len, cfg.max_path)
                suffix = uid8(g.for_uid) if "shared across" in " ".join(g.problems) \
                    else uid8(g.series_uid)
                name = unique_name(name, taken_dirs, suffix)
                sdir = staging / name
                prefix = cfg.file_prefix(g.modality)
                taken_files: set[str] = set()
                n = 0
                for i, h in enumerate(g.headers, start=1):
                    num = h.instance_number if h.instance_number is not None else i
                    fname = instance_filename(prefix, num)
                    if fname.upper() in taken_files:
                        fname = instance_filename(prefix, num,
                                                  f"_{uid8(h.sop_instance_uid)}.dcm")
                    taken_files.add(fname.upper())
                    sha = copy_verified(h.path, sdir / fname, verify_full)
                    file_entries.append({
                        "path": f"{name}/{fname}", "size": h.size, "sha256": sha,
                        "kind": platform_kind("dicom", g.modality),
                        "sop_instance_uid": h.sop_instance_uid, "sop_class_uid": h.sop_class_uid,
                        "instance_number": h.instance_number, "series_dir": name,
                        "source_relpath": h.source_relpath})
                    n += 1
                modalities[g.modality] = modalities.get(g.modality, 0) + 1
                h0 = g.headers[0]
                series_entries.append({
                    "dir": name, "series_uid": g.series_uid, "study_uid": g.study_uid,
                    "for_uid": g.for_uid, "modality": g.modality,
                    "series_number": g.series_number, "description": g.description,
                    "study_date": h0.study_date, "n_instances": n,
                    "ref_series_uid": h0.ref_series_uid, "ref_sop_uid": h0.ref_sop_uid,
                    "key_tags": h0.key_tags, "problems": list(g.problems),
                    "classification": dec.as_dict(),
                })
            taken_docs: dict[str, set[str]] = {}
            for o, dec in pb.others:
                sub = subdir_for_kind(o.kind)
                fname = unique_filename(Path(o.path).name, taken_docs.setdefault(sub, set()))
                sha = copy_verified(o.path, staging / sub / fname, verify_full)
                file_entries.append({
                    "path": f"{sub}/{fname}", "size": o.size, "sha256": sha,
                    "kind": platform_kind(o.kind), "source_relpath": o.source_relpath,
                    "series_dir": None, "sop_instance_uid": None, "sop_class_uid": None,
                    "instance_number": None})
            archives = []
            for z in scan.archives:
                entry = {"name": z.name, "size": z.stat().st_size, "kept": bool(cfg.keep_archives)}
                if cfg.keep_archives:
                    fname = unique_filename(z.name, taken_docs.setdefault(ARCHIVES_DIR, set()))
                    entry["sha256"] = copy_verified(z, staging / ARCHIVES_DIR / fname, verify_full)
                    entry["path"] = f"{ARCHIVES_DIR}/{fname}"
                    file_entries.append({"path": entry["path"], "size": entry["size"],
                                         "sha256": entry["sha256"], "kind": "archive_zip",
                                         "source_relpath": z.name, "series_dir": None,
                                         "sop_instance_uid": None, "sop_class_uid": None,
                                         "instance_number": None})
                archives.append(entry)
        except CopyError:
            remove_tree(staging)
            raise
        seq = self.cat.next_batch_seq(case.pk)
        kind = "initial" if seq == 1 else "resubmission"
        ingested_at = utcnow()
        first_dec = pb.groups[0][1] if pb.groups else pb.others[0][1]
        manifest = {
            "schema": BATCH_SCHEMA, "trial": pb.trial_id, "case_id": pb.case_id,
            "batch": batch_name, "seq": seq, "kind": kind, "ingest_id": ingest_id,
            "ingested_at": ingested_at, "host": self.host, "user": self.user,
            "iroc_qa_version": _tool_version, "source": str(drop),
            "classification": first_dec.as_dict(),
            "studies": _studies(pb), "series": series_entries, "files": file_entries,
            "archives": archives, "skipped_duplicates": pb.skipped,
        }
        _write_json(staging / BATCH_MANIFEST, manifest)
        final.parent.mkdir(parents=True, exist_ok=True)
        staging.rename(final)
        batch_rel = self.store.rel(final)
        with self.cat.transaction():
            self.cat.upsert_trial(rule.id, rule.name, rule.protocol_ids)
            self.cat.upsert_case(pb.trial_id, pb.case_id)
            bid = self.cat.insert_batch(case.pk, batch_name, seq, kind, ingest_id, str(drop),
                                        ingested_at, len(file_entries),
                                        sum(f["size"] for f in file_entries), manifest)
            sids = {}
            for s in series_entries:
                sids[s["dir"]] = self.cat.insert_series(
                    bid, case.pk, f"{batch_rel}/{s['dir']}", s["series_uid"], s["study_uid"],
                    s["for_uid"], s["modality"], s["series_number"], s["description"],
                    s["study_date"], s["n_instances"], s["ref_series_uid"], s["ref_sop_uid"],
                    s["key_tags"])
            self.cat.insert_files({
                "case_pk": case.pk, "origin": "original", "batch_id": bid,
                "series_id": sids.get(f["series_dir"]) if f.get("series_dir") else None,
                "kind": f["kind"], "rel_path": f"{batch_rel}/{f['path']}", "size": f["size"],
                "sha256": f["sha256"], "source_relpath": f.get("source_relpath"),
                "sop_instance_uid": f.get("sop_instance_uid"),
                "sop_class_uid": f.get("sop_class_uid"),
                "instance_number": f.get("instance_number"),
            } for f in file_entries)
            self.cat.advance_current_if_unpinned(case.pk, bid)
        desc = ", ".join(f"{m}x{n}" for m, n in sorted(modalities.items()))
        self.store.log.append(pb.trial_id, "ingest",
                              f"{batch_name} ({kind}): {desc or 'documents only'}, "
                              f"{len(file_entries)} files, "
                              f"{'imported from' if self.copy_only else 'from'} "
                              f"{drop if self.copy_only else drop.name}",
                              case_id=pb.case_id,
                              details={"ingest_id": ingest_id, "batch_id": bid})
        self.store.run_on_ingest(case, bid)
        return self._describe(pb, batch_name, modalities, len(file_entries), bid)

    # -- reporting helpers ---------------------------------------------------------------
    def _describe(self, pb: PendingBatch, batch_name: str, modalities: dict | None = None,
                  n_files: int | None = None, batch_id: str | None = None) -> dict:
        if modalities is None:
            modalities = {}
            for g, _ in pb.groups:
                modalities[g.modality] = modalities.get(g.modality, 0) + 1
        return {"trial": pb.trial_id, "case": pb.case_id, "batch": batch_name,
                "batch_id": batch_id, "n_files": pb.n_files if n_files is None else n_files,
                "modalities": modalities, "n_documents": len(pb.others),
                "skipped_duplicates": len(pb.skipped)}

    @staticmethod
    def _describe_held(ingest_id: str, it: HeldItem) -> dict:
        return {"ingest_id": ingest_id, "group_no": it.group_no, "reason": it.reason,
                "summary": it.summary(), "n_files": len(it.files),
                "suggested": it.decision.target, "notes": list(it.decision.notes)}

    def _log_held(self, ingest_id: str, it: HeldItem) -> None:
        trial = it.decision.target[0] if it.decision.target else None
        if trial is None:
            for e in it.decision.evidence:
                if e.trial_id:
                    trial = e.trial_id
                    break
        if trial is None:
            return
        case = it.decision.target[1] if it.decision.target else None
        self.store.log.append(trial, "holding",
                              f"{ingest_id} group {it.group_no}: {it.reason} — {it.summary()}",
                              case_id=case, details={"ingest_id": ingest_id})

    def _log_handler(self, ingest_id: str) -> logging.Handler:
        if self.dry_run:
            return logging.NullHandler()
        self.cfg.logs.mkdir(parents=True, exist_ok=True)
        h = logging.FileHandler(self.cfg.logs / f"ingest-{ingest_id}.log", encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
        h.setLevel(logging.INFO)
        logging.getLogger().addHandler(h)
        return h


def _studies(pb: PendingBatch) -> list[dict]:
    seen: dict[str, dict] = {}
    for g, _ in pb.groups:
        s = seen.setdefault(g.study_uid, {"study_uid": g.study_uid,
                                          "study_date": g.headers[0].study_date,
                                          "study_description": g.headers[0].study_description,
                                          "for_uids": []})
        if g.for_uid and g.for_uid not in s["for_uids"]:
            s["for_uids"].append(g.for_uid)
    return list(seen.values())


def _write_json(path: Path, data: dict) -> None:
    part = path.with_name(path.name + ".part")
    part.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
    part.replace(path)


# ---------------------------------------------------------------------------
# resolving holding items
# ---------------------------------------------------------------------------

def resolve_holding(store: Store, ingest_id: str, group_nos: list[int] | None, trial: str | None,
                    case: str | None, *, discard: bool = False,
                    force_new_batch: bool = False) -> list[dict]:
    from .holding import load_report

    report = load_report(store.cfg.holding, ingest_id)
    groups = report["groups"]
    if group_nos:
        groups = [g for g in groups if g["group_no"] in group_nos]
        missing = set(group_nos) - {g["group_no"] for g in groups}
        if missing:
            raise ValueError(f"no such holding group(s) {sorted(missing)} in {ingest_id}")
    results = []
    with store.lock(cmd="resolve"):
        for g in groups:
            gdir = store.cfg.holding / ingest_id / g["dir"]
            if not gdir.exists():
                results.append({"group_no": g["group_no"], "status": "already resolved"})
                continue
            if discard:
                dst = discard_group(store.cfg.holding, ingest_id, g["group_no"])
                store.catalog.resolve_holding(ingest_id, g["group_no"], "discarded")
                t = (g.get("decision") or {}).get("trial")
                if t:
                    store.log.append(t, "discard", f"{ingest_id} group {g['group_no']} discarded "
                                     f"-> {dst.name}",
                                     case_id=(g.get("decision") or {}).get("case"))
                results.append({"group_no": g["group_no"], "status": "discarded", "path": str(dst)})
                continue
            if not (trial and case):
                raise ValueError("--trial and --case are required unless --discard")
            ing = Ingester(store, forced=(trial, case), keep_source=False,
                           accept_uid_conflicts=force_new_batch)
            rep = ing.ingest_drop(gdir, drop_name=f"{ingest_id}/{g['dir']}")
            if rep.batches:
                bid = rep.batches[0]["batch_id"]
                store.catalog.resolve_holding(ingest_id, g["group_no"], bid)
                store.log.append(rep.batches[0]["trial"], "resolve",
                                 f"{ingest_id} group {g['group_no']} ({g['reason']}) filed as "
                                 f"{rep.batches[0]['batch']}", case_id=rep.batches[0]["case"],
                                 details={"holding": ingest_id, "batch_id": bid})
                results.append({"group_no": g["group_no"], "status": "filed", "batch_id": bid})
            elif rep.duplicates and not rep.held and not rep.failures:
                store.catalog.resolve_holding(ingest_id, g["group_no"], "duplicate")
                results.append({"group_no": g["group_no"], "status": "duplicate of stored data"})
            else:
                results.append({"group_no": g["group_no"], "status": "still held",
                                "held": rep.held, "failures": rep.failures})
        cleanup_if_empty(store.cfg.holding, ingest_id)
    store.refresh_overview()
    return results
