using System;
using System.Windows;
using VMS.TPS.Common.Model;
using VMS.TPS.Common.Model.API;
using System.IO;
using System.Windows.Controls;
using System.Collections.Generic;
using VMS.TPS.Common.Model.Types;

namespace VMS.TPS
{
  public class Script
  {
    public Script() {}

    DVHEstimationInfoView view_;

    public void Execute(ScriptContext ctx, System.Windows.Window win)
    {
      PlanSetup plan = ctx.PlanSetup;
      view_ = new DVHEstimationInfoView(win, plan);
    }
  }

  public class StructureInfo
  {
    public StructureInfo(string structure)
    {
      StructureId = structure;
      Estimates = new List<string[]>();
      Objectives = new List<string[]>();
      DVH = new List<string>();
    }

    public string StructureId;
    public List<string[]> Estimates;
    public List<string[]> Objectives;
    public List<string> DVH;
  }

  public class DVHEstimationInfoView
  {
    System.Windows.Window window_;
    Grid grid_;
    StackPanel textPanel_;
    PlanSetup plan_;
    List<StructureInfo> structures_;

    public DVHEstimationInfoView(System.Windows.Window win, PlanSetup plan)
    {
      window_ = win;
      plan_ = plan;
      structures_ = new List<StructureInfo>();

      CreateDialog();
      OutputPlanToText();
      SaveClipboardToCSV();  // ✅ Use clipboard text
    }

    private void CreateDialog()
    {
      grid_ = new Grid();

      grid_.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
      grid_.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
      grid_.RowDefinitions.Add(new RowDefinition { Height = new GridLength(50) });

      textPanel_ = new StackPanel();

      TextBox text = new TextBox();
      text.Text = string.Format("Plan id: {0}, course id: {1}", plan_.Id, plan_.Course.Id);
      textPanel_.Children.Add(text);

      ScrollViewer scroller = new ScrollViewer();
      scroller.Content = textPanel_;
      Grid.SetRow(scroller, 0);
      Grid.SetColumn(scroller, 0);
      grid_.Children.Add(scroller);

      Button btn = new Button();
      btn.IsEnabled = true;
      btn.Content = "Close";
      btn.Click += CloseButton_Click;
      Grid.SetRow(btn, 1);
      Grid.SetColumn(btn, 0);
      grid_.Children.Add(btn);

      window_.Content = grid_;
    }

    private void OutputPlanToText()
    {
      OptimizationSetup opt = plan_.OptimizationSetup;

      if (opt != null)
      {
        foreach (var objective in opt.Objectives)
        {
          StructureInfo info = structures_.Find(s => s.StructureId == objective.Structure.Id);
          if (info == null)
          {
            info = new StructureInfo(objective.Structure.Id);
            structures_.Add(info);
          }

          if (objective.GetType() == typeof(OptimizationPointObjective))
          {
            var p_objective = objective as OptimizationPointObjective;
            info.Objectives.Add(new string[] {
              string.Format("Point objective d/v: {0} {1} / {2} %, prio: {3:F0}",
              p_objective.Dose.ValueAsString,
              p_objective.Dose.UnitAsString,
              p_objective.Volume,
              p_objective.Priority)
            });
          }
          else if (objective.GetType() == typeof(OptimizationLineObjective))
          {
            var l_objective = objective as OptimizationLineObjective;
            List<string> lineValues = new List<string>();
            foreach (var dvhPoint in l_objective.CurveData)
            {
              lineValues.Add(string.Format("{0}, {1:F1}",
              dvhPoint.DoseValue.ValueAsString,
              dvhPoint.Volume));
            }
            lineValues.Insert(0, string.Format("Line objective, priority: {0:F0},", l_objective.Priority));
            info.Objectives.Add(lineValues.ToArray());
          }
          else
          {
            info.Objectives.Add(new string[] { "unknown optimization objective" });
          }
        }
      }

      foreach (var dvhe in plan_.DVHEstimates)
      {
        StructureInfo info = structures_.Find(s => s.StructureId == dvhe.Structure.Id);
        if (info == null)
        {
          info = new StructureInfo(dvhe.Structure.Id);
          structures_.Add(info);
        }

        List<string> lineValues = new List<string>();
        foreach (var dvhPoint in dvhe.CurveData)
        {
          lineValues.Add(string.Format("{0}, {1:F1}", dvhPoint.DoseValue.ValueAsString, dvhPoint.Volume));
        }

        info.Estimates.Add(lineValues.ToArray());
      }

      if (plan_.IsDoseValid)
      {
        foreach (var structure in plan_.StructureSet.Structures)
        {
          StructureInfo info = structures_.Find(s => s.StructureId == structure.Id);
          if (info != null)
          {
            DVHData dvhData = plan_.GetDVHCumulativeData(structure, DoseValuePresentation.Absolute, VolumePresentation.Relative, 1.0);
            if (dvhData != null)
            {
              info.DVH.Add(string.Format("Coverage: {0:F1}, dose min: {1} {2}, dose max: {3} {4}, dose mean: {5} {6}",
              dvhData.Coverage,
              dvhData.MinDose.ValueAsString, dvhData.MinDose.UnitAsString,
              dvhData.MaxDose.ValueAsString, dvhData.MaxDose.UnitAsString,
              dvhData.MeanDose.ValueAsString, dvhData.MeanDose.UnitAsString));
              foreach (var dvhPoint in dvhData.CurveData)
              {
                info.DVH.Add(string.Format("{0}, {1:F1}", dvhPoint.DoseValue.ValueAsString, dvhPoint.Volume));
              }
            }
          }
        }
      }

      System.Text.StringBuilder sb = new System.Text.StringBuilder();

      foreach (var info in structures_)
      {
        sb.AppendLine("Structure Name:");
        sb.AppendLine(info.StructureId);

        foreach (var strArr in info.Estimates)
        {
          sb.AppendLine("DVH Estimate:");
          foreach (var str in strArr)
          {
            sb.AppendLine(str);
          }
        }
        sb.AppendLine("Optimization Objectives:");
        foreach (var strArr in info.Objectives)
        {
          foreach (var str in strArr)
          {
            sb.AppendLine(str);
          }
        }

        if (info.DVH.Count > 0)
        {
          foreach (var str in info.DVH)
          {
            sb.AppendLine(str);
          }
        }
        sb.AppendLine();
      }

      TextBox strInfoTextBox = new TextBox();
      strInfoTextBox.Text = sb.ToString();
      strInfoTextBox.AcceptsReturn = true;
      textPanel_.Children.Add(strInfoTextBox);
      Clipboard.SetText(sb.ToString());
    }

    private void SaveClipboardToCSV()
    {
      Microsoft.Win32.SaveFileDialog dialog = new Microsoft.Win32.SaveFileDialog();
      dialog.Filter = "CSV files (*.csv)|*.csv";
      dialog.Title = "Save DVH CSV File";
      dialog.FileName = string.Format("DVH_Clipboard_{0:yyyyMMdd_HHmmss}.csv", DateTime.Now);

      bool? result = dialog.ShowDialog();
      if (result == true)
      {
        string path = dialog.FileName;
        string content = Clipboard.GetText();  // ✅ Get DVH text directly from clipboard
        File.WriteAllText(path, content);
        MessageBox.Show("DVH clipboard text saved to: " + path);
      }
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
      window_.Close();
    }
  }
}
