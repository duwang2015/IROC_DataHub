"""Resolve (trial, case) for a series group. The DICOM header is authoritative.

Folder names are only cross-checked: any disagreement, or a header that cannot be
recognised, sends the group to the holding area for human review.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .config import StoreConfig, TrialRule
from .layout import normalize_case_id
from .scanner import OtherFile, SeriesGroup

AUTHORITATIVE = "authoritative"
CHECK = "check"
FORCED = "forced"

# holding reasons
OK = "ok"
HEADER_CONFLICT = "header_conflict"
UNRECOGNIZED = "unrecognized"
FOLDER_MISMATCH = "folder_mismatch"
AMBIGUOUS_TRIAL = "ambiguous_trial"
INCONSISTENT_SERIES = "inconsistent_series"
UID_CONFLICT = "uid_conflict"
NO_DICOM_CONTEXT = "no_dicom_context"
READ_ERROR = "read_error"


@dataclass
class Evidence:
    category: str          # authoritative | check | forced
    source: str            # tag_0012 | patient_id | folder | keyword | forced
    trial_id: str | None
    case_id: str | None    # normalized
    detail: str = ""

    def as_dict(self) -> dict:
        return {"category": self.category, "source": self.source, "trial": self.trial_id,
                "case": self.case_id, "detail": self.detail}


@dataclass
class Decision:
    target: tuple[str, str] | None
    reason: str
    header_source: str = ""
    folder_check: str = "absent"   # match | mismatch | absent
    evidence: list[Evidence] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.reason == OK and self.target is not None

    def as_dict(self) -> dict:
        return {
            "trial": self.target[0] if self.target else None,
            "case": self.target[1] if self.target else None,
            "reason": self.reason, "header_source": self.header_source,
            "folder_check": self.folder_check,
            "evidence": [e.as_dict() for e in self.evidence], "notes": list(self.notes),
        }


def _norm(rule: TrialRule, raw: str) -> str:
    return normalize_case_id(raw, rule.case_id_normalize)


def collect_evidence(group: SeriesGroup, cfg: StoreConfig) -> list[Evidence]:
    ev: list[Evidence] = []
    pids = {h.patient_id for h in group.headers}
    protos = {h.trial_protocol_id for h in group.headers if h.trial_protocol_id}
    subjects = {h.trial_subject_id for h in group.headers if h.trial_subject_id}
    # -- authoritative: clinical trial module tags (0012,xxxx)
    if protos or subjects:
        if len(protos) > 1 or len(subjects) > 1:
            ev.append(Evidence(AUTHORITATIVE, "tag_0012", None, None,
                               f"inconsistent 0012 tags within series: {sorted(protos)} "
                               f"{sorted(subjects)}"))
        else:
            proto = next(iter(protos), "")
            subj = next(iter(subjects), "")
            matched = [t for t in cfg.trials if t.matches_protocol(proto)] if proto else []
            if matched:
                t = matched[0]
                ev.append(Evidence(AUTHORITATIVE, "tag_0012", t.id,
                                   _norm(t, subj) if subj else None,
                                   f"ClinicalTrialProtocolID={proto!r} "
                                   f"ClinicalTrialSubjectID={subj!r}"))
            elif proto:
                ev.append(Evidence(CHECK, "tag_0012", None, None,
                                   f"ClinicalTrialProtocolID={proto!r} matches no configured "
                                   "trial"))
    # -- authoritative: PatientID
    if len(pids) > 1:
        ev.append(Evidence(AUTHORITATIVE, "patient_id", None, None,
                           f"inconsistent PatientID within series: {sorted(pids)}"))
    else:
        pid = next(iter(pids), "")
        hits = []
        for t in cfg.trials:
            c = t.match_patient_id(pid) if pid else None
            if c:
                hits.append((t, c))
        for t, c in hits:
            ev.append(Evidence(AUTHORITATIVE, "patient_id", t.id, _norm(t, c),
                               f"PatientID={pid!r}"))
        if not hits:
            ev.append(Evidence(AUTHORITATIVE, "patient_id", None, None,
                               f"PatientID={pid!r} matches no configured trial"))
    # -- check: folder names (nearest first), first hit per trial
    for hint in group.folder_hints:
        for t in cfg.trials:
            c = t.match_case_in_text(hint)
            if c:
                ev.append(Evidence(CHECK, "folder", t.id, _norm(t, c), f"folder={hint!r}"))
    # -- check: keywords
    texts = [h.study_description for h in group.headers[:1]] + list(group.folder_hints)
    for t in cfg.trials:
        for text in texts:
            if text and t.keyword_in(text):
                ev.append(Evidence(CHECK, "keyword", t.id, None, f"keyword in {text!r}"))
                break
    return ev


def decide(evidence: list[Evidence], cfg: StoreConfig,
           forced: tuple[str, str] | None = None) -> Decision:
    d = Decision(target=None, reason=UNRECOGNIZED, evidence=list(evidence))
    auth = [e for e in evidence if e.category == AUTHORITATIVE]
    checks = [e for e in evidence if e.category == CHECK and e.trial_id]
    for e in auth:
        if e.trial_id is None and "inconsistent" in e.detail:
            d.reason = INCONSISTENT_SERIES
            d.notes.append(e.detail)
            if forced is None:
                return d
    if forced is not None:
        t = cfg.trial(forced[0])
        d.target = (t.id, _norm(t, forced[1]))
        d.reason = OK
        d.header_source = "forced"
        d.evidence.append(Evidence(FORCED, "forced", d.target[0], d.target[1], "forced by user"))
        agree = [e for e in auth if e.trial_id]
        if agree and not any((e.trial_id, e.case_id) == d.target for e in agree):
            d.notes.append("forced target differs from DICOM header: "
                           + "; ".join(f"{e.source}: {e.trial_id}/{e.case_id}" for e in agree))
        return d
    tag = [e for e in auth if e.source == "tag_0012" and e.trial_id]
    pid = [e for e in auth if e.source == "patient_id" and e.trial_id]
    candidates: list[tuple[str, str, str]] = []  # (source, trial, case)
    if tag:
        e = tag[0]
        if e.case_id:
            candidates.append(("tag_0012", e.trial_id, e.case_id))
        else:
            # trial from the tag, case must come from PatientID within that trial
            same = [p for p in pid if p.trial_id == e.trial_id]
            if same:
                candidates.append(("tag_0012+patient_id", e.trial_id, same[0].case_id))
            else:
                d.notes.append(f"trial {e.trial_id} from 0012 tags but PatientID gives no case")
    if len(pid) > 1 and len({p.trial_id for p in pid}) > 1:
        d.reason = AMBIGUOUS_TRIAL
        d.notes.append("PatientID matches more than one trial: "
                       + ", ".join(f"{p.trial_id}/{p.case_id}" for p in pid))
        return d
    if pid:
        candidates.append(("patient_id", pid[0].trial_id, pid[0].case_id))
    uniq = {(t, c) for _, t, c in candidates}
    if not uniq:
        d.reason = UNRECOGNIZED
        d.notes.append("no trial/case could be read from DICOM headers")
        if checks:
            d.notes.append("folder/keyword suggests: "
                           + ", ".join(f"{e.trial_id}/{e.case_id or '?'}" for e in checks))
        return d
    if len(uniq) > 1:
        d.reason = HEADER_CONFLICT
        d.notes.append("0012 tags and PatientID disagree: "
                       + ", ".join(f"{s}: {t}/{c}" for s, t, c in candidates))
        return d
    trial_id, case_id = next(iter(uniq))
    d.target = (trial_id, case_id)
    d.header_source = candidates[0][0]
    folder_ev = [e for e in checks if e.source == "folder"]
    mismatches = [e for e in folder_ev if (e.trial_id, e.case_id) != d.target]
    if mismatches:
        d.reason = FOLDER_MISMATCH
        d.folder_check = "mismatch"
        d.notes.append("folder name disagrees with header: "
                       + ", ".join(f"{e.detail} -> {e.trial_id}/{e.case_id}" for e in mismatches)
                       + f"; header -> {trial_id}/{case_id}")
        return d
    kw_mismatch = [e for e in checks if e.source == "keyword" and e.trial_id != trial_id]
    if kw_mismatch and not folder_ev:
        d.notes.append("keyword hints a different trial: "
                       + ", ".join(e.trial_id for e in kw_mismatch))
    d.folder_check = "match" if folder_ev else "absent"
    d.reason = OK
    return d


def classify_group(group: SeriesGroup, cfg: StoreConfig,
                   forced: tuple[str, str] | None = None) -> Decision:
    d = decide(collect_evidence(group, cfg), cfg, forced)
    for p in group.problems:
        if "different content" in p:
            d.reason = UID_CONFLICT
            d.target = d.target if forced else d.target
            d.notes.append(p)
        else:
            d.notes.append(p)
    if d.reason == UID_CONFLICT:
        d.target = None
    return d


def inherit_for_other(other: OtherFile, group_decisions: list[tuple[SeriesGroup, Decision]],
                      cfg: StoreConfig, forced: tuple[str, str] | None = None) -> Decision:
    """A non-DICOM file inherits the unique target of DICOM groups in its folder or below."""
    if forced is not None:
        t = cfg.trial(forced[0])
        return Decision((t.id, _norm(t, forced[1])), OK, "forced", "absent",
                        [Evidence(FORCED, "forced", t.id, _norm(t, forced[1]), "forced by user")])
    my_dir = str(_parent(other.source_relpath))
    same: list[Decision] = []
    below: list[Decision] = []
    for g, dec in group_decisions:
        dirs = g.source_dirs
        if my_dir in dirs:
            same.append(dec)
        elif any(sd.startswith(my_dir + "/") or my_dir == "." for sd in dirs):
            below.append(dec)
    scope = same or below          # DICOM in the same folder wins over sub-folders
    targets = {d.target for d in scope if d.ok}
    blocked = any(not d.ok for d in scope)
    d = Decision(None, NO_DICOM_CONTEXT)
    if len(targets) == 1 and not blocked:
        d.target = next(iter(targets))
        d.reason = OK
        d.header_source = "inherited"
        d.notes.append("inherited from DICOM series in the same folder")
        return d
    if not targets and not blocked:
        d.notes.append("no DICOM series in the same folder to inherit a case from")
    elif blocked:
        d.notes.append("DICOM series in the same folder were sent to holding")
    else:
        d.notes.append("DICOM series in the same folder belong to several cases")
    for t in cfg.trials:
        for hint in other.folder_hints:
            c = t.match_case_in_text(hint)
            if c:
                d.notes.append(f"folder suggests {t.id}/{_norm(t, c)}")
                break
    return d


def _parent(relpath: str) -> str:
    rp = relpath.replace("!/", "/")
    if "/" not in rp:
        return "."
    return rp.rsplit("/", 1)[0]
