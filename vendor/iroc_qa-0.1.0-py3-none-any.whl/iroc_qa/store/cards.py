"""Per-case ``case.json`` cards and per-collection ``cases.json`` indexes.

A card is a self-contained summary of one case, written next to the data so that any
project can read it without the catalog or the app. Paths inside are relative to the case
directory, so a moved or copied case folder keeps a valid card. Cards are derived from the
catalog and rewritten after every change (ingest, resolve, derived run, current batch,
reindex); ``iroc-store cards`` rebuilds them all.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

from .fsutil import atomic_write_text
from .layout import CASE_PIN, ORIGINAL_DIR

if TYPE_CHECKING:
    from .store import CaseRef, Store

CASE_SCHEMA = "iroc-store.case/2"
INDEX_SCHEMA = "iroc-store.cases-index/1"
INDEX_NAME = "cases.json"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _rel(case_rel: str, rel_path: str) -> str:
    """Catalog paths are relative to the root; cards want them relative to the case dir."""
    prefix = case_rel.rstrip("/") + "/"
    return rel_path[len(prefix):] if rel_path.startswith(prefix) else rel_path


def build_case_card(store: Store, case: CaseRef) -> dict:
    cat = store.catalog
    c = cat.get_case(case.pk) or {}
    case_rel = store.rel(case.dir)
    batches = []
    for b in cat.list_batches(case.pk):
        series = []
        for s in cat.series_for_case(case.pk, batch_id=b["id"]):
            series.append({
                "dir": _rel(case_rel, s["rel_dir"]), "modality": s["modality"],
                "series_number": s["series_number"], "description": s["series_description"],
                "study_date": s["study_date"], "n_instances": s["n_instances"],
                "series_uid": s["series_uid"], "study_uid": s["study_uid"],
                "frame_of_reference_uid": s["frame_of_reference_uid"],
                "ref_series_uid": s["ref_series_uid"] or None,
                "ref_sop_uid": s["ref_sop_uid"] or None,
            })
        docs = [{"path": _rel(case_rel, f["rel_path"]), "kind": f["kind"], "size": f["size"],
                 "sha256": f["sha256"]}
                for f in cat.files_for_batch(b["id"]) if f["series_id"] is None]
        batches.append({
            "name": b["name"], "seq": b["seq"], "kind": b["kind"],
            "ingested_at": b["ingested_at"], "source": b["source"], "ingest_id": b["ingest_id"],
            "n_files": b["n_files"], "bytes": b["total_bytes"],
            "current": b["id"] == c.get("current_batch_id"),
            "dir": f"{ORIGINAL_DIR}/{b['name']}", "series": series, "documents": docs,
        })
    derived = []
    for r in cat.runs_for_case(case.pk):
        files = [f for f in cat.derived_files(case.pk, module=r["module"], latest_only=False)
                 if f["derived_run_id"] == r["id"]]
        meta = {}
        outputs = []
        for f in files:
            try:
                meta = json.loads(f["metadata_json"]) if f.get("metadata_json") else {}
            except ValueError:
                meta = {}
            outputs.append({"role": meta.get("role", "other"),
                            "path": _rel(case_rel, f["rel_path"]), "kind": f["kind"],
                            "size": f["size"], "sha256": f["sha256"]})
        try:
            params = json.loads(r["params_json"]) if r.get("params_json") else {}
        except ValueError:
            params = {}
        derived.append({
            "module": r["module"], "version": r["version"], "run": r["run_name"],
            "status": r["status"], "started_at": r["started_at"],
            "finished_at": r["finished_at"], "dir": _rel(case_rel, r["rel_dir"]),
            "params": params, "inputs_hash": r["inputs_hash"], "outputs": outputs,
        })
    modalities = sorted({s["modality"] for b in batches for s in b["series"]})
    latest: dict[str, dict] = {}
    for d in derived:
        if d["status"] == "completed":
            key = f"{d['module']}@{d['version']}"
            if key not in latest or d["started_at"] >= latest[key]["started_at"]:
                latest[key] = d
    notes_dir = case.dir / "notes"
    return {
        "schema": CASE_SCHEMA, "updated_at": _now(),
        "site": case.site, "collection": case.trial, "collection_kind": case.kind,
        "case_id": case.case_id, "pk": case.pk, "path_rel": case_rel,
        "current_batch": (c.get("current_batch_id") or "").rsplit("/", 1)[-1] or None,
        "pinned": bool(c.get("pinned")),
        "modalities": modalities,
        "modules": sorted({d["module"] for d in derived if d["status"] == "completed"}),
        "batches": batches,
        "derived": derived,
        "latest_outputs": {k: {"run": v["run"], "dir": v["dir"], "outputs": v["outputs"]}
                           for k, v in latest.items()},
        "notes_dir": "notes" if notes_dir.is_dir() else None,
        "notes": sorted(p.name for p in notes_dir.iterdir()) if notes_dir.is_dir() else [],
        "n_log_entries": len(cat.trial_log(case.trial, case_id=case.case_id, limit=100000)),
    }


def write_case_card(store: Store, case: CaseRef) -> Path | None:
    if store.catalog.get_case(case.pk) is None:
        return None
    case.dir.mkdir(parents=True, exist_ok=True)
    card = build_case_card(store, case)
    path = case.dir / CASE_PIN
    atomic_write_text(path, json.dumps(card, indent=1, ensure_ascii=False))
    return path


def write_collection_index(store: Store, collection_id: str) -> Path | None:
    rule = store.cfg.trial(collection_id)
    cdir = store.collection_dir(rule.id)
    rows = []
    for c in store.catalog.list_cases(rule.id):
        series = store.catalog.series_for_case(c["id"])
        batches = store.catalog.list_batches(c["id"])
        runs = store.catalog.runs_for_case(c["id"], status="completed")
        rows.append({
            "case_id": c["case_id"], "dir": c["case_id"],
            "modalities": sorted({s["modality"] for s in series}),
            "modules": sorted({r["module"] for r in runs}),
            "n_batches": len(batches),
            "current_batch": (c["current_batch_id"] or "").rsplit("/", 1)[-1] or None,
            "last_ingest": max((b["ingested_at"] for b in batches), default=None),
            "n_files": sum(b["n_files"] for b in batches),
        })
    if not rows and not cdir.exists():
        return None
    cdir.mkdir(parents=True, exist_ok=True)
    path = cdir / INDEX_NAME
    atomic_write_text(path, json.dumps({
        "schema": INDEX_SCHEMA, "updated_at": _now(), "site": rule.site,
        "collection": rule.id, "collection_kind": rule.kind, "name": rule.name,
        "n_cases": len(rows), "cases": rows}, indent=1, ensure_ascii=False))
    return path


def refresh_cards(store: Store, case: CaseRef) -> None:
    """Rewrite the card of one case and its collection index; never raises."""
    try:
        write_case_card(store, case)
        write_collection_index(store, case.trial)
    except Exception as exc:  # pragma: no cover - cards must never break a write path
        import logging

        logging.getLogger(__name__).warning("case card not refreshed for %s: %s", case.pk, exc)


def rebuild_all_cards(store: Store) -> int:
    n = 0
    for c in store.catalog.list_cases():
        try:
            case = store.case_from_pk(c["id"])
        except Exception:
            continue
        if write_case_card(store, case):
            n += 1
    for rule in store.cfg.trials:
        write_collection_index(store, rule.id)
    return n


# ---------------------------------------------------------------------------------
# reading cards without a Store (for other projects)
# ---------------------------------------------------------------------------------

def load_case(path: Path | str) -> dict:
    """Load a ``case.json`` (or a case directory containing one)."""
    p = Path(path)
    if p.is_dir():
        p = p / CASE_PIN
    card = json.loads(p.read_text(encoding="utf-8"))
    card["_dir"] = str(p.parent)
    return card


def iter_cases(root: Path | str, site: str | None = None, collection: str | None = None,
               modality: str | None = None) -> Iterator[dict]:
    """Yield case cards under ``root`` (``<site>/<collection>/<case>/case.json``)."""
    root = Path(root)
    for p in sorted(root.glob("*/*/*/" + CASE_PIN)):
        if p.parent.parent.parent.name.startswith(("_", ".")):
            continue
        try:
            card = load_case(p)
        except (OSError, ValueError):
            continue
        if card.get("schema") != CASE_SCHEMA:
            continue
        if site and card.get("site") != site:
            continue
        if collection and card.get("collection") != collection:
            continue
        if modality and modality.upper() not in card.get("modalities", []):
            continue
        yield card


def case_files(card: dict, modality: str | None = None, current_only: bool = True) -> list[Path]:
    """Absolute series directories of a loaded card, optionally one modality / current batch."""
    base = Path(card["_dir"])
    out = []
    for b in card["batches"]:
        if current_only and not b["current"]:
            continue
        for s in b["series"]:
            if modality and s["modality"] != modality.upper():
                continue
            out.append(base / s["dir"])
    return out


def derived_outputs(card: dict, module: str, kind: str | None = None) -> list[Path]:
    """Absolute paths of the latest completed outputs of ``module`` in a loaded card."""
    base = Path(card["_dir"])
    out = []
    for key, v in card.get("latest_outputs", {}).items():
        if key.split("@")[0] != module:
            continue
        for o in v["outputs"]:
            if kind and not o["kind"].startswith(kind):
                continue
            out.append(base / o["path"])
    return out


__all__ = ["CASE_SCHEMA", "INDEX_SCHEMA", "build_case_card", "case_files", "derived_outputs",
           "iter_cases", "load_case", "rebuild_all_cards", "refresh_cards", "write_case_card",
           "write_collection_index"]
