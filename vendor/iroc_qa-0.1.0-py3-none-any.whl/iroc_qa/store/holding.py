"""Holding area: groups that could not be filed automatically, with a human-readable report."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

from .classify import Decision
from .fsutil import atomic_write_text, copy_verified, move_file, remove_tree
from .scanner import OtherFile, SeriesGroup

logger = logging.getLogger(__name__)

REPORT_MD = "report.md"
REPORT_JSON = "report.json"
DISCARDED_DIR = "_discarded"


@dataclass
class HeldItem:
    group_no: int
    reason: str
    decision: Decision
    group: SeriesGroup | None = None
    others: list[OtherFile] = field(default_factory=list)
    extra_notes: list[str] = field(default_factory=list)

    @property
    def files(self) -> list[tuple[Path, str]]:
        out: list[tuple[Path, str]] = []
        if self.group is not None:
            out.extend((h.path, h.source_relpath) for h in self.group.headers)
            out.extend((h.path, h.source_relpath) for h in self.group.dropped_duplicates)
        out.extend((o.path, o.source_relpath) for o in self.others)
        return out

    def summary(self) -> str:
        if self.group is not None:
            g = self.group
            desc = g.description or ""
            num = g.series_number if g.series_number is not None else "?"
            return (f"{g.modality} series #{num}"
                    f" {desc!r}, {g.n_instances} files, SeriesInstanceUID {g.series_uid}, "
                    f"PatientID {g.patient_id!r}")
        return f"{len(self.others)} non-DICOM file(s)"


def group_dirname(group_no: int) -> str:
    return f"group-{group_no:02d}"


def _dest_relpath(source_relpath: str) -> Path:
    return Path(source_relpath.replace("!/", "/"))


def write_holding(holding_root: Path, ingest_id: str, source: str, items: list[HeldItem],
                  resolve_cmd: str = "iroc-store resolve", copy: bool = False) -> Path:
    """Move (or copy, for imports) each item's files into ``<ingest_id>/group-NN/`` + reports."""
    base = holding_root / ingest_id
    base.mkdir(parents=True, exist_ok=True)
    for it in items:
        gdir = base / group_dirname(it.group_no)
        for src, rel in it.files:
            dst = gdir / _dest_relpath(rel)
            if dst.exists():
                dst = dst.with_name(f"{dst.stem}_{abs(hash(str(src))) % 10000:04d}{dst.suffix}")
            if copy:
                copy_verified(src, dst)
            else:
                move_file(src, dst)
    atomic_write_text(base / REPORT_JSON, json.dumps(report_json(ingest_id, source, items),
                                                     indent=2, ensure_ascii=False))
    atomic_write_text(base / REPORT_MD, report_markdown(ingest_id, source, items, resolve_cmd))
    return base


def report_json(ingest_id: str, source: str, items: list[HeldItem]) -> dict:
    out = {"schema": "iroc-store.holding/1", "ingest_id": ingest_id, "source": source,
           "groups": []}
    for it in items:
        g = {"group_no": it.group_no, "dir": group_dirname(it.group_no), "reason": it.reason,
             "summary": it.summary(), "decision": it.decision.as_dict(),
             "notes": list(it.extra_notes), "n_files": len(it.files)}
        if it.group is not None:
            g["series"] = {
                "modality": it.group.modality, "series_uid": it.group.series_uid,
                "study_uid": it.group.study_uid, "for_uid": it.group.for_uid,
                "patient_id": it.group.patient_id, "series_number": it.group.series_number,
                "description": it.group.description,
                "folder_hints": list(it.group.folder_hints),
                "trial_protocol_id": it.group.headers[0].trial_protocol_id,
                "trial_subject_id": it.group.headers[0].trial_subject_id,
            }
        g["files"] = [rel for _, rel in it.files]
        out["groups"].append(g)
    return out


def report_markdown(ingest_id: str, source: str, items: list[HeldItem],
                    resolve_cmd: str) -> str:
    lines = [f"# Holding report {ingest_id}", "", f"Source: `{source}`", "",
             "Nothing below was filed automatically. For each group, check the DICOM header "
             "values against the folder name, then run the `resolve` command (fill in the "
             "correct trial/case) or `--discard`.", ""]
    for it in items:
        lines.append(f"## Group {it.group_no}  ({group_dirname(it.group_no)}/)  — "
                     f"reason: **{it.reason}**")
        lines.append("")
        lines.append(f"- {it.summary()}")
        if it.group is not None:
            h = it.group.headers[0]
            lines.append(f"- folder hints: {', '.join(it.group.folder_hints) or '-'}")
            if h.trial_protocol_id or h.trial_subject_id:
                lines.append(f"- ClinicalTrialProtocolID: {h.trial_protocol_id!r}, "
                             f"ClinicalTrialSubjectID: {h.trial_subject_id!r}")
            lines.append(f"- StudyDate: {h.study_date or '-'}, StudyDescription: "
                         f"{h.study_description or '-'}")
        for e in it.decision.evidence:
            tgt = f"{e.trial_id or '?'}/{e.case_id or '?'}"
            lines.append(f"- evidence [{e.category}] {e.source}: {tgt}  ({e.detail})")
        for n in it.decision.notes + it.extra_notes:
            lines.append(f"- note: {n}")
        t = it.decision.target
        trial = t[0] if t else "<TRIAL>"
        case = t[1] if t else "<CASE>"
        lines.append("")
        lines.append(f"    {resolve_cmd} {ingest_id} --group {it.group_no} --trial {trial} "
                     f"--case {case}")
        lines.append(f"    {resolve_cmd} {ingest_id} --group {it.group_no} --discard")
        lines.append("")
    return "\n".join(lines) + "\n"


def load_report(holding_root: Path, ingest_id: str) -> dict:
    p = holding_root / ingest_id / REPORT_JSON
    return json.loads(p.read_text(encoding="utf-8"))


def discard_group(holding_root: Path, ingest_id: str, group_no: int) -> Path:
    src = holding_root / ingest_id / group_dirname(group_no)
    dst = holding_root / DISCARDED_DIR / ingest_id / group_dirname(group_no)
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        remove_tree(dst)
    src.rename(dst)
    return dst


def cleanup_if_empty(holding_root: Path, ingest_id: str) -> bool:
    base = holding_root / ingest_id
    if not base.exists():
        return True
    remaining = [p for p in base.iterdir() if p.is_dir() and p.name.startswith("group-")]
    if remaining:
        return False
    remove_tree(base)
    return True
