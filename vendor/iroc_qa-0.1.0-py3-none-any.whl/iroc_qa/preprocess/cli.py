"""CLI entry point for preprocessing: ``iroc-preprocess``."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path


def main(argv: list[str] | None = None) -> int:
    """Run preprocessing subcommands."""
    parser = argparse.ArgumentParser(
        prog="iroc-preprocess",
        description="IROC data preprocessing tools.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # combine
    p_combine = sub.add_parser("combine", help="Combine dose Excel files")
    p_combine.add_argument("--input-dir", required=True, type=Path)
    p_combine.add_argument("--output", required=True, type=Path)
    p_combine.add_argument("--column", default="Achieved")

    # html-to-excel
    p_html = sub.add_parser("html-to-excel", help="Convert HTML to Excel")
    p_html.add_argument("--input-dir", required=True, type=Path)
    p_html.add_argument("--output-dir", required=True, type=Path)

    # mim-convert
    p_mim = sub.add_parser("mim-convert", help="DVA form → MIM CSV")
    p_mim.add_argument("--input", required=True, type=Path)
    p_mim.add_argument("--output", required=True, type=Path)

    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if args.command == "combine":
        from .combine import combine_dose_files
        df = combine_dose_files(args.input_dir, args.output, args.column)
        print(f"Combined {len(df.columns)} files → {args.output}")

    elif args.command == "html-to-excel":
        from .html_convert import html_to_excel
        created = html_to_excel(args.input_dir, args.output_dir)
        print(f"Converted {len(created)} HTML files")

    elif args.command == "mim-convert":
        from .mim_convert import dva_to_mim_csv
        df = dva_to_mim_csv(args.input, args.output)
        print(f"Wrote {len(df)} constraints → {args.output}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
