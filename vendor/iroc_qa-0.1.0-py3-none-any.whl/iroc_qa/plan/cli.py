"""CLI entry point for DVH analysis: ``iroc-plan``."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from .batch import DVHConfig, process_files


def main(argv: list[str] | None = None) -> int:
    """Run DVH batch processing from the command line."""
    parser = argparse.ArgumentParser(
        prog="iroc-plan",
        description="Extract DVH metrics from CSV files and write to Excel.",
    )
    parser.add_argument(
        "--input-dir", required=True, type=Path,
        help="Folder containing DVH CSV files",
    )
    parser.add_argument(
        "--output", required=True, type=Path,
        help="Output Excel file path",
    )
    parser.add_argument(
        "--structures", nargs="+", required=True,
        help="Structure names to extract (e.g. PTV_6000 Brainstem)",
    )
    parser.add_argument(
        "--rx-dose", type=float, default=None,
        help="Prescribed dose in Gy (needed for V_%%Rx metrics)",
    )
    parser.add_argument(
        "--v-thresholds", nargs="*", type=float, default=[],
        help="V-dose thresholds in Gy (e.g. 5 20 30)",
    )
    parser.add_argument(
        "--v-pct-thresholds", nargs="*", type=float, default=[],
        help="V-%%Rx thresholds as fractions (e.g. 0.95 for 95%%Rx)",
    )
    parser.add_argument(
        "--d-pct-thresholds", nargs="*", type=float, default=[],
        help="D-volume%% thresholds as fractions (e.g. 0.95 for D95%%)",
    )
    parser.add_argument(
        "--d-cc-thresholds", nargs="*", type=float, default=[],
        help="D-cc thresholds in cc (e.g. 0.03)",
    )
    parser.add_argument("-v", "--verbose", action="store_true")

    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    if not args.input_dir.is_dir():
        logging.error("Input directory not found: %s", args.input_dir)
        return 1

    config = DVHConfig(
        structures=args.structures,
        v_thresholds_gy=args.v_thresholds,
        v_percent_thresholds=args.v_pct_thresholds,
        d_percent_thresholds=args.d_pct_thresholds,
        d_cc_thresholds=args.d_cc_thresholds,
        rx_dose_gy=args.rx_dose,
    )

    df = process_files(args.input_dir, args.output, config)
    print(f"Processed {len(df)} files → {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
