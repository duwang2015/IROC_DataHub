"""Query helper behind ``iroc-store find``."""

from __future__ import annotations

from .store import Store


def find(store: Store, trial: str, modalities: list[str] | None = None,
         missing: list[str] | None = None, kind: str | None = None, module: str | None = None,
         current_only: bool = False) -> list[dict]:
    cat = store.catalog
    tid = store.cfg.trial(trial).id
    cases = cat.cases_with_modalities(tid, modalities or [], current_only, missing or [])
    out = []
    for cid in cases:
        case = store.case(tid, cid)
        c = cat.get_case(case.pk)
        if module:
            rows = cat.derived_files(case.pk, module=module, kind=kind, latest_only=True)
            paths = [str(store.abs(r["rel_path"])) for r in rows]
        elif kind:
            sql = "SELECT rel_path FROM file WHERE case_pk=? AND origin='original' AND kind LIKE ?"
            args: list = [case.pk, kind if "%" in kind else kind]
            if current_only and c and c["current_batch_id"]:
                sql += " AND batch_id=?"
                args.append(c["current_batch_id"])
            paths = [str(store.abs(r[0])) for r in cat.conn.execute(sql + " ORDER BY rel_path",
                                                                      args)]
        else:
            bid = c["current_batch_id"] if (current_only and c) else None
            paths = [str(store.abs(s["rel_dir"]))
                     for s in cat.series_for_case(case.pk, batch_id=bid)
                     if not modalities or s["modality"] in {m.upper() for m in modalities}]
        out.append({"trial": tid, "case": cid, "dir": str(case.dir), "paths": paths})
    return out
