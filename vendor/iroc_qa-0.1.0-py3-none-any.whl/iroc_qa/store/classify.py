"""Resolve (collection, case) for a series group. The DICOM header is authoritative.

A collection is a trial or a non-trial data source (a hospital, a public dataset). Trials are
recognised from the 0012 clinical-trial tags or PatientID patterns; sources from PatientID
patterns or InstitutionName. Folder names are only cross-checked: any disagreement, or a
header that lacks what is needed, sends the group to the holding area for human review.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .config import CollectionRule, StoreConfig
from .layout import normalize_case_id
from .scanner import OtherFile, SeriesGroup

AUTHORITATIVE = "authoritative"
CHECK = "check"
FORCED = "forced"

# holding reasons
OK = "ok"
HEADER_CONFLICT = "header_conflict"          # 0012 tags and PatientID name different trials/cases
UNRECOGNIZED = "unrecognized"                # nothing usable in the header at all
UNKNOWN_SOURCE = "unknown_source"            # PatientID present but no trial and no known hospital
FOLDER_MISMATCH = "folder_mismatch"          # folder name disagrees with the header
AMBIGUOUS_TRIAL = "ambiguous_trial"          # PatientID matches several trials
AMBIGUOUS_SOURCE = "ambiguous_source"        # header matches several sources
INCONSISTENT_SERIES = "inconsistent_series"  # PatientID / 0012 tags vary inside one series
MISSING_MODALITY = "missing_modality"        # Modality tag empty
MISSING_UIDS = "missing_uids"                # no SeriesInstanceUID or SOPInstanceUID
MISSING_PATIENT_ID = "missing_patient_id"    # source recognised but PatientID empty
UID_CONFLICT = "uid_conflict"
NO_DICOM_CONTEXT = "no_dicom_context"
READ_ERROR = "read_error"

REASON_HELP = {
    HEADER_CONFLICT: "ClinicalTrialProtocolID/SubjectID and PatientID point to different cases",
    UNRECOGNIZED: "no PatientID, trial tags or institution in the header",
    UNKNOWN_SOURCE: "PatientID matches no trial pattern and the hospital/dataset is not "
                    "recognised (InstitutionName missing or not configured)",
    FOLDER_MISMATCH: "folder name names a different trial/case than the DICOM header",
    AMBIGUOUS_TRIAL: "PatientID matches the patterns of more than one trial",
    AMBIGUOUS_SOURCE: "header matches more than one non-trial source",
    INCONSISTENT_SERIES: "files of one series carry different PatientID or trial tags",
    MISSING_MODALITY: "Modality tag is empty; the series cannot be named",
    MISSING_UIDS: "SeriesInstanceUID or SOPInstanceUID missing; the files cannot be indexed",
    MISSING_PATIENT_ID: "the hospital/dataset is recognised but PatientID is empty",
    UID_CONFLICT: "SOPInstanceUID already stored with other content or under another case",
    NO_DICOM_CONTEXT: "non-DICOM file with no DICOM series in its folder to inherit a case from",
    READ_ERROR: "file has a DICOM preamble but cannot be parsed",
}


@dataclass
class Evidence:
    category: str          # authoritative | check | forced
    source: str            # tag_0012 | patient_id | institution | folder | folder_keyword | keyword
    trial_id: str | None   # collection id
    case_id: str | None    # normalized
    detail: str = ""

    def as_dict(self) -> dict:
        return {"category": self.category, "source": self.source, "trial": self.trial_id,
                "case": self.case_id, "detail": self.detail}


@dataclass
class Decision:
    target: tuple[str, str] | None
    reason: str
    header_source: str = ""
    folder_check: str = "absent"   # match | mismatch | absent
    evidence: list[Evidence] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    site: str = ""
    kind: str = ""

    @property
    def ok(self) -> bool:
        return self.reason == OK and self.target is not None

    def as_dict(self) -> dict:
        return {
            "trial": self.target[0] if self.target else None,
            "case": self.target[1] if self.target else None,
            "site": self.site, "kind": self.kind,
            "reason": self.reason, "reason_help": REASON_HELP.get(self.reason, ""),
            "header_source": self.header_source, "folder_check": self.folder_check,
            "evidence": [e.as_dict() for e in self.evidence], "notes": list(self.notes),
        }


def _norm(rule: CollectionRule, raw: str) -> str:
    return normalize_case_id(raw, rule.case_id_normalize)


def _finish(d: Decision, cfg: StoreConfig) -> Decision:
    if d.target:
        try:
            rule = cfg.trial(d.target[0])
            d.site, d.kind = rule.site, rule.kind
        except Exception:
            pass
    return d


# ---------------------------------------------------------------------------------
# evidence
# ---------------------------------------------------------------------------------

def collect_evidence(group: SeriesGroup, cfg: StoreConfig) -> list[Evidence]:
    ev: list[Evidence] = []
    hs = group.headers
    pids = {h.patient_id for h in hs}
    protos = {h.trial_protocol_id for h in hs if h.trial_protocol_id}
    subjects = {h.trial_subject_id for h in hs if h.trial_subject_id}
    insts = {h.institution_name for h in hs if h.institution_name}
    depts = {h.department_name for h in hs if h.department_name}
    trials = cfg.trials_only
    sources = cfg.sources

    # -- authoritative: clinical trial module tags (0012,xxxx)
    if protos or subjects:
        if len(protos) > 1 or len(subjects) > 1:
            ev.append(Evidence(AUTHORITATIVE, "tag_0012", None, None,
                               f"inconsistent 0012 tags within series: {sorted(protos)} "
                               f"{sorted(subjects)}"))
        else:
            proto = next(iter(protos), "")
            subj = next(iter(subjects), "")
            matched = [t for t in trials if t.matches_protocol(proto)] if proto else []
            if matched:
                t = matched[0]
                ev.append(Evidence(AUTHORITATIVE, "tag_0012", t.id,
                                   _norm(t, subj) if subj else None,
                                   f"ClinicalTrialProtocolID={proto!r} "
                                   f"ClinicalTrialSubjectID={subj!r}"))
            elif proto:
                ev.append(Evidence(CHECK, "tag_0012", None, None,
                                   f"ClinicalTrialProtocolID={proto!r} matches no configured "
                                   "trial"))
    # -- authoritative: PatientID against trials, then sources
    if len(pids) > 1:
        ev.append(Evidence(AUTHORITATIVE, "patient_id", None, None,
                           f"inconsistent PatientID within series: {sorted(pids)}"))
    else:
        pid = next(iter(pids), "")
        hits = 0
        for t in trials + sources:
            c = t.match_patient_id(pid) if pid else None
            if c:
                ev.append(Evidence(AUTHORITATIVE, "patient_id", t.id, _norm(t, c),
                                   f"PatientID={pid!r}"))
                hits += 1
        if not hits:
            ev.append(Evidence(AUTHORITATIVE, "patient_id", None, None,
                               f"PatientID={pid!r} matches no trial or source pattern" if pid
                               else "PatientID is empty"))
    # -- authoritative: InstitutionName / department against sources
    inst_text = " | ".join(sorted(insts | depts))
    if inst_text:
        pid = next(iter(pids), "") if len(pids) == 1 else ""
        hit = False
        for s in sources:
            if s.match_institution(inst_text):
                ev.append(Evidence(AUTHORITATIVE, "institution", s.id,
                                   _norm(s, pid) if pid else None,
                                   f"InstitutionName={inst_text!r}"))
                hit = True
        if not hit:
            ev.append(Evidence(CHECK, "institution", None, None,
                               f"InstitutionName={inst_text!r} matches no configured source"))
    else:
        ev.append(Evidence(CHECK, "institution", None, None, "InstitutionName is empty"))
    # -- check: folder names (nearest first): trial case patterns, then collection keywords
    for hint in group.folder_hints:
        for t in trials:
            c = t.match_case_in_text(hint)
            if c:
                ev.append(Evidence(CHECK, "folder", t.id, _norm(t, c), f"folder={hint!r}"))
        for t in trials + sources:
            if t.keyword_in(hint):
                ev.append(Evidence(CHECK, "folder_keyword", t.id, None, f"folder={hint!r}"))
    # -- check: keywords in StudyDescription (note only)
    desc = hs[0].study_description if hs else ""
    if desc:
        for t in trials + sources:
            if t.keyword_in(desc):
                ev.append(Evidence(CHECK, "keyword", t.id, None, f"keyword in {desc!r}"))
    return ev


# ---------------------------------------------------------------------------------
# decision
# ---------------------------------------------------------------------------------

def decide(evidence: list[Evidence], cfg: StoreConfig,
           forced: tuple[str, str] | None = None) -> Decision:
    d = Decision(target=None, reason=UNRECOGNIZED, evidence=list(evidence))
    auth = [e for e in evidence if e.category == AUTHORITATIVE]
    for e in auth:
        if e.trial_id is None and "inconsistent" in e.detail:
            d.reason = INCONSISTENT_SERIES
            d.notes.append(e.detail)
            if forced is None:
                return d
    if forced is not None:
        t = cfg.trial(forced[0])
        d.target = (t.id, _norm(t, forced[1]))
        d.reason = OK
        d.header_source = "forced"
        d.evidence.append(Evidence(FORCED, "forced", d.target[0], d.target[1], "forced by user"))
        agree = [e for e in auth if e.trial_id]
        if agree and not any((e.trial_id, e.case_id) == d.target for e in agree):
            d.notes.append("forced target differs from DICOM header: "
                           + "; ".join(f"{e.source}: {e.trial_id}/{e.case_id}" for e in agree))
        return _finish(d, cfg)

    kinds = {t.id: t.kind for t in cfg.trials}
    tag = [e for e in auth if e.source == "tag_0012" and e.trial_id]
    pid_trial = [e for e in auth if e.source == "patient_id" and e.trial_id
                 and kinds.get(e.trial_id) == "trial"]
    pid_source = [e for e in auth if e.source == "patient_id" and e.trial_id
                  and kinds.get(e.trial_id) == "source"]
    inst = [e for e in auth if e.source == "institution" and e.trial_id]
    pid_empty = any(e.source == "patient_id" and e.detail == "PatientID is empty" for e in auth)

    # ---- trials first
    candidates: list[tuple[str, str, str]] = []   # (source, collection, case)
    if tag:
        e = tag[0]
        if e.case_id:
            candidates.append(("tag_0012", e.trial_id, e.case_id))
        else:
            same = [p for p in pid_trial if p.trial_id == e.trial_id]
            if same:
                candidates.append(("tag_0012+patient_id", e.trial_id, same[0].case_id))
            else:
                d.notes.append(f"trial {e.trial_id} from 0012 tags but PatientID gives no case")
    if len({p.trial_id for p in pid_trial}) > 1:
        d.reason = AMBIGUOUS_TRIAL
        d.notes.append("PatientID matches more than one trial: "
                       + ", ".join(f"{p.trial_id}/{p.case_id}" for p in pid_trial))
        return d
    if pid_trial:
        candidates.append(("patient_id", pid_trial[0].trial_id, pid_trial[0].case_id))
    uniq = {(c, k) for _, c, k in candidates}
    if len(uniq) > 1:
        d.reason = HEADER_CONFLICT
        d.notes.append("0012 tags and PatientID disagree: "
                       + ", ".join(f"{s}: {c}/{k}" for s, c, k in candidates))
        return d
    if uniq:
        d.target = next(iter(uniq))
        d.header_source = candidates[0][0]
    else:
        # ---- then non-trial sources
        src_ids = {e.trial_id for e in pid_source} | {e.trial_id for e in inst}
        if len(src_ids) > 1:
            d.reason = AMBIGUOUS_SOURCE
            d.notes.append("header matches more than one source: " + ", ".join(sorted(src_ids)))
            return d
        if src_ids:
            sid = next(iter(src_ids))
            case = next((e.case_id for e in pid_source if e.case_id), None) or \
                next((e.case_id for e in inst if e.case_id), None)
            if not case:
                d.reason = MISSING_PATIENT_ID
                d.notes.append(f"source {sid} recognised but PatientID is empty")
                return d
            d.target = (sid, case)
            d.header_source = "patient_id" if pid_source else "institution"
        else:
            missing = [e.detail for e in evidence
                       if e.source in ("patient_id", "institution") and e.trial_id is None]
            hints = [e for e in evidence if e.category == CHECK and e.trial_id]
            if pid_empty and not inst:
                d.reason = UNRECOGNIZED
            else:
                d.reason = UNKNOWN_SOURCE
            d.notes.extend(missing)
            if hints:
                d.notes.append("folder/keyword suggests: " + ", ".join(
                    f"{e.trial_id}/{e.case_id or '?'}" for e in hints))
            return d

    # ---- cross-check against folder names
    coll, case = d.target
    folder_ev = [e for e in evidence if e.source == "folder"]
    kw_ev = [e for e in evidence if e.source == "folder_keyword"]
    mism = [e for e in folder_ev if (e.trial_id, e.case_id) != d.target]
    mism += [e for e in kw_ev if e.trial_id != coll]
    if mism:
        d.reason = FOLDER_MISMATCH
        d.folder_check = "mismatch"
        d.notes.append("folder name disagrees with header: " + ", ".join(
            f"{e.detail} -> {e.trial_id}/{e.case_id or '?'}" for e in mism)
            + f"; header -> {coll}/{case}")
        return _finish(d, cfg)
    d.folder_check = "match" if (folder_ev or kw_ev) else "absent"
    desc_kw = [e for e in evidence if e.source == "keyword" and e.trial_id != coll]
    if desc_kw:
        d.notes.append("StudyDescription mentions another collection: "
                       + ", ".join(e.trial_id for e in desc_kw))
    d.reason = OK
    return _finish(d, cfg)


def classify_group(group: SeriesGroup, cfg: StoreConfig,
                   forced: tuple[str, str] | None = None) -> Decision:
    hs = group.headers
    if forced is None:
        if not group.modality or group.modality == "OT" and not any(h.modality for h in hs):
            d = Decision(None, MISSING_MODALITY, evidence=collect_evidence(group, cfg),
                         notes=["Modality tag is empty in every file of the series"])
            return d
        if group.series_uid == "UNKNOWN" or any(not h.sop_instance_uid for h in hs):
            what = []
            if group.series_uid == "UNKNOWN":
                what.append("SeriesInstanceUID")
            if any(not h.sop_instance_uid for h in hs):
                what.append("SOPInstanceUID")
            return Decision(None, MISSING_UIDS, evidence=collect_evidence(group, cfg),
                            notes=["missing " + " and ".join(what)])
    d = decide(collect_evidence(group, cfg), cfg, forced)
    for p in group.problems:
        if "different content" in p:
            d.reason = UID_CONFLICT
            d.notes.append(p)
        else:
            d.notes.append(p)
    if d.reason == UID_CONFLICT:
        d.target = None
    return d


def inherit_for_other(other: OtherFile, group_decisions: list[tuple[SeriesGroup, Decision]],
                      cfg: StoreConfig, forced: tuple[str, str] | None = None) -> Decision:
    """A non-DICOM file inherits the unique target of DICOM groups in its folder or below."""
    if forced is not None:
        t = cfg.trial(forced[0])
        return _finish(Decision((t.id, _norm(t, forced[1])), OK, "forced", "absent",
                                [Evidence(FORCED, "forced", t.id, _norm(t, forced[1]),
                                          "forced by user")]), cfg)
    my_dir = str(_parent(other.source_relpath))
    same: list[Decision] = []
    below: list[Decision] = []
    for g, dec in group_decisions:
        dirs = g.source_dirs
        if my_dir in dirs:
            same.append(dec)
        elif any(sd.startswith(my_dir + "/") or my_dir == "." for sd in dirs):
            below.append(dec)
    scope = same or below          # DICOM in the same folder wins over sub-folders
    targets = {d.target for d in scope if d.ok}
    blocked = any(not d.ok for d in scope)
    d = Decision(None, NO_DICOM_CONTEXT)
    if len(targets) == 1 and not blocked:
        d.target = next(iter(targets))
        d.reason = OK
        d.header_source = "inherited"
        d.notes.append("inherited from DICOM series in the same folder")
        return _finish(d, cfg)
    if not targets and not blocked:
        d.notes.append("no DICOM series in the same folder to inherit a case from")
    elif blocked:
        d.notes.append("DICOM series in the same folder were sent to holding")
    else:
        d.notes.append("DICOM series in the same folder belong to several cases")
    for t in cfg.trials:
        for hint in other.folder_hints:
            c = t.match_case_in_text(hint) if t.is_trial else (t.id if t.keyword_in(hint)
                                                                else None)
            if c:
                d.notes.append(f"folder suggests {t.id}/{_norm(t, c) if t.is_trial else '?'}")
                break
    return d


def _parent(relpath: str) -> str:
    rp = relpath.replace("!/", "/")
    if "/" not in rp:
        return "."
    return rp.rsplit("/", 1)[0]
