"""Dosiomics feature extraction from NIfTI dose distributions.

Applies radiomics feature extraction to dose maps instead of imaging data.
Wraps the ``Eval.radiomics`` engine with dose-appropriate defaults:

  - Bin width: 50 cGy (dose maps have wider value ranges than CT)
  - Feature classes: firstorder + glcm by default (shape is mask-only,
    identical for imaging and dose; included on request)
  - All functions accept the same path/label/roi_mapping interface

Usage
-----
    from Eval.dosiomics import extract_dosiomics, extract_dosiomics_batch

    # Single ROI
    features = extract_dosiomics("dose.nii.gz", "mask.nii.gz")

    # All ROIs in a label map
    results = extract_dosiomics_batch(
        "dose.nii.gz", "labels.nii.gz", {1: "GTV", 2: "Brainstem"},
    )

    # Compare original vs defaced dose
    report = compare_dosiomics(
        "dose_original.nii.gz", "dose_defaced.nii.gz", "mask.nii.gz",
    )
"""

from __future__ import annotations

import json
import logging
from collections import OrderedDict
from pathlib import Path

from . import radiomics

logger = logging.getLogger(__name__)

# Dose-specific defaults
DOSE_BIN_WIDTH = 50  # cGy — wider bins for dose distributions
DOSE_FEATURE_CLASSES = ["firstorder", "glcm"]


# ============================================================================
# Core extraction
# ============================================================================

def extract_dosiomics(
    dose_path: str | Path,
    mask_path: str | Path,
    label: int | None = None,
    feature_classes: list[str] | None = None,
    bin_width: float = DOSE_BIN_WIDTH,
    roi_name: str = "",
) -> OrderedDict:
    """Extract dosiomics features from a dose distribution + ROI mask.

    Parameters
    ----------
    dose_path : path
        NIfTI dose file (cGy).
    mask_path : path
        NIfTI binary mask or label map.
    label : int, optional
        Label value if mask is a label map.
    feature_classes : list of str, optional
        Feature classes to compute.
        Default: ["firstorder", "glcm"].
        Options: "firstorder", "shape", "glcm", "glrlm", "glszm".
    bin_width : float
        Discretization bin width (cGy).  Default 50 cGy.
    roi_name : str
        Name label for the ROI.

    Returns
    -------
    OrderedDict of feature_name -> float.
    """
    if feature_classes is None:
        feature_classes = list(DOSE_FEATURE_CLASSES)

    return radiomics.extract_features(
        image_path=dose_path,
        mask_path=mask_path,
        label=label,
        feature_classes=feature_classes,
        bin_width=bin_width,
        roi_name=roi_name,
    )


def extract_dosiomics_batch(
    dose_path: str | Path,
    label_path: str | Path,
    roi_mapping: dict[int, str] | str | Path,
    feature_classes: list[str] | None = None,
    bin_width: float = DOSE_BIN_WIDTH,
) -> dict[str, OrderedDict]:
    """Extract dosiomics features for all ROIs in a label map.

    Parameters
    ----------
    dose_path : path
        NIfTI dose file (cGy).
    label_path : path
        NIfTI label map.
    roi_mapping : dict or JSON path
        Label int -> ROI name.
    feature_classes : list of str, optional
        Default: ["firstorder", "glcm"].
    bin_width : float
        Discretization bin width (cGy).  Default 50 cGy.

    Returns
    -------
    dict mapping ROI name -> OrderedDict of features.
    """
    if feature_classes is None:
        feature_classes = list(DOSE_FEATURE_CLASSES)

    return radiomics.extract_features_batch(
        image_path=dose_path,
        label_path=label_path,
        roi_mapping=roi_mapping,
        feature_classes=feature_classes,
        bin_width=bin_width,
    )


# ============================================================================
# Comparison: original vs defaced dose
# ============================================================================

def compare_dosiomics(
    original_dose_path: str | Path,
    defaced_dose_path: str | Path,
    mask_path: str | Path,
    label: int | None = None,
    feature_classes: list[str] | None = None,
    bin_width: float = DOSE_BIN_WIDTH,
    roi_name: str = "",
) -> dict:
    """Compare dosiomics features between original and defaced dose.

    Parameters
    ----------
    original_dose_path : path
    defaced_dose_path : path
    mask_path : path
    label : int, optional
    feature_classes : list of str, optional
    bin_width : float
    roi_name : str

    Returns
    -------
    dict with feature-level comparison.
    """
    if feature_classes is None:
        feature_classes = list(DOSE_FEATURE_CLASSES)

    feat_orig = radiomics.extract_features(
        original_dose_path, mask_path, label,
        feature_classes, bin_width, roi_name=roi_name,
    )
    feat_defc = radiomics.extract_features(
        defaced_dose_path, mask_path, label,
        feature_classes, bin_width, roi_name=roi_name,
    )

    comparison = radiomics.compare_features(feat_orig, feat_defc)
    comparison["roi_name"] = roi_name
    return comparison


def compare_dosiomics_batch(
    original_dose_path: str | Path,
    defaced_dose_path: str | Path,
    label_path: str | Path,
    roi_mapping: dict[int, str] | str | Path,
    feature_classes: list[str] | None = None,
    bin_width: float = DOSE_BIN_WIDTH,
) -> dict[str, dict]:
    """Compare dosiomics for all ROIs between original and defaced dose.

    Parameters
    ----------
    original_dose_path : path
    defaced_dose_path : path
    label_path : path
    roi_mapping : dict or JSON path
    feature_classes : list of str, optional
    bin_width : float

    Returns
    -------
    dict mapping ROI name -> comparison dict.
    """
    if feature_classes is None:
        feature_classes = list(DOSE_FEATURE_CLASSES)

    if isinstance(roi_mapping, (str, Path)):
        roi_mapping = Path(roi_mapping)
        if not roi_mapping.exists():
            raise FileNotFoundError(f"ROI mapping not found: {roi_mapping}")
        with open(roi_mapping, encoding="utf-8") as f:
            raw = json.load(f)
        roi_mapping = {int(k): v for k, v in raw.items()}

    orig_results = radiomics.extract_features_batch(
        original_dose_path, label_path, roi_mapping,
        feature_classes, bin_width,
    )
    defc_results = radiomics.extract_features_batch(
        defaced_dose_path, label_path, roi_mapping,
        feature_classes, bin_width,
    )

    comparisons = {}
    for name in sorted(set(orig_results) & set(defc_results)):
        comp = radiomics.compare_features(orig_results[name], defc_results[name])
        comp["roi_name"] = name
        comparisons[name] = comp

    return comparisons


def export_dosiomics_csv(
    results: dict[str, OrderedDict],
    output_path: str | Path,
) -> None:
    """Export dosiomics features to CSV.

    One row per ROI, columns = features.

    Parameters
    ----------
    results : dict
        ROI name -> OrderedDict of features (from extract_dosiomics_batch).
    output_path : path
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if not results:
        logger.warning("No dosiomics results to export")
        return

    # Collect all feature keys
    all_keys = []
    for feat_dict in results.values():
        for k in feat_dict:
            if k not in all_keys:
                all_keys.append(k)

    lines = [",".join(["ROI"] + all_keys)]
    for roi_name, feat_dict in sorted(results.items()):
        row = [roi_name]
        for k in all_keys:
            row.append(f"{feat_dict.get(k, 0.0):.6f}")
        lines.append(",".join(row))

    output_path.write_text("\n".join(lines), encoding="utf-8")
    logger.info("Dosiomics CSV exported: %s (%d ROIs, %d features)",
                output_path, len(results), len(all_keys))
