"""Contour QA and auto-segmentation comparison (planned)."""
